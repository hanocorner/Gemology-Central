#Gemology Central Laboratory
Purpose of this project is to create a solution to verify Gem report via online system.
