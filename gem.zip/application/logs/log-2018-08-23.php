<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-08-23 21:59:57 --> 404 Page Not Found: Assets/css
ERROR - 2018-08-23 22:05:28 --> 404 Page Not Found: Assests/admin
ERROR - 2018-08-23 23:27:18 --> Severity: Parsing Error --> syntax error, unexpected '$id' (T_VARIABLE) C:\wamp64\www\gem\application\models\Report_model.php 46
ERROR - 2018-08-23 23:32:33 --> Query error: Unknown column '$id' in 'where clause' - Invalid query: SELECT cerno, cer_object, cer_identification, cer_weight, customerID FROM tbl_certificate WHERE customerID = $id 
ERROR - 2018-08-23 23:33:15 --> Severity: Notice --> Array to string conversion C:\wamp64\www\gem\application\models\Report_model.php 46
ERROR - 2018-08-23 23:33:15 --> Query error: Unknown column 'Array' in 'where clause' - Invalid query: SELECT cerno, cer_object, cer_identification, cer_weight, customerID FROM tbl_certificate WHERE customerID = Array 
ERROR - 2018-08-23 23:34:10 --> Severity: Notice --> Array to string conversion C:\wamp64\www\gem\application\models\Report_model.php 46
ERROR - 2018-08-23 23:34:10 --> Query error: Unknown column 'Array' in 'where clause' - Invalid query: SELECT cerno, cer_object, cer_identification, cer_weight, customerID FROM tbl_certificate WHERE customerID = Array 
