<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-09-14 06:47:31 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\models\Lab_model.php 38
ERROR - 2018-09-14 06:47:39 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\models\Lab_model.php 38
ERROR - 2018-09-14 06:47:52 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\models\Lab_model.php 38
ERROR - 2018-09-14 06:48:55 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\models\Lab_model.php 38
ERROR - 2018-09-14 06:49:46 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\models\Lab_model.php 40
ERROR - 2018-09-14 06:49:51 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\models\Lab_model.php 40
ERROR - 2018-09-14 06:59:04 --> 404 Page Not Found: admin/Report/add_customer
ERROR - 2018-09-14 07:43:53 --> Severity: Notice --> Undefined variable: repo_type C:\wamp64\www\gem\application\controllers\admin\Report.php 72
