<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-09-13 06:56:47 --> Severity: Parsing Error --> syntax error, unexpected ')' C:\wamp64\www\gem\application\controllers\admin\Report.php 93
