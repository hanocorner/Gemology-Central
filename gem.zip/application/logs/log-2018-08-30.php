<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-08-30 00:07:03 --> 404 Page Not Found: Assets/css
ERROR - 2018-08-30 00:09:30 --> 404 Page Not Found: admin/%3C/index
ERROR - 2018-08-30 00:09:38 --> 404 Page Not Found: admin/%3C/index
ERROR - 2018-08-30 00:12:54 --> 404 Page Not Found: admin/Report/8
ERROR - 2018-08-30 00:44:07 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1 - Invalid query: SELECT cerno, cer_object, cer_identification, cer_weight, customerID FROM tbl_certificate WHERE customerID =  
ERROR - 2018-08-30 00:45:30 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'all' at line 1 - Invalid query: SELECT cerno, cer_object, cer_identification, cer_weight, customerID FROM tbl_certificate WHERE customerID = gem-all 
ERROR - 2018-08-30 00:46:11 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1 - Invalid query: SELECT cerno, cer_object, cer_identification, cer_weight, customerID FROM tbl_certificate WHERE customerID =  
ERROR - 2018-08-30 00:59:05 --> Severity: Notice --> Undefined index: id C:\wamp64\www\gem\application\controllers\admin\Report.php 101
ERROR - 2018-08-30 00:59:05 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1 - Invalid query: SELECT cerno, cer_object, cer_identification, cer_weight, customerID FROM tbl_certificate WHERE customerID =  
ERROR - 2018-08-30 00:59:48 --> Severity: Notice --> Undefined variable: params C:\wamp64\www\gem\application\controllers\admin\Report.php 113
ERROR - 2018-08-30 01:01:15 --> Severity: Notice --> Undefined variable: id C:\wamp64\www\gem\application\controllers\admin\Report.php 103
ERROR - 2018-08-30 01:01:15 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1 - Invalid query: SELECT cerno, cer_object, cer_identification, cer_weight, customerID FROM tbl_certificate WHERE customerID =  
ERROR - 2018-08-30 01:03:08 --> Query error: Unknown column 'NaN' in 'where clause' - Invalid query: SELECT cerno, cer_object, cer_identification, cer_weight, customerID FROM tbl_certificate WHERE customerID = NaN 
ERROR - 2018-08-30 01:03:23 --> Severity: Notice --> Undefined index: id C:\wamp64\www\gem\application\models\Report_model.php 46
ERROR - 2018-08-30 01:03:23 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1 - Invalid query: SELECT cerno, cer_object, cer_identification, cer_weight, customerID FROM tbl_certificate WHERE customerID =  
ERROR - 2018-08-30 01:03:34 --> Query error: Unknown column 'NaN' in 'where clause' - Invalid query: SELECT cerno, cer_object, cer_identification, cer_weight, customerID FROM tbl_certificate WHERE customerID = NaN 
ERROR - 2018-08-30 01:07:45 --> Query error: Unknown column 'id' in 'where clause' - Invalid query: SELECT cerno, cer_object, cer_identification, cer_weight, customerID FROM tbl_certificate WHERE customerID = id 
ERROR - 2018-08-30 01:44:53 --> Severity: Notice --> Array to string conversion C:\wamp64\www\gem\application\views\admin\report\gem.php 70
ERROR - 2018-08-30 01:50:32 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'BY cerno DESC LIMIT 0, 10' at line 1 - Invalid query: SELECT cerno, cer_object, cer_identification, cer_paymentStatus, cer_weight, customerID FROM tbl_certificateORDER BY cerno DESC LIMIT 0, 10
ERROR - 2018-08-30 01:54:11 --> Severity: Parsing Error --> syntax error, unexpected '$id' (T_VARIABLE) C:\wamp64\www\gem\application\models\Report_model.php 52
ERROR - 2018-08-30 06:23:18 --> 404 Page Not Found: Assets/css
ERROR - 2018-08-30 06:23:28 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'BY custid DESC LIMIT 0, 10' at line 1 - Invalid query: SELECT custid, cus_firstname, cus_lastname, cus_email FROM tbl_customerORDER BY custid DESC LIMIT 0, 10
ERROR - 2018-08-30 06:24:18 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE cerno LIKE '%a%' OR cer_object LIKE '%a%' OR cer_weight LIKE '%a%'' at line 1 - Invalid query: SELECT cerno, cer_object, cer_identification, cer_paymentStatus, cer_weight, customerID FROM tbl_certificate WHERE customerID = 3  WHERE cerno LIKE '%a%' OR cer_object LIKE '%a%' OR cer_weight LIKE '%a%' 
ERROR - 2018-08-30 06:24:30 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE cerno LIKE '%a%' OR cer_object LIKE '%a%' OR cer_weight LIKE '%a%'' at line 1 - Invalid query: SELECT cerno, cer_object, cer_identification, cer_paymentStatus, cer_weight, customerID FROM tbl_certificate WHERE customerID = 3  WHERE cerno LIKE '%a%' OR cer_object LIKE '%a%' OR cer_weight LIKE '%a%' 
ERROR - 2018-08-30 06:27:13 --> Severity: Notice --> Array to string conversion C:\wamp64\www\gem\application\controllers\admin\Report.php 104
ERROR - 2018-08-30 06:27:20 --> Severity: Notice --> Array to string conversion C:\wamp64\www\gem\application\controllers\admin\Report.php 104
ERROR - 2018-08-30 06:27:33 --> Severity: Notice --> Array to string conversion C:\wamp64\www\gem\application\controllers\admin\Report.php 104
ERROR - 2018-08-30 06:28:10 --> Severity: Error --> Call to undefined function prinnt_r() C:\wamp64\www\gem\application\controllers\admin\Report.php 104
ERROR - 2018-08-30 06:38:30 --> 404 Page Not Found: admin/Blog/add_gemstone
ERROR - 2018-08-30 06:39:48 --> 404 Page Not Found: admin/Blog/add_gemstone
ERROR - 2018-08-30 06:40:19 --> 404 Page Not Found: admin/Blog/add_gemstone
ERROR - 2018-08-30 06:40:24 --> 404 Page Not Found: Assets/img
ERROR - 2018-08-30 07:26:05 --> Severity: Parsing Error --> syntax error, unexpected 'print' (T_PRINT), expecting identifier (T_STRING) C:\wamp64\www\gem\application\controllers\admin\Report.php 224
ERROR - 2018-08-30 07:27:05 --> Severity: Notice --> Undefined variable: id C:\wamp64\www\gem\application\views\admin\report\gem.php 69
ERROR - 2018-08-30 07:27:05 --> Severity: Notice --> Undefined variable: customer C:\wamp64\www\gem\application\views\admin\report\gem.php 70
ERROR - 2018-08-30 07:27:05 --> Severity: Notice --> Undefined variable: id C:\wamp64\www\gem\application\views\admin\report\gem.php 71
ERROR - 2018-08-30 07:29:20 --> 404 Page Not Found: Assets/img
ERROR - 2018-08-30 07:30:03 --> 404 Page Not Found: Assets/img
ERROR - 2018-08-30 07:30:28 --> 404 Page Not Found: Assets/img
ERROR - 2018-08-30 07:30:40 --> 404 Page Not Found: Assets/img
ERROR - 2018-08-30 07:37:34 --> 404 Page Not Found: Assets/img
ERROR - 2018-08-30 07:41:10 --> 404 Page Not Found: Assets/img
ERROR - 2018-08-30 07:45:34 --> 404 Page Not Found: Assets/img
ERROR - 2018-08-30 20:57:08 --> 404 Page Not Found: Assets/css
ERROR - 2018-08-30 21:13:07 --> Severity: Notice --> Undefined offset: 0 C:\wamp64\www\gem\application\models\Report_model.php 75
ERROR - 2018-08-30 21:13:07 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\models\Report_model.php 75
ERROR - 2018-08-30 21:13:07 --> Severity: Notice --> Undefined offset: 0 C:\wamp64\www\gem\application\models\Report_model.php 75
ERROR - 2018-08-30 21:13:07 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\models\Report_model.php 75
ERROR - 2018-08-30 21:13:07 --> Query error: Unknown column 'undefined' in 'where clause' - Invalid query: SELECT cerno, cer_object, cer_identification, cer_paymentStatus, cer_weight, customerID FROM tbl_certificate  WHERE customerID = undefined ORDER BY cerno DESC LIMIT 0, 10
ERROR - 2018-08-30 21:16:45 --> Severity: Notice --> Undefined offset: 0 C:\wamp64\www\gem\application\models\Report_model.php 75
ERROR - 2018-08-30 21:16:45 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\models\Report_model.php 75
ERROR - 2018-08-30 21:16:45 --> Severity: Notice --> Undefined offset: 0 C:\wamp64\www\gem\application\models\Report_model.php 75
ERROR - 2018-08-30 21:16:45 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\models\Report_model.php 75
ERROR - 2018-08-30 21:16:46 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'ORDER BY cerno DESC LIMIT 0, 10' at line 1 - Invalid query: SELECT cerno, cer_object, cer_identification, cer_paymentStatus, cer_weight, customerID FROM tbl_certificate  WHERE customerID =  ORDER BY cerno DESC LIMIT 0, 10
ERROR - 2018-08-30 21:19:09 --> Severity: Compile Error --> Cannot use isset() on the result of a function call (you can use "null !== func()" instead) C:\wamp64\www\gem\application\controllers\admin\Report.php 84
ERROR - 2018-08-30 23:09:52 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1 - Invalid query: SELECT * FROM tbl_certificate WHERE customerID =  
ERROR - 2018-08-30 23:12:14 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1 - Invalid query: SELECT * FROM tbl_certificate WHERE cerno =  
ERROR - 2018-08-30 23:15:54 --> Query error: Unknown column 'GCL2018' in 'where clause' - Invalid query: SELECT * FROM tbl_certificate WHERE cerno = GCL2018-071005 
ERROR - 2018-08-30 23:16:02 --> Query error: Unknown column 'GCL2018' in 'where clause' - Invalid query: SELECT * FROM tbl_certificate WHERE cerno = GCL2018-071005 
ERROR - 2018-08-30 23:16:47 --> Query error: Unknown column 'GCL2018' in 'where clause' - Invalid query: SELECT * FROM tbl_certificate WHERE cerno = GCL2018-071005 
ERROR - 2018-08-30 23:17:49 --> Severity: Notice --> Undefined offset: 0 C:\wamp64\www\gem\application\views\admin\report\preview_modal.php 10
ERROR - 2018-08-30 23:17:49 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\admin\report\preview_modal.php 10
ERROR - 2018-08-30 23:17:49 --> Severity: Notice --> Undefined offset: 0 C:\wamp64\www\gem\application\views\admin\report\preview_modal.php 21
ERROR - 2018-08-30 23:17:49 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\admin\report\preview_modal.php 21
ERROR - 2018-08-30 23:17:49 --> Severity: Notice --> Undefined offset: 0 C:\wamp64\www\gem\application\views\admin\report\preview_modal.php 32
ERROR - 2018-08-30 23:17:49 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\admin\report\preview_modal.php 32
ERROR - 2018-08-30 23:17:49 --> Severity: Notice --> Undefined offset: 0 C:\wamp64\www\gem\application\views\admin\report\preview_modal.php 43
ERROR - 2018-08-30 23:17:49 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\admin\report\preview_modal.php 43
ERROR - 2018-08-30 23:17:49 --> Severity: Notice --> Undefined offset: 0 C:\wamp64\www\gem\application\views\admin\report\preview_modal.php 57
ERROR - 2018-08-30 23:17:49 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\admin\report\preview_modal.php 57
ERROR - 2018-08-30 23:17:49 --> Severity: Notice --> Undefined offset: 0 C:\wamp64\www\gem\application\views\admin\report\preview_modal.php 75
ERROR - 2018-08-30 23:17:49 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\admin\report\preview_modal.php 75
ERROR - 2018-08-30 23:17:49 --> Severity: Notice --> Undefined offset: 0 C:\wamp64\www\gem\application\views\admin\report\preview_modal.php 87
ERROR - 2018-08-30 23:17:49 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\admin\report\preview_modal.php 87
ERROR - 2018-08-30 23:17:49 --> Severity: Notice --> Undefined offset: 0 C:\wamp64\www\gem\application\views\admin\report\preview_modal.php 87
ERROR - 2018-08-30 23:17:49 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\admin\report\preview_modal.php 87
ERROR - 2018-08-30 23:17:49 --> Severity: Notice --> Undefined offset: 0 C:\wamp64\www\gem\application\views\admin\report\preview_modal.php 87
ERROR - 2018-08-30 23:17:49 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\admin\report\preview_modal.php 87
ERROR - 2018-08-30 23:17:49 --> Severity: Notice --> Undefined offset: 0 C:\wamp64\www\gem\application\views\admin\report\preview_modal.php 99
ERROR - 2018-08-30 23:17:49 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\admin\report\preview_modal.php 99
ERROR - 2018-08-30 23:17:49 --> Severity: Notice --> Undefined offset: 0 C:\wamp64\www\gem\application\views\admin\report\preview_modal.php 111
ERROR - 2018-08-30 23:17:49 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\admin\report\preview_modal.php 111
ERROR - 2018-08-30 23:17:49 --> Severity: Notice --> Undefined offset: 0 C:\wamp64\www\gem\application\views\admin\report\preview_modal.php 123
ERROR - 2018-08-30 23:17:49 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\admin\report\preview_modal.php 123
ERROR - 2018-08-30 23:17:49 --> Severity: Notice --> Undefined offset: 0 C:\wamp64\www\gem\application\views\admin\report\preview_modal.php 135
ERROR - 2018-08-30 23:17:49 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\admin\report\preview_modal.php 135
ERROR - 2018-08-30 23:18:27 --> Severity: Notice --> Undefined offset: 0 C:\wamp64\www\gem\application\views\admin\report\preview_modal.php 10
ERROR - 2018-08-30 23:18:27 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\admin\report\preview_modal.php 10
ERROR - 2018-08-30 23:18:27 --> Severity: Notice --> Undefined offset: 0 C:\wamp64\www\gem\application\views\admin\report\preview_modal.php 21
ERROR - 2018-08-30 23:18:27 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\admin\report\preview_modal.php 21
ERROR - 2018-08-30 23:18:27 --> Severity: Notice --> Undefined offset: 0 C:\wamp64\www\gem\application\views\admin\report\preview_modal.php 32
ERROR - 2018-08-30 23:18:27 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\admin\report\preview_modal.php 32
ERROR - 2018-08-30 23:18:27 --> Severity: Notice --> Undefined offset: 0 C:\wamp64\www\gem\application\views\admin\report\preview_modal.php 43
ERROR - 2018-08-30 23:18:27 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\admin\report\preview_modal.php 43
ERROR - 2018-08-30 23:18:27 --> Severity: Notice --> Undefined offset: 0 C:\wamp64\www\gem\application\views\admin\report\preview_modal.php 57
ERROR - 2018-08-30 23:18:27 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\admin\report\preview_modal.php 57
ERROR - 2018-08-30 23:18:27 --> Severity: Notice --> Undefined offset: 0 C:\wamp64\www\gem\application\views\admin\report\preview_modal.php 75
ERROR - 2018-08-30 23:18:27 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\admin\report\preview_modal.php 75
ERROR - 2018-08-30 23:18:27 --> Severity: Notice --> Undefined offset: 0 C:\wamp64\www\gem\application\views\admin\report\preview_modal.php 87
ERROR - 2018-08-30 23:18:27 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\admin\report\preview_modal.php 87
ERROR - 2018-08-30 23:18:27 --> Severity: Notice --> Undefined offset: 0 C:\wamp64\www\gem\application\views\admin\report\preview_modal.php 87
ERROR - 2018-08-30 23:18:27 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\admin\report\preview_modal.php 87
ERROR - 2018-08-30 23:18:27 --> Severity: Notice --> Undefined offset: 0 C:\wamp64\www\gem\application\views\admin\report\preview_modal.php 87
ERROR - 2018-08-30 23:18:27 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\admin\report\preview_modal.php 87
ERROR - 2018-08-30 23:18:27 --> Severity: Notice --> Undefined offset: 0 C:\wamp64\www\gem\application\views\admin\report\preview_modal.php 99
ERROR - 2018-08-30 23:18:27 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\admin\report\preview_modal.php 99
ERROR - 2018-08-30 23:18:27 --> Severity: Notice --> Undefined offset: 0 C:\wamp64\www\gem\application\views\admin\report\preview_modal.php 111
ERROR - 2018-08-30 23:18:27 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\admin\report\preview_modal.php 111
ERROR - 2018-08-30 23:18:27 --> Severity: Notice --> Undefined offset: 0 C:\wamp64\www\gem\application\views\admin\report\preview_modal.php 123
ERROR - 2018-08-30 23:18:27 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\admin\report\preview_modal.php 123
ERROR - 2018-08-30 23:18:27 --> Severity: Notice --> Undefined offset: 0 C:\wamp64\www\gem\application\views\admin\report\preview_modal.php 135
ERROR - 2018-08-30 23:18:27 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\admin\report\preview_modal.php 135
