<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-08-26 00:46:06 --> Severity: Notice --> Undefined index: start C:\wamp64\www\gem\application\models\Article_model.php 19
ERROR - 2018-08-26 00:46:06 --> Severity: Notice --> Undefined index: length C:\wamp64\www\gem\application\models\Article_model.php 20
ERROR - 2018-08-26 00:46:06 --> Severity: Notice --> Undefined index: search C:\wamp64\www\gem\application\models\Article_model.php 21
ERROR - 2018-08-26 00:46:06 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1 - Invalid query: SELECT postid, post_title, post_date, post_published, post_url FROM tbl_posts ORDER BY postid DESC LIMIT ,  
ERROR - 2018-08-26 00:48:26 --> Severity: Notice --> Undefined property: Comment::$Comment_model C:\wamp64\www\gem\application\controllers\admin\Comment.php 51
ERROR - 2018-08-26 00:48:26 --> Severity: Error --> Call to a member function get_all_articles() on null C:\wamp64\www\gem\application\controllers\admin\Comment.php 51
ERROR - 2018-08-26 00:49:06 --> Severity: Notice --> Undefined property: Comment::$Comment_model C:\wamp64\www\gem\application\controllers\admin\Comment.php 51
ERROR - 2018-08-26 00:49:06 --> Severity: Error --> Call to a member function all_comments() on null C:\wamp64\www\gem\application\controllers\admin\Comment.php 51
ERROR - 2018-08-26 00:50:12 --> Severity: Notice --> Undefined property: Comment::$Comment_model C:\wamp64\www\gem\application\controllers\admin\Comment.php 51
ERROR - 2018-08-26 00:50:13 --> Severity: Error --> Call to a member function all_comments() on null C:\wamp64\www\gem\application\controllers\admin\Comment.php 51
ERROR - 2018-08-26 00:50:35 --> Severity: Notice --> Undefined property: Comment::$Article_model C:\wamp64\www\gem\application\controllers\admin\Comment.php 59
ERROR - 2018-08-26 00:50:35 --> Severity: Error --> Call to a member function count_all() on null C:\wamp64\www\gem\application\controllers\admin\Comment.php 59
ERROR - 2018-08-26 01:31:20 --> 404 Page Not Found: admin/Blog/comment
ERROR - 2018-08-26 01:50:30 --> 404 Page Not Found: admin/Commnet/delete
