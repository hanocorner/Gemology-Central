<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-09-09 06:52:21 --> 404 Page Not Found: Assets/css
ERROR - 2018-09-09 06:52:28 --> Severity: Notice --> Undefined variable: noOfComments C:\wamp64\www\gem\application\views\admin\profile.php 45
ERROR - 2018-09-09 06:52:28 --> Severity: Notice --> Undefined variable: total_unpaid_certificates C:\wamp64\www\gem\application\views\admin\profile.php 56
ERROR - 2018-09-09 16:36:39 --> 404 Page Not Found: Assets/css
ERROR - 2018-09-09 16:37:02 --> 404 Page Not Found: Assets/css
ERROR - 2018-09-09 16:37:11 --> Severity: Notice --> Undefined variable: noOfComments C:\wamp64\www\gem\application\views\admin\profile.php 45
ERROR - 2018-09-09 16:37:11 --> Severity: Notice --> Undefined variable: total_unpaid_certificates C:\wamp64\www\gem\application\views\admin\profile.php 56
ERROR - 2018-09-09 16:37:11 --> Severity: Notice --> Undefined variable: noOfComments C:\wamp64\www\gem\application\views\admin\profile.php 45
ERROR - 2018-09-09 16:37:11 --> Severity: Notice --> Undefined variable: total_unpaid_certificates C:\wamp64\www\gem\application\views\admin\profile.php 56
ERROR - 2018-09-09 18:02:22 --> Severity: Notice --> Undefined variable: noOfComments C:\wamp64\www\gem\application\views\admin\profile.php 45
ERROR - 2018-09-09 18:02:22 --> Severity: Notice --> Undefined variable: total_unpaid_certificates C:\wamp64\www\gem\application\views\admin\profile.php 56
ERROR - 2018-09-09 18:02:23 --> Severity: Notice --> Undefined variable: noOfComments C:\wamp64\www\gem\application\views\admin\profile.php 45
ERROR - 2018-09-09 18:02:23 --> Severity: Notice --> Undefined variable: total_unpaid_certificates C:\wamp64\www\gem\application\views\admin\profile.php 56
ERROR - 2018-09-09 18:15:08 --> Severity: Notice --> Undefined variable: noOfComments C:\wamp64\www\gem\application\views\admin\profile.php 45
ERROR - 2018-09-09 18:15:08 --> Severity: Notice --> Undefined variable: total_unpaid_certificates C:\wamp64\www\gem\application\views\admin\profile.php 56
ERROR - 2018-09-09 18:15:08 --> Severity: Notice --> Undefined variable: noOfComments C:\wamp64\www\gem\application\views\admin\profile.php 45
ERROR - 2018-09-09 18:15:08 --> Severity: Notice --> Undefined variable: total_unpaid_certificates C:\wamp64\www\gem\application\views\admin\profile.php 56
ERROR - 2018-09-09 22:07:34 --> 404 Page Not Found: Assets/css
ERROR - 2018-09-09 22:07:35 --> 404 Page Not Found: Assets/css
ERROR - 2018-09-09 22:07:38 --> Severity: Notice --> Undefined variable: noOfComments C:\wamp64\www\gem\application\views\admin\profile.php 45
ERROR - 2018-09-09 22:07:38 --> Severity: Notice --> Undefined variable: total_unpaid_certificates C:\wamp64\www\gem\application\views\admin\profile.php 56
ERROR - 2018-09-09 22:07:39 --> Severity: Notice --> Undefined variable: noOfComments C:\wamp64\www\gem\application\views\admin\profile.php 45
ERROR - 2018-09-09 22:07:39 --> Severity: Notice --> Undefined variable: total_unpaid_certificates C:\wamp64\www\gem\application\views\admin\profile.php 56
ERROR - 2018-09-09 22:14:29 --> Severity: Parsing Error --> syntax error, unexpected 'page' (T_STRING) C:\wamp64\www\gem\application\controllers\admin\Report.php 259
ERROR - 2018-09-09 22:14:30 --> Severity: Parsing Error --> syntax error, unexpected 'page' (T_STRING) C:\wamp64\www\gem\application\controllers\admin\Report.php 259
ERROR - 2018-09-09 22:42:14 --> Severity: Notice --> Undefined property: Report::$url C:\wamp64\www\gem\application\controllers\admin\Report.php 170
ERROR - 2018-09-09 22:42:14 --> Severity: Error --> Call to a member function get() on null C:\wamp64\www\gem\application\controllers\admin\Report.php 170
ERROR - 2018-09-09 22:43:31 --> Severity: Error --> Call to undefined method CI_URI::segement() C:\wamp64\www\gem\application\controllers\admin\Report.php 170
