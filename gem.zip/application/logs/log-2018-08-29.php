<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-08-29 07:05:49 --> 404 Page Not Found: Assets/css
ERROR - 2018-08-29 07:40:08 --> Query error: Unknown column 'cer_paymentStatus' in 'where clause' - Invalid query: SELECT
            (SELECT COUNT(*) FROM tbl_postcomments WHERE cmnt_status = 1) AS totalComments,
            (SELECT COUNT(*) FROM tbl_postcomments WHERE cer_paymentStatus = 0) AS totalCertificates
ERROR - 2018-08-29 07:40:41 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\controllers\admin\Profile.php 41
ERROR - 2018-08-29 07:40:41 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\controllers\admin\Profile.php 42
ERROR - 2018-08-29 07:41:41 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\controllers\admin\Profile.php 41
ERROR - 2018-08-29 07:41:42 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\controllers\admin\Profile.php 42
ERROR - 2018-08-29 08:45:07 --> 404 Page Not Found: Assets/admin
ERROR - 2018-08-29 08:45:07 --> 404 Page Not Found: Assets/admin
ERROR - 2018-08-29 08:45:07 --> 404 Page Not Found: Assets/admin
ERROR - 2018-08-29 08:45:07 --> 404 Page Not Found: Assets/admin
ERROR - 2018-08-29 08:45:10 --> 404 Page Not Found: Assets/admin
ERROR - 2018-08-29 08:45:10 --> 404 Page Not Found: Assets/admin
ERROR - 2018-08-29 08:45:10 --> 404 Page Not Found: Assets/admin
ERROR - 2018-08-29 08:45:10 --> 404 Page Not Found: Assets/admin
ERROR - 2018-08-29 08:45:28 --> 404 Page Not Found: Assets/admin
ERROR - 2018-08-29 08:45:28 --> 404 Page Not Found: Assets/admin
ERROR - 2018-08-29 08:45:29 --> 404 Page Not Found: Assets/admin
ERROR - 2018-08-29 08:45:29 --> 404 Page Not Found: Assets/admin
ERROR - 2018-08-29 09:06:33 --> 404 Page Not Found: Assets/admin
ERROR - 2018-08-29 09:06:34 --> 404 Page Not Found: Assets/admin
ERROR - 2018-08-29 09:06:34 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-29 09:06:34 --> 404 Page Not Found: Assets/js
ERROR - 2018-08-29 09:06:34 --> 404 Page Not Found: Assets/js
ERROR - 2018-08-29 09:06:34 --> 404 Page Not Found: Assets/admin
ERROR - 2018-08-29 09:06:34 --> 404 Page Not Found: Assets/admin
ERROR - 2018-08-29 09:06:34 --> 404 Page Not Found: Assets/js
ERROR - 2018-08-29 09:06:34 --> 404 Page Not Found: Assets/js
ERROR - 2018-08-29 09:12:45 --> 404 Page Not Found: admin/%3C/index
ERROR - 2018-08-29 09:13:20 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-29 09:13:20 --> 404 Page Not Found: Assets/img
ERROR - 2018-08-29 09:13:20 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-29 09:13:20 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-29 09:13:20 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-29 21:23:35 --> Severity: Notice --> Undefined index: logged_in C:\wamp64\www\gem\application\controllers\admin\Home.php 27
ERROR - 2018-08-29 21:24:51 --> 404 Page Not Found: Assets/css
