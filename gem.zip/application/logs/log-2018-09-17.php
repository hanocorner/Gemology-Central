<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-09-17 00:42:37 --> Severity: Notice --> Undefined variable: labrepoid C:\wamp64\www\gem\application\controllers\admin\Report.php 149
ERROR - 2018-09-17 00:42:37 --> Severity: Notice --> Undefined variable: id C:\wamp64\www\gem\application\controllers\admin\Report.php 149
ERROR - 2018-09-17 00:42:37 --> Severity: Notice --> Undefined variable: rep_mem_id C:\wamp64\www\gem\application\controllers\admin\Report.php 194
ERROR - 2018-09-17 00:42:37 --> Severity: Notice --> Undefined variable: labrepo_id C:\wamp64\www\gem\application\controllers\admin\Report.php 195
ERROR - 2018-09-17 00:42:37 --> Severity: Notice --> Undefined variable: repo_data C:\wamp64\www\gem\application\controllers\admin\Report.php 201
ERROR - 2018-09-17 00:47:44 --> Severity: Notice --> Undefined variable: rep_mem_id C:\wamp64\www\gem\application\controllers\admin\Report.php 194
ERROR - 2018-09-17 00:47:44 --> Severity: Notice --> Undefined variable: labrepo_id C:\wamp64\www\gem\application\controllers\admin\Report.php 195
ERROR - 2018-09-17 00:47:44 --> Severity: Notice --> Undefined variable: repo_data C:\wamp64\www\gem\application\controllers\admin\Report.php 201
ERROR - 2018-09-17 00:49:13 --> Severity: Notice --> Undefined variable: repo_data C:\wamp64\www\gem\application\controllers\admin\Report.php 201
ERROR - 2018-09-17 00:51:06 --> Severity: Parsing Error --> syntax error, unexpected 'Print' (T_PRINT), expecting identifier (T_STRING) C:\wamp64\www\gem\application\controllers\admin\Print.php 3
ERROR - 2018-09-17 00:56:51 --> Severity: Parsing Error --> syntax error, unexpected 'Print' (T_PRINT), expecting identifier (T_STRING) C:\wamp64\www\gem\application\controllers\admin\Print.php 3
ERROR - 2018-09-17 00:58:19 --> 404 Page Not Found: admin/Printp/certificate
ERROR - 2018-09-17 00:58:22 --> 404 Page Not Found: admin/Printp/certificate
ERROR - 2018-09-17 01:01:36 --> 404 Page Not Found: admin/Printp/certificate
ERROR - 2018-09-17 01:02:12 --> Severity: error --> Exception: C:\wamp64\www\gem\application\models/Print_model.php exists, but doesn't declare class Print_model C:\wamp64\www\gem\system\core\Loader.php 340
ERROR - 2018-09-17 01:02:45 --> Query error: Unknown column 't1.memoid' in 'where clause' - Invalid query: SELECT * FROM `tbl_lab_report` AS t1 INNER JOIN `tbl_gemstone_report` as t2 ON t1.reportid = t2.reportid WHERE t1.memoid = 'GCL2018-091003'
ERROR - 2018-09-17 01:03:20 --> Query error: Unknown column 't1.gsrid' in 'where clause' - Invalid query: SELECT * FROM `tbl_lab_report` AS t1 INNER JOIN `tbl_gemstone_report` as t2 ON t1.reportid = t2.reportid WHERE t1.gsrid = 'GCL2018-091003'
ERROR - 2018-09-17 01:03:42 --> Severity: Notice --> Undefined property: stdClass::$cerno C:\wamp64\www\gem\application\views\admin\lab\print\certificate_report.php 46
ERROR - 2018-09-17 01:03:42 --> Severity: Notice --> Undefined property: stdClass::$cer_date C:\wamp64\www\gem\application\views\admin\lab\print\certificate_report.php 50
ERROR - 2018-09-17 01:03:42 --> Severity: Notice --> Undefined property: stdClass::$cer_object C:\wamp64\www\gem\application\views\admin\lab\print\certificate_report.php 54
ERROR - 2018-09-17 01:03:42 --> Severity: Notice --> Undefined property: stdClass::$cer_identification C:\wamp64\www\gem\application\views\admin\lab\print\certificate_report.php 58
ERROR - 2018-09-17 01:03:42 --> Severity: Notice --> Undefined property: stdClass::$cer_weight C:\wamp64\www\gem\application\views\admin\lab\print\certificate_report.php 62
ERROR - 2018-09-17 01:03:42 --> Severity: Notice --> Undefined property: stdClass::$cer_cut C:\wamp64\www\gem\application\views\admin\lab\print\certificate_report.php 67
ERROR - 2018-09-17 01:03:42 --> Severity: Notice --> Undefined property: stdClass::$cer_gemWidth C:\wamp64\www\gem\application\views\admin\lab\print\certificate_report.php 73
ERROR - 2018-09-17 01:03:42 --> Severity: Notice --> Undefined property: stdClass::$cer_gemHeight C:\wamp64\www\gem\application\views\admin\lab\print\certificate_report.php 73
ERROR - 2018-09-17 01:03:42 --> Severity: Notice --> Undefined property: stdClass::$cer_gemLength C:\wamp64\www\gem\application\views\admin\lab\print\certificate_report.php 73
ERROR - 2018-09-17 01:03:42 --> Severity: Notice --> Undefined property: stdClass::$cer_shape C:\wamp64\www\gem\application\views\admin\lab\print\certificate_report.php 79
ERROR - 2018-09-17 01:03:42 --> Severity: Notice --> Undefined property: stdClass::$cer_color C:\wamp64\www\gem\application\views\admin\lab\print\certificate_report.php 84
ERROR - 2018-09-17 01:03:42 --> Severity: Notice --> Undefined property: stdClass::$cer_comment C:\wamp64\www\gem\application\views\admin\lab\print\certificate_report.php 89
ERROR - 2018-09-17 01:03:42 --> Severity: Notice --> Undefined property: stdClass::$cer_imagename C:\wamp64\www\gem\application\views\admin\lab\print\certificate_report.php 102
ERROR - 2018-09-17 01:29:55 --> Severity: Notice --> Undefined offset: 0 C:\wamp64\www\gem\application\views\admin\lab\print\certificate_report.php 61
ERROR - 2018-09-17 01:29:55 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\admin\lab\print\certificate_report.php 61
ERROR - 2018-09-17 01:29:55 --> Severity: Notice --> Undefined offset: 0 C:\wamp64\www\gem\application\views\admin\lab\print\certificate_report.php 65
ERROR - 2018-09-17 01:29:55 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\admin\lab\print\certificate_report.php 65
ERROR - 2018-09-17 01:29:55 --> Severity: Notice --> Undefined offset: 0 C:\wamp64\www\gem\application\views\admin\lab\print\certificate_report.php 69
ERROR - 2018-09-17 01:29:55 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\admin\lab\print\certificate_report.php 69
ERROR - 2018-09-17 01:29:56 --> Severity: Notice --> Undefined offset: 0 C:\wamp64\www\gem\application\views\admin\lab\print\certificate_report.php 73
ERROR - 2018-09-17 01:29:56 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\admin\lab\print\certificate_report.php 73
ERROR - 2018-09-17 01:29:56 --> Severity: Notice --> Undefined offset: 0 C:\wamp64\www\gem\application\views\admin\lab\print\certificate_report.php 77
ERROR - 2018-09-17 01:29:56 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\admin\lab\print\certificate_report.php 77
ERROR - 2018-09-17 01:29:56 --> Severity: Notice --> Undefined offset: 0 C:\wamp64\www\gem\application\views\admin\lab\print\certificate_report.php 82
ERROR - 2018-09-17 01:29:56 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\admin\lab\print\certificate_report.php 82
ERROR - 2018-09-17 01:29:56 --> Severity: Notice --> Undefined offset: 0 C:\wamp64\www\gem\application\views\admin\lab\print\certificate_report.php 88
ERROR - 2018-09-17 01:29:56 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\admin\lab\print\certificate_report.php 88
ERROR - 2018-09-17 01:29:56 --> Severity: Notice --> Undefined offset: 0 C:\wamp64\www\gem\application\views\admin\lab\print\certificate_report.php 88
ERROR - 2018-09-17 01:29:56 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\admin\lab\print\certificate_report.php 88
ERROR - 2018-09-17 01:29:56 --> Severity: Notice --> Undefined offset: 0 C:\wamp64\www\gem\application\views\admin\lab\print\certificate_report.php 88
ERROR - 2018-09-17 01:29:56 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\admin\lab\print\certificate_report.php 88
ERROR - 2018-09-17 01:29:56 --> Severity: Notice --> Undefined offset: 0 C:\wamp64\www\gem\application\views\admin\lab\print\certificate_report.php 94
ERROR - 2018-09-17 01:29:56 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\admin\lab\print\certificate_report.php 94
ERROR - 2018-09-17 01:29:56 --> Severity: Notice --> Undefined offset: 0 C:\wamp64\www\gem\application\views\admin\lab\print\certificate_report.php 99
ERROR - 2018-09-17 01:29:56 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\admin\lab\print\certificate_report.php 99
ERROR - 2018-09-17 01:29:56 --> Severity: Notice --> Undefined offset: 0 C:\wamp64\www\gem\application\views\admin\lab\print\certificate_report.php 104
ERROR - 2018-09-17 01:29:56 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\admin\lab\print\certificate_report.php 104
ERROR - 2018-09-17 01:29:56 --> Severity: Notice --> Undefined offset: 0 C:\wamp64\www\gem\application\views\admin\lab\print\certificate_report.php 117
ERROR - 2018-09-17 01:29:56 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\admin\lab\print\certificate_report.php 117
ERROR - 2018-09-17 03:17:19 --> Severity: Notice --> Undefined property: Report::$Gem_model C:\wamp64\www\gem\application\controllers\admin\Report.php 244
ERROR - 2018-09-17 03:17:19 --> Severity: Error --> Call to a member function insert_gem() on null C:\wamp64\www\gem\application\controllers\admin\Report.php 244
ERROR - 2018-09-17 03:40:54 --> Severity: Notice --> Undefined property: Gemstone::$Lab_model C:\wamp64\www\gem\application\controllers\admin\Gemstone.php 57
ERROR - 2018-09-17 03:40:55 --> Severity: Error --> Call to a member function get_gem_list() on null C:\wamp64\www\gem\application\controllers\admin\Gemstone.php 57
ERROR - 2018-09-17 07:28:54 --> 404 Page Not Found: admin/Bootstrapbundleminjsmap/index
ERROR - 2018-09-17 08:37:14 --> Severity: Notice --> Undefined index: id C:\wamp64\www\gem\application\controllers\admin\Customer.php 141
ERROR - 2018-09-17 21:06:57 --> Query error: Unknown column 't1.memoid' in 'where clause' - Invalid query: SELECT * FROM `tbl_gemstone_report` AS t1 INNER JOIN `tbl_lab_report` AS t2 ON t1.reportid = t2.reportid WHERE t1.memoid = 'GCL2018-091005'
ERROR - 2018-09-17 21:08:18 --> Severity: Notice --> Undefined property: stdClass::$mem_amount C:\wamp64\www\gem\application\views\admin\lab\report\edit.php 85
ERROR - 2018-09-17 21:23:32 --> Severity: Notice --> Undefined property: stdClass::$mem_amount C:\wamp64\www\gem\application\views\admin\lab\report\edit.php 91
ERROR - 2018-09-17 21:23:56 --> Severity: Notice --> Undefined property: stdClass::$mem_amount C:\wamp64\www\gem\application\views\admin\lab\report\edit.php 91
ERROR - 2018-09-17 21:25:20 --> Severity: Notice --> Undefined property: stdClass::$mem_amount C:\wamp64\www\gem\application\views\admin\lab\report\edit.php 91
ERROR - 2018-09-17 21:39:43 --> Severity: Notice --> Undefined property: stdClass::$mem_amount C:\wamp64\www\gem\application\views\admin\lab\report\edit.php 105
