<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-08-31 07:04:40 --> 404 Page Not Found: Assets/css
ERROR - 2018-08-31 07:04:55 --> Severity: Notice --> Undefined offset: 0 C:\wamp64\www\gem\application\views\admin\report\preview_modal.php 10
ERROR - 2018-08-31 07:04:55 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\admin\report\preview_modal.php 10
ERROR - 2018-08-31 07:04:55 --> Severity: Notice --> Undefined offset: 0 C:\wamp64\www\gem\application\views\admin\report\preview_modal.php 21
ERROR - 2018-08-31 07:04:55 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\admin\report\preview_modal.php 21
ERROR - 2018-08-31 07:04:55 --> Severity: Notice --> Undefined offset: 0 C:\wamp64\www\gem\application\views\admin\report\preview_modal.php 32
ERROR - 2018-08-31 07:04:55 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\admin\report\preview_modal.php 32
ERROR - 2018-08-31 07:04:55 --> Severity: Notice --> Undefined offset: 0 C:\wamp64\www\gem\application\views\admin\report\preview_modal.php 43
ERROR - 2018-08-31 07:04:55 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\admin\report\preview_modal.php 43
ERROR - 2018-08-31 07:04:55 --> Severity: Notice --> Undefined offset: 0 C:\wamp64\www\gem\application\views\admin\report\preview_modal.php 57
ERROR - 2018-08-31 07:04:55 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\admin\report\preview_modal.php 57
ERROR - 2018-08-31 07:04:55 --> Severity: Notice --> Undefined offset: 0 C:\wamp64\www\gem\application\views\admin\report\preview_modal.php 75
ERROR - 2018-08-31 07:04:55 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\admin\report\preview_modal.php 75
ERROR - 2018-08-31 07:04:55 --> Severity: Notice --> Undefined offset: 0 C:\wamp64\www\gem\application\views\admin\report\preview_modal.php 87
ERROR - 2018-08-31 07:04:55 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\admin\report\preview_modal.php 87
ERROR - 2018-08-31 07:04:55 --> Severity: Notice --> Undefined offset: 0 C:\wamp64\www\gem\application\views\admin\report\preview_modal.php 87
ERROR - 2018-08-31 07:04:55 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\admin\report\preview_modal.php 87
ERROR - 2018-08-31 07:04:55 --> Severity: Notice --> Undefined offset: 0 C:\wamp64\www\gem\application\views\admin\report\preview_modal.php 87
ERROR - 2018-08-31 07:04:55 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\admin\report\preview_modal.php 87
ERROR - 2018-08-31 07:04:55 --> Severity: Notice --> Undefined offset: 0 C:\wamp64\www\gem\application\views\admin\report\preview_modal.php 99
ERROR - 2018-08-31 07:04:55 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\admin\report\preview_modal.php 99
ERROR - 2018-08-31 07:04:55 --> Severity: Notice --> Undefined offset: 0 C:\wamp64\www\gem\application\views\admin\report\preview_modal.php 111
ERROR - 2018-08-31 07:04:55 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\admin\report\preview_modal.php 111
ERROR - 2018-08-31 07:04:55 --> Severity: Notice --> Undefined offset: 0 C:\wamp64\www\gem\application\views\admin\report\preview_modal.php 123
ERROR - 2018-08-31 07:04:55 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\admin\report\preview_modal.php 123
ERROR - 2018-08-31 07:04:55 --> Severity: Notice --> Undefined offset: 0 C:\wamp64\www\gem\application\views\admin\report\preview_modal.php 135
ERROR - 2018-08-31 07:04:55 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\admin\report\preview_modal.php 135
ERROR - 2018-08-31 07:05:06 --> Severity: Notice --> Undefined offset: 0 C:\wamp64\www\gem\application\views\admin\report\preview_modal.php 10
ERROR - 2018-08-31 07:05:06 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\admin\report\preview_modal.php 10
ERROR - 2018-08-31 07:05:06 --> Severity: Notice --> Undefined offset: 0 C:\wamp64\www\gem\application\views\admin\report\preview_modal.php 21
ERROR - 2018-08-31 07:05:06 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\admin\report\preview_modal.php 21
ERROR - 2018-08-31 07:05:06 --> Severity: Notice --> Undefined offset: 0 C:\wamp64\www\gem\application\views\admin\report\preview_modal.php 32
ERROR - 2018-08-31 07:05:06 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\admin\report\preview_modal.php 32
ERROR - 2018-08-31 07:05:06 --> Severity: Notice --> Undefined offset: 0 C:\wamp64\www\gem\application\views\admin\report\preview_modal.php 43
ERROR - 2018-08-31 07:05:06 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\admin\report\preview_modal.php 43
ERROR - 2018-08-31 07:05:06 --> Severity: Notice --> Undefined offset: 0 C:\wamp64\www\gem\application\views\admin\report\preview_modal.php 57
ERROR - 2018-08-31 07:05:06 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\admin\report\preview_modal.php 57
ERROR - 2018-08-31 07:05:06 --> Severity: Notice --> Undefined offset: 0 C:\wamp64\www\gem\application\views\admin\report\preview_modal.php 75
ERROR - 2018-08-31 07:05:06 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\admin\report\preview_modal.php 75
ERROR - 2018-08-31 07:05:06 --> Severity: Notice --> Undefined offset: 0 C:\wamp64\www\gem\application\views\admin\report\preview_modal.php 87
ERROR - 2018-08-31 07:05:06 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\admin\report\preview_modal.php 87
ERROR - 2018-08-31 07:05:06 --> Severity: Notice --> Undefined offset: 0 C:\wamp64\www\gem\application\views\admin\report\preview_modal.php 87
ERROR - 2018-08-31 07:05:06 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\admin\report\preview_modal.php 87
ERROR - 2018-08-31 07:05:06 --> Severity: Notice --> Undefined offset: 0 C:\wamp64\www\gem\application\views\admin\report\preview_modal.php 87
ERROR - 2018-08-31 07:05:06 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\admin\report\preview_modal.php 87
ERROR - 2018-08-31 07:05:06 --> Severity: Notice --> Undefined offset: 0 C:\wamp64\www\gem\application\views\admin\report\preview_modal.php 99
ERROR - 2018-08-31 07:05:06 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\admin\report\preview_modal.php 99
ERROR - 2018-08-31 07:05:06 --> Severity: Notice --> Undefined offset: 0 C:\wamp64\www\gem\application\views\admin\report\preview_modal.php 111
ERROR - 2018-08-31 07:05:06 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\admin\report\preview_modal.php 111
ERROR - 2018-08-31 07:05:06 --> Severity: Notice --> Undefined offset: 0 C:\wamp64\www\gem\application\views\admin\report\preview_modal.php 123
ERROR - 2018-08-31 07:05:06 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\admin\report\preview_modal.php 123
ERROR - 2018-08-31 07:05:06 --> Severity: Notice --> Undefined offset: 0 C:\wamp64\www\gem\application\views\admin\report\preview_modal.php 135
ERROR - 2018-08-31 07:05:07 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\admin\report\preview_modal.php 135
ERROR - 2018-08-31 07:05:36 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\admin\report\preview_modal.php 10
ERROR - 2018-08-31 07:05:36 --> Severity: Notice --> Undefined offset: 0 C:\wamp64\www\gem\application\views\admin\report\preview_modal.php 21
ERROR - 2018-08-31 07:05:36 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\admin\report\preview_modal.php 21
ERROR - 2018-08-31 07:05:36 --> Severity: Notice --> Undefined offset: 0 C:\wamp64\www\gem\application\views\admin\report\preview_modal.php 32
ERROR - 2018-08-31 07:05:36 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\admin\report\preview_modal.php 32
ERROR - 2018-08-31 07:05:36 --> Severity: Notice --> Undefined offset: 0 C:\wamp64\www\gem\application\views\admin\report\preview_modal.php 43
ERROR - 2018-08-31 07:05:36 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\admin\report\preview_modal.php 43
ERROR - 2018-08-31 07:05:36 --> Severity: Notice --> Undefined offset: 0 C:\wamp64\www\gem\application\views\admin\report\preview_modal.php 57
ERROR - 2018-08-31 07:05:37 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\admin\report\preview_modal.php 57
ERROR - 2018-08-31 07:05:37 --> Severity: Notice --> Undefined offset: 0 C:\wamp64\www\gem\application\views\admin\report\preview_modal.php 75
ERROR - 2018-08-31 07:05:37 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\admin\report\preview_modal.php 75
ERROR - 2018-08-31 07:05:37 --> Severity: Notice --> Undefined offset: 0 C:\wamp64\www\gem\application\views\admin\report\preview_modal.php 87
ERROR - 2018-08-31 07:05:37 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\admin\report\preview_modal.php 87
ERROR - 2018-08-31 07:05:37 --> Severity: Notice --> Undefined offset: 0 C:\wamp64\www\gem\application\views\admin\report\preview_modal.php 87
ERROR - 2018-08-31 07:05:37 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\admin\report\preview_modal.php 87
ERROR - 2018-08-31 07:05:37 --> Severity: Notice --> Undefined offset: 0 C:\wamp64\www\gem\application\views\admin\report\preview_modal.php 87
ERROR - 2018-08-31 07:05:37 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\admin\report\preview_modal.php 87
ERROR - 2018-08-31 07:05:37 --> Severity: Notice --> Undefined offset: 0 C:\wamp64\www\gem\application\views\admin\report\preview_modal.php 99
ERROR - 2018-08-31 07:05:37 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\admin\report\preview_modal.php 99
ERROR - 2018-08-31 07:05:37 --> Severity: Notice --> Undefined offset: 0 C:\wamp64\www\gem\application\views\admin\report\preview_modal.php 111
ERROR - 2018-08-31 07:05:37 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\admin\report\preview_modal.php 111
ERROR - 2018-08-31 07:05:37 --> Severity: Notice --> Undefined offset: 0 C:\wamp64\www\gem\application\views\admin\report\preview_modal.php 123
ERROR - 2018-08-31 07:05:37 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\admin\report\preview_modal.php 123
ERROR - 2018-08-31 07:05:37 --> Severity: Notice --> Undefined offset: 0 C:\wamp64\www\gem\application\views\admin\report\preview_modal.php 135
ERROR - 2018-08-31 07:05:37 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\admin\report\preview_modal.php 135
ERROR - 2018-08-31 07:09:30 --> Severity: Error --> Cannot use object of type stdClass as array C:\wamp64\www\gem\application\views\admin\report\preview_modal.php 21
ERROR - 2018-08-31 07:10:22 --> Severity: Error --> Cannot use object of type stdClass as array C:\wamp64\www\gem\application\views\admin\report\preview_modal.php 32
ERROR - 2018-08-31 07:11:16 --> 404 Page Not Found: Assets/img
ERROR - 2018-08-31 07:12:31 --> 404 Page Not Found: Assets/img
ERROR - 2018-08-31 07:15:43 --> 404 Page Not Found: Assets/img
ERROR - 2018-08-31 07:16:21 --> 404 Page Not Found: Assets/img
ERROR - 2018-08-31 07:17:31 --> 404 Page Not Found: Assets/img
ERROR - 2018-08-31 07:19:15 --> 404 Page Not Found: Assets/img
ERROR - 2018-08-31 07:24:08 --> 404 Page Not Found: Assets/img
ERROR - 2018-08-31 07:26:14 --> 404 Page Not Found: Assets/img
ERROR - 2018-08-31 07:34:10 --> 404 Page Not Found: Assets/img
ERROR - 2018-08-31 07:35:12 --> 404 Page Not Found: Assets/img
ERROR - 2018-08-31 07:36:41 --> 404 Page Not Found: Assets/img
ERROR - 2018-08-31 07:38:01 --> 404 Page Not Found: Assets/img
ERROR - 2018-08-31 07:38:05 --> 404 Page Not Found: Assets/img
ERROR - 2018-08-31 08:39:35 --> 404 Page Not Found: Assets/img
ERROR - 2018-08-31 08:39:38 --> 404 Page Not Found: Assets/img
ERROR - 2018-08-31 08:40:03 --> 404 Page Not Found: Assets/img
ERROR - 2018-08-31 08:40:05 --> 404 Page Not Found: Assets/img
ERROR - 2018-08-31 08:40:08 --> 404 Page Not Found: Assets/img
ERROR - 2018-08-31 08:40:12 --> 404 Page Not Found: Assets/img
ERROR - 2018-08-31 09:12:49 --> 404 Page Not Found: Assets/img
ERROR - 2018-08-31 09:12:58 --> 404 Page Not Found: Assets/img
ERROR - 2018-08-31 09:13:00 --> 404 Page Not Found: Assets/img
ERROR - 2018-08-31 09:13:03 --> 404 Page Not Found: Assets/img
ERROR - 2018-08-31 09:14:08 --> 404 Page Not Found: admin/%3C/index
ERROR - 2018-08-31 10:04:53 --> 404 Page Not Found: Assets/img
ERROR - 2018-08-31 10:50:19 --> Severity: Warning --> imagepng(assets/img/qr/GCL2018-071004.png): failed to open stream: No such file or directory C:\wamp64\www\gem\application\libraries\qrcode\qrimage.php 46
ERROR - 2018-08-31 10:50:19 --> 404 Page Not Found: Assets/css
ERROR - 2018-08-31 10:50:19 --> 404 Page Not Found: Assets/img
ERROR - 2018-08-31 10:50:19 --> 404 Page Not Found: Assets/img
ERROR - 2018-08-31 10:50:19 --> 404 Page Not Found: Assets/img
ERROR - 2018-08-31 10:50:19 --> 404 Page Not Found: Assets/img
ERROR - 2018-08-31 10:56:00 --> Severity: Warning --> imagepng(assets/img/qr/GCL2018-071004.png): failed to open stream: No such file or directory C:\wamp64\www\gem\application\libraries\qrcode\qrimage.php 46
ERROR - 2018-08-31 10:56:00 --> 404 Page Not Found: Assets/img
ERROR - 2018-08-31 10:56:00 --> 404 Page Not Found: Assets/css
ERROR - 2018-08-31 10:56:00 --> 404 Page Not Found: Assets/admin
ERROR - 2018-08-31 10:56:01 --> 404 Page Not Found: Assets/img
ERROR - 2018-08-31 10:56:01 --> 404 Page Not Found: Assets/admin
ERROR - 2018-08-31 11:04:06 --> 404 Page Not Found: admin/Blog/add_customer
ERROR - 2018-08-31 11:04:53 --> 404 Page Not Found: admin/Report/add_customer
ERROR - 2018-08-31 11:06:30 --> 404 Page Not Found: Assets/img
ERROR - 2018-08-31 11:12:04 --> 404 Page Not Found: Assets/img
ERROR - 2018-08-31 11:50:57 --> 404 Page Not Found: Assets/img
ERROR - 2018-08-31 11:54:44 --> 404 Page Not Found: Assets/img
ERROR - 2018-08-31 12:17:26 --> The upload path does not appear to be valid.
ERROR - 2018-08-31 12:17:26 --> Severity: Notice --> Undefined variable: cstid C:\wamp64\www\gem\application\views\admin\report\add_gemstone.php 32
ERROR - 2018-08-31 12:20:14 --> The upload path does not appear to be valid.
ERROR - 2018-08-31 12:20:14 --> Severity: Notice --> Undefined variable: cstid C:\wamp64\www\gem\application\views\admin\report\add_gemstone.php 32
ERROR - 2018-08-31 12:29:41 --> The upload path does not appear to be valid.
ERROR - 2018-08-31 12:31:43 --> The upload path does not appear to be valid.
ERROR - 2018-08-31 12:31:43 --> Query error: Column 'cerno' cannot be null - Invalid query: INSERT INTO `tbl_certificate` (`cerno`, `cer_date`, `cer_object`, `cer_type`, `cer_identification`, `cer_weight`, `cer_gemWidth`, `cer_gemHeight`, `cer_gemlength`, `cer_cut`, `cer_shape`, `cer_color`, `cer_comment`, `customerID`, `cer_imagename`) VALUES (NULL, '2018-08-31', 'three', 'cert-report', 'diffusion', '8.50', '12.37', '9.64', '8.84', 'modified', 'oval', 'blue', 'dell', '10', '.jpg')
ERROR - 2018-08-31 12:35:27 --> The upload path does not appear to be valid.
ERROR - 2018-08-31 12:40:01 --> 404 Page Not Found: Assets/img
ERROR - 2018-08-31 12:45:44 --> 404 Page Not Found: Assets/img
ERROR - 2018-08-31 12:46:14 --> 404 Page Not Found: Assets/admin
ERROR - 2018-08-31 12:46:19 --> 404 Page Not Found: Assets/admin
ERROR - 2018-08-31 12:47:01 --> 404 Page Not Found: Assets/img
ERROR - 2018-08-31 12:47:06 --> The upload path does not appear to be valid.
ERROR - 2018-08-31 12:51:45 --> 404 Page Not Found: Assets/css
ERROR - 2018-08-31 12:51:45 --> 404 Page Not Found: Assets/img
ERROR - 2018-08-31 12:52:38 --> 404 Page Not Found: Assets/css
ERROR - 2018-08-31 12:52:38 --> 404 Page Not Found: Assets/img
ERROR - 2018-08-31 12:52:38 --> 404 Page Not Found: Assets/public
ERROR - 2018-08-31 13:01:34 --> 404 Page Not Found: Assets/css
ERROR - 2018-08-31 13:01:34 --> 404 Page Not Found: Assets/public
ERROR - 2018-08-31 13:01:34 --> 404 Page Not Found: Assets/img
ERROR - 2018-08-31 13:02:06 --> 404 Page Not Found: Assets/css
ERROR - 2018-08-31 13:02:06 --> 404 Page Not Found: Assets/public
ERROR - 2018-08-31 13:02:06 --> 404 Page Not Found: Assets/img
ERROR - 2018-08-31 13:02:13 --> 404 Page Not Found: Assets/css
ERROR - 2018-08-31 13:03:10 --> 404 Page Not Found: Assets/public
ERROR - 2018-08-31 13:03:10 --> 404 Page Not Found: Assets/img
ERROR - 2018-08-31 13:19:46 --> 404 Page Not Found: Assets/img
ERROR - 2018-08-31 13:22:46 --> 404 Page Not Found: Assets/img
ERROR - 2018-08-31 13:30:33 --> 404 Page Not Found: Assets/img
ERROR - 2018-08-31 13:31:38 --> 404 Page Not Found: Assets/img
ERROR - 2018-08-31 13:31:38 --> 404 Page Not Found: Assets/admin
ERROR - 2018-08-31 13:31:38 --> 404 Page Not Found: Assets/admin
ERROR - 2018-08-31 13:40:12 --> 404 Page Not Found: Assets/admin
ERROR - 2018-08-31 13:40:12 --> 404 Page Not Found: Assets/admin
ERROR - 2018-08-31 13:43:21 --> 404 Page Not Found: Assets/admin
ERROR - 2018-08-31 13:43:21 --> 404 Page Not Found: Assets/admin
ERROR - 2018-08-31 13:44:53 --> 404 Page Not Found: Assets/admin
ERROR - 2018-08-31 13:44:54 --> 404 Page Not Found: Assets/admin
ERROR - 2018-08-31 13:46:13 --> 404 Page Not Found: Assets/admin
ERROR - 2018-08-31 13:46:13 --> 404 Page Not Found: Assets/admin
ERROR - 2018-08-31 13:46:18 --> 404 Page Not Found: Assets/admin
ERROR - 2018-08-31 13:46:18 --> 404 Page Not Found: Assets/admin
ERROR - 2018-08-31 13:46:46 --> 404 Page Not Found: Assets/admin
ERROR - 2018-08-31 13:46:48 --> 404 Page Not Found: Assets/admin
ERROR - 2018-08-31 13:46:50 --> 404 Page Not Found: Assets/admin
ERROR - 2018-08-31 13:46:50 --> 404 Page Not Found: Assets/admin
ERROR - 2018-08-31 13:47:39 --> 404 Page Not Found: Assets/admin
ERROR - 2018-08-31 13:47:39 --> 404 Page Not Found: Assets/admin
ERROR - 2018-08-31 13:47:46 --> 404 Page Not Found: Assets/admin
ERROR - 2018-08-31 13:47:46 --> 404 Page Not Found: Assets/admin
ERROR - 2018-08-31 13:47:54 --> 404 Page Not Found: Assets/admin
ERROR - 2018-08-31 13:47:54 --> 404 Page Not Found: Assets/admin
ERROR - 2018-08-31 13:48:35 --> 404 Page Not Found: Assets/admin
ERROR - 2018-08-31 13:48:35 --> 404 Page Not Found: Assets/admin
ERROR - 2018-08-31 13:48:47 --> 404 Page Not Found: Assets/admin
ERROR - 2018-08-31 13:48:47 --> 404 Page Not Found: Assets/admin
ERROR - 2018-08-31 13:48:50 --> 404 Page Not Found: Assets/admin
ERROR - 2018-08-31 13:48:51 --> 404 Page Not Found: Assets/admin
ERROR - 2018-08-31 13:49:25 --> 404 Page Not Found: Assets/admin
ERROR - 2018-08-31 13:49:25 --> 404 Page Not Found: Assets/admin
ERROR - 2018-08-31 13:49:27 --> 404 Page Not Found: Assets/admin
ERROR - 2018-08-31 13:49:28 --> 404 Page Not Found: Assets/admin
ERROR - 2018-08-31 13:49:48 --> 404 Page Not Found: Assets/admin
ERROR - 2018-08-31 13:49:48 --> 404 Page Not Found: Assets/admin
ERROR - 2018-08-31 13:49:54 --> 404 Page Not Found: Assets/admin
ERROR - 2018-08-31 13:49:54 --> 404 Page Not Found: Assets/admin
ERROR - 2018-08-31 13:50:06 --> 404 Page Not Found: Assets/admin
ERROR - 2018-08-31 13:50:07 --> 404 Page Not Found: Assets/admin
ERROR - 2018-08-31 13:50:10 --> 404 Page Not Found: Assets/admin
ERROR - 2018-08-31 13:50:10 --> 404 Page Not Found: Assets/admin
ERROR - 2018-08-31 16:57:28 --> The upload path does not appear to be valid.
ERROR - 2018-08-31 16:59:49 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-31 16:59:49 --> 404 Page Not Found: Assets/img
ERROR - 2018-08-31 16:59:49 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-31 16:59:49 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-31 16:59:49 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-31 16:59:50 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-31 17:01:27 --> 404 Page Not Found: Assets/img
ERROR - 2018-08-31 17:01:27 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-31 17:01:27 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-31 17:01:27 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-31 17:01:27 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-31 17:01:31 --> 404 Page Not Found: Assets/admin
ERROR - 2018-08-31 17:01:31 --> 404 Page Not Found: Assets/admin
ERROR - 2018-08-31 17:01:31 --> 404 Page Not Found: Assets/js
ERROR - 2018-08-31 17:01:31 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-31 17:01:31 --> 404 Page Not Found: Assets/js
ERROR - 2018-08-31 17:01:31 --> 404 Page Not Found: Assets/admin
ERROR - 2018-08-31 17:01:31 --> 404 Page Not Found: Assets/admin
ERROR - 2018-08-31 17:01:31 --> 404 Page Not Found: Assets/js
ERROR - 2018-08-31 17:01:31 --> 404 Page Not Found: Assets/js
ERROR - 2018-08-31 17:09:10 --> The upload path does not appear to be valid.
ERROR - 2018-08-31 17:09:14 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-31 17:09:14 --> 404 Page Not Found: Assets/img
ERROR - 2018-08-31 17:09:14 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-31 17:09:15 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-31 17:09:15 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-31 17:19:02 --> 404 Page Not Found: Assets/js
ERROR - 2018-08-31 17:19:02 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-31 17:19:02 --> 404 Page Not Found: Assets/js
ERROR - 2018-08-31 17:19:03 --> 404 Page Not Found: Assets/js
ERROR - 2018-08-31 17:19:03 --> 404 Page Not Found: Assets/js
ERROR - 2018-08-31 17:19:05 --> 404 Page Not Found: Assets/admin
ERROR - 2018-08-31 17:19:05 --> 404 Page Not Found: Assets/admin
ERROR - 2018-08-31 17:19:05 --> 404 Page Not Found: Assets/js
ERROR - 2018-08-31 17:19:05 --> 404 Page Not Found: Assets/admin
ERROR - 2018-08-31 17:19:05 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-31 17:19:05 --> 404 Page Not Found: Assets/admin
ERROR - 2018-08-31 17:19:05 --> 404 Page Not Found: Assets/admin
ERROR - 2018-08-31 17:19:05 --> 404 Page Not Found: Assets/admin
ERROR - 2018-08-31 17:19:05 --> 404 Page Not Found: Assets/js
ERROR - 2018-08-31 17:19:05 --> 404 Page Not Found: Assets/admin
ERROR - 2018-08-31 17:19:05 --> 404 Page Not Found: Assets/admin
ERROR - 2018-08-31 17:19:06 --> 404 Page Not Found: Assets/admin
ERROR - 2018-08-31 17:19:06 --> 404 Page Not Found: Assets/admin
ERROR - 2018-08-31 17:19:06 --> 404 Page Not Found: Assets/admin
ERROR - 2018-08-31 17:19:06 --> 404 Page Not Found: Assets/admin
ERROR - 2018-08-31 17:19:06 --> 404 Page Not Found: Assets/js
ERROR - 2018-08-31 17:19:06 --> 404 Page Not Found: Assets/js
ERROR - 2018-08-31 17:20:59 --> 404 Page Not Found: Assets/js
ERROR - 2018-08-31 17:20:59 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-31 17:20:59 --> 404 Page Not Found: Assets/js
ERROR - 2018-08-31 17:20:59 --> 404 Page Not Found: Assets/js
ERROR - 2018-08-31 17:20:59 --> 404 Page Not Found: Assets/js
ERROR - 2018-08-31 17:29:39 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-31 17:29:39 --> 404 Page Not Found: Assets/img
ERROR - 2018-08-31 17:29:39 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-31 17:29:39 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-31 17:31:21 --> The upload path does not appear to be valid.
ERROR - 2018-08-31 17:31:25 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-31 17:31:25 --> 404 Page Not Found: Assets/img
ERROR - 2018-08-31 17:31:25 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-31 17:31:26 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-31 17:31:26 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-31 17:31:30 --> 404 Page Not Found: Assets/img
ERROR - 2018-08-31 17:31:30 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-31 17:31:30 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-31 17:31:30 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-31 17:31:31 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-31 17:31:31 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-31 17:31:35 --> 404 Page Not Found: Assets/js
ERROR - 2018-08-31 17:31:35 --> 404 Page Not Found: Assets/public
ERROR - 2018-08-31 17:31:35 --> 404 Page Not Found: Assets/js
ERROR - 2018-08-31 17:31:36 --> 404 Page Not Found: Assets/js
ERROR - 2018-08-31 17:31:36 --> 404 Page Not Found: Assets/js
ERROR - 2018-08-31 17:38:46 --> 404 Page Not Found: Assets/img
ERROR - 2018-08-31 17:38:46 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-31 17:38:46 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-31 17:38:46 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-31 17:38:46 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-31 17:38:50 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-31 17:38:50 --> 404 Page Not Found: Assets/img
ERROR - 2018-08-31 17:38:50 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-31 17:38:50 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-31 17:38:50 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-31 17:38:50 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-31 17:38:50 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-31 17:38:50 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-31 17:38:50 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-31 17:38:50 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-31 17:38:50 --> 404 Page Not Found: Assets/public
ERROR - 2018-08-31 17:43:49 --> 404 Page Not Found: Assets/img
ERROR - 2018-08-31 17:43:49 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-31 17:43:49 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-31 17:43:50 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-31 17:43:50 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-31 17:44:10 --> 404 Page Not Found: Assets/js
ERROR - 2018-08-31 17:44:10 --> 404 Page Not Found: Assets/js
ERROR - 2018-08-31 17:44:10 --> 404 Page Not Found: Assets/js
ERROR - 2018-08-31 17:44:10 --> 404 Page Not Found: Assets/js
ERROR - 2018-08-31 17:45:48 --> 404 Page Not Found: Assets/img
ERROR - 2018-08-31 17:45:48 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-31 17:45:48 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-31 17:45:48 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-31 17:46:41 --> 404 Page Not Found: Assets/img
ERROR - 2018-08-31 17:46:41 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-31 17:46:41 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-31 17:46:41 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-31 17:46:41 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-31 17:47:31 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-31 17:47:31 --> 404 Page Not Found: Assets/img
ERROR - 2018-08-31 17:55:11 --> 404 Page Not Found: Assets/js
ERROR - 2018-08-31 17:55:11 --> 404 Page Not Found: Assets/js
ERROR - 2018-08-31 17:55:12 --> 404 Page Not Found: Assets/js
ERROR - 2018-08-31 17:55:12 --> 404 Page Not Found: Assets/js
ERROR - 2018-08-31 18:05:56 --> Severity: Notice --> Undefined property: stdClass::$topArticle C:\wamp64\www\gem\application\controllers\admin\Blog.php 246
ERROR - 2018-08-31 18:05:56 --> 404 Page Not Found: Assets/js
ERROR - 2018-08-31 18:05:56 --> 404 Page Not Found: Assets/js
ERROR - 2018-08-31 18:05:57 --> 404 Page Not Found: Assets/js
ERROR - 2018-08-31 18:05:57 --> Severity: Notice --> Undefined property: stdClass::$topArticle C:\wamp64\www\gem\application\controllers\admin\Blog.php 246
ERROR - 2018-08-31 18:05:57 --> 404 Page Not Found: Assets/js
ERROR - 2018-08-31 18:07:12 --> Severity: Notice --> Undefined property: stdClass::$topArticle C:\wamp64\www\gem\application\controllers\admin\Blog.php 246
ERROR - 2018-08-31 18:07:12 --> 404 Page Not Found: Assets/js
ERROR - 2018-08-31 18:07:12 --> 404 Page Not Found: Assets/js
ERROR - 2018-08-31 18:07:13 --> Severity: Notice --> Undefined property: stdClass::$topArticle C:\wamp64\www\gem\application\controllers\admin\Blog.php 246
ERROR - 2018-08-31 18:07:13 --> 404 Page Not Found: Assets/js
ERROR - 2018-08-31 18:07:13 --> 404 Page Not Found: Assets/js
ERROR - 2018-08-31 18:07:32 --> 404 Page Not Found: Assets/js
ERROR - 2018-08-31 18:07:32 --> 404 Page Not Found: Assets/js
ERROR - 2018-08-31 18:07:32 --> 404 Page Not Found: Assets/js
ERROR - 2018-08-31 18:07:33 --> 404 Page Not Found: Assets/js
ERROR - 2018-08-31 18:08:19 --> 404 Page Not Found: Assets/js
ERROR - 2018-08-31 18:08:19 --> 404 Page Not Found: Assets/js
ERROR - 2018-08-31 18:08:19 --> 404 Page Not Found: Assets/js
ERROR - 2018-08-31 18:08:19 --> 404 Page Not Found: Assets/js
ERROR - 2018-08-31 18:13:27 --> 404 Page Not Found: Assets/js
ERROR - 2018-08-31 18:13:27 --> 404 Page Not Found: Assets/js
ERROR - 2018-08-31 18:13:28 --> 404 Page Not Found: Assets/js
ERROR - 2018-08-31 18:13:28 --> 404 Page Not Found: Assets/js
ERROR - 2018-08-31 18:25:51 --> 404 Page Not Found: Assets/js
ERROR - 2018-08-31 18:25:51 --> 404 Page Not Found: Assets/js
ERROR - 2018-08-31 18:25:52 --> 404 Page Not Found: Assets/js
ERROR - 2018-08-31 18:25:52 --> 404 Page Not Found: Assets/js
ERROR - 2018-08-31 18:27:58 --> 404 Page Not Found: Assets/js
ERROR - 2018-08-31 18:27:58 --> 404 Page Not Found: Assets/js
ERROR - 2018-08-31 18:27:58 --> 404 Page Not Found: Assets/js
ERROR - 2018-08-31 18:27:58 --> 404 Page Not Found: Assets/js
ERROR - 2018-08-31 19:04:46 --> Query error: Unknown column 'asiri' in 'where clause' - Invalid query: SELECT * FROM tbl_posts AS t1 INNER JOIN tbl_postMetaData AS t2 ON t1.postid = t2.post_id WHERE t1.post_url = asiri-groups-business 
ERROR - 2018-08-31 19:22:31 --> Severity: Notice --> Undefined variable: postTitle C:\wamp64\www\gem\application\controllers\admin\Blog.php 314
ERROR - 2018-08-31 19:22:31 --> Query error: Unknown column 'post_tite' in 'field list' - Invalid query: UPDATE `tbl_posts` SET `post_tite` = 'Asiri groups business', `post_body` = '<p>Great things happen</p>', `post_date` = '2018-08-31', `post_author` = 'Harold ', `post_tag` = 'Ruby', `post_topArticle` = '1', `post_publish_date` = '2018-08-31 19:22:31', `post_title` = NULL, `post_published` = '1', `post_image` = 'gcl-n-a.'
WHERE `post_url` = 'n-a'
ERROR - 2018-08-31 19:22:52 --> Query error: Unknown column 'post_tite' in 'field list' - Invalid query: UPDATE `tbl_posts` SET `post_tite` = 'Asiri groups business', `post_body` = '<p>Great things happen</p>', `post_date` = '2018-08-31', `post_author` = 'Harold ', `post_tag` = 'Ruby', `post_topArticle` = '1', `post_publish_date` = '2018-08-31 19:22:52', `post_published` = '1', `post_image` = 'gcl-n-a.'
WHERE `post_url` = 'n-a'
ERROR - 2018-08-31 19:23:42 --> Query error: Unknown column 'post_tite' in 'field list' - Invalid query: UPDATE `tbl_posts` SET `post_tite` = 'Asiri groups business', `post_body` = '<p>Great things happen</p>', `post_date` = '2018-08-31', `post_author` = 'Harold ', `post_tag` = 'Ruby', `post_topArticle` = '1', `post_publish_date` = '2018-08-31 19:23:42', `post_published` = '1', `post_image` = 'gcl-n-a.'
WHERE `post_url` = 'n-a'
ERROR - 2018-08-31 19:24:09 --> Query error: Unknown column 'n' in 'where clause' - Invalid query: SELECT postid FROM tbl_posts WHERE post_url = n-a
ERROR - 2018-08-31 19:24:43 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1 - Invalid query: SELECT postid FROM tbl_posts WHERE post_url = 
ERROR - 2018-08-31 19:26:01 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\models\Article_model.php 149
ERROR - 2018-08-31 19:26:30 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\models\Article_model.php 149
ERROR - 2018-08-31 19:27:00 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\models\Article_model.php 149
ERROR - 2018-08-31 19:27:54 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\models\Article_model.php 149
ERROR - 2018-08-31 19:45:28 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\wamp64\www\gem\system\database\DB_query_builder.php 2442
ERROR - 2018-08-31 19:45:28 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 2 - Invalid query: UPDATE `tbl_postMetaData` SET `meta_keywords` = 'rubuy', `meta_description` = 'ruby is awesome '
WHERE `post_id` = 
ERROR - 2018-08-31 19:49:46 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\wamp64\www\gem\system\database\DB_query_builder.php 2442
ERROR - 2018-08-31 19:49:46 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 2 - Invalid query: UPDATE `tbl_postMetaData` SET `meta_keywords` = 'rubuy', `meta_description` = 'ruby is awesome '
WHERE `post_id` = 
ERROR - 2018-08-31 19:53:26 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\wamp64\www\gem\application\controllers\admin\Blog.php 325
ERROR - 2018-08-31 19:53:26 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\wamp64\www\gem\system\database\DB_query_builder.php 2442
ERROR - 2018-08-31 19:53:26 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 2 - Invalid query: UPDATE `tbl_postMetaData` SET `meta_keywords` = 'rubuy', `meta_description` = 'ruby is awesome '
WHERE `post_id` = 
ERROR - 2018-08-31 20:00:05 --> 404 Page Not Found: Assets/img
ERROR - 2018-08-31 20:00:05 --> 404 Page Not Found: Assets/public
ERROR - 2018-08-31 20:00:05 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-31 20:00:05 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-31 20:00:06 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-31 20:00:09 --> 404 Page Not Found: Assets/public
ERROR - 2018-08-31 20:08:25 --> 404 Page Not Found: Assets/img
ERROR - 2018-08-31 20:08:25 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-31 20:08:25 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-31 20:08:25 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-31 20:08:25 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-31 20:09:17 --> Severity: Notice --> Undefined variable: dburl C:\wamp64\www\gem\application\controllers\admin\Blog.php 321
ERROR - 2018-08-31 20:23:45 --> 404 Page Not Found: Assets/public
ERROR - 2018-08-31 20:32:07 --> 404 Page Not Found: Assets/img
ERROR - 2018-08-31 20:32:07 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-31 20:32:07 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-31 20:32:07 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-31 20:32:07 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-31 20:54:36 --> Severity: Parsing Error --> syntax error, unexpected '"."' (T_CONSTANT_ENCAPSED_STRING) C:\wamp64\www\gem\application\controllers\admin\Blog.php 322
ERROR - 2018-08-31 20:55:02 --> Severity: Parsing Error --> syntax error, unexpected '"."' (T_CONSTANT_ENCAPSED_STRING) C:\wamp64\www\gem\application\controllers\admin\Blog.php 322
ERROR - 2018-08-31 20:55:28 --> Severity: Parsing Error --> syntax error, unexpected '"."' (T_CONSTANT_ENCAPSED_STRING) C:\wamp64\www\gem\application\controllers\admin\Blog.php 322
ERROR - 2018-08-31 20:56:58 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\models\Article_model.php 149
ERROR - 2018-08-31 20:56:58 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\controllers\admin\Blog.php 240
ERROR - 2018-08-31 20:56:58 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\controllers\admin\Blog.php 241
ERROR - 2018-08-31 20:56:58 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\controllers\admin\Blog.php 242
ERROR - 2018-08-31 20:56:58 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\controllers\admin\Blog.php 243
ERROR - 2018-08-31 20:56:58 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\controllers\admin\Blog.php 244
ERROR - 2018-08-31 20:56:58 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\controllers\admin\Blog.php 245
ERROR - 2018-08-31 20:56:58 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\controllers\admin\Blog.php 246
ERROR - 2018-08-31 20:56:58 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\controllers\admin\Blog.php 247
ERROR - 2018-08-31 20:56:58 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\controllers\admin\Blog.php 248
ERROR - 2018-08-31 20:56:58 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\controllers\admin\Blog.php 249
ERROR - 2018-08-31 21:02:08 --> 404 Page Not Found: Assets/img
ERROR - 2018-08-31 21:02:08 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-31 21:02:08 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-31 21:02:08 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-31 21:05:38 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-31 21:05:38 --> 404 Page Not Found: Assets/img
ERROR - 2018-08-31 21:05:38 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-31 21:05:38 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-31 21:05:38 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-31 21:05:38 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-31 21:05:38 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-31 21:05:38 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-31 21:05:39 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-31 21:05:39 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-31 21:05:39 --> 404 Page Not Found: Assets/public
ERROR - 2018-08-31 21:05:41 --> 404 Page Not Found: Assets/img
ERROR - 2018-08-31 21:05:41 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-31 21:05:41 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-31 21:05:41 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-31 21:05:41 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-31 22:15:44 --> 404 Page Not Found: Assests/public
ERROR - 2018-08-31 22:15:53 --> 404 Page Not Found: Assests/public
ERROR - 2018-08-31 22:15:56 --> 404 Page Not Found: Assests/public
ERROR - 2018-08-31 22:25:24 --> 404 Page Not Found: admin/%3C/index
ERROR - 2018-08-31 22:27:06 --> 404 Page Not Found: admin/%3C/index
ERROR - 2018-08-31 22:27:11 --> 404 Page Not Found: admin/Report/edit
ERROR - 2018-08-31 22:28:33 --> 404 Page Not Found: admin/Report/edit_customer%20%20
ERROR - 2018-08-31 22:28:48 --> 404 Page Not Found: admin/Report/edit_customer%20%20
ERROR - 2018-08-31 22:29:35 --> Severity: Notice --> Undefined variable: layout_title C:\wamp64\www\gem\application\libraries\Layout.php 78
ERROR - 2018-08-31 22:30:24 --> 404 Page Not Found: Assets/img
ERROR - 2018-08-31 22:32:22 --> 404 Page Not Found: Assets/img
ERROR - 2018-08-31 22:32:22 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-31 22:32:22 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-31 22:32:22 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-31 22:32:22 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-31 22:33:37 --> 404 Page Not Found: Assets/img
ERROR - 2018-08-31 22:33:37 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-31 22:33:37 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-31 22:33:37 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-31 22:33:37 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-31 22:33:37 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-31 22:33:37 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-31 22:33:37 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-31 22:33:37 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-31 22:33:37 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-31 22:33:38 --> 404 Page Not Found: Assets/public
ERROR - 2018-08-31 22:48:58 --> 404 Page Not Found: Assets/img
ERROR - 2018-08-31 22:48:58 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-31 22:48:58 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-31 22:48:58 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-31 22:48:58 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-31 22:48:58 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-31 22:48:58 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-31 22:48:58 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-31 22:48:58 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-31 22:48:58 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-31 22:48:58 --> 404 Page Not Found: Assets/public
ERROR - 2018-08-31 22:49:00 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-31 22:49:00 --> 404 Page Not Found: Assets/img
ERROR - 2018-08-31 22:49:00 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-31 22:49:00 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-31 22:49:00 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-31 22:49:00 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-31 22:49:00 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-31 22:49:00 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-31 22:49:00 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-31 22:49:00 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-31 22:49:01 --> 404 Page Not Found: Assets/public
ERROR - 2018-08-31 22:49:03 --> 404 Page Not Found: Assets/img
ERROR - 2018-08-31 22:49:03 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-31 22:49:03 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-31 22:49:03 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-31 22:49:03 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-31 22:50:29 --> 404 Page Not Found: Assets/img
ERROR - 2018-08-31 22:50:29 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-31 22:50:29 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-31 22:50:29 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-31 22:50:29 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-31 22:50:29 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-31 22:50:29 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-31 22:50:29 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-31 22:50:29 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-31 22:50:29 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-31 22:50:29 --> 404 Page Not Found: Assets/public
ERROR - 2018-08-31 22:52:02 --> 404 Page Not Found: Assets/img
ERROR - 2018-08-31 22:52:02 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-31 22:52:02 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-31 22:52:02 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-31 22:52:02 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-31 22:52:03 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-31 22:52:03 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-31 22:52:03 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-31 22:52:03 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-31 22:52:03 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-31 22:52:03 --> 404 Page Not Found: Assets/public
ERROR - 2018-08-31 22:54:35 --> 404 Page Not Found: Assets/img
ERROR - 2018-08-31 22:54:35 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-31 22:54:35 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-31 22:54:35 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-31 22:54:35 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-31 22:54:35 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-31 22:54:35 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-31 22:54:35 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-31 22:54:36 --> 404 Page Not Found: Assets/public
ERROR - 2018-08-31 22:55:28 --> 404 Page Not Found: Assets/public
ERROR - 2018-08-31 22:55:28 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-31 22:55:28 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-31 22:55:29 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-31 22:55:29 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-31 22:55:29 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-31 22:55:29 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-31 22:55:29 --> 404 Page Not Found: Assets/public
ERROR - 2018-08-31 22:55:47 --> 404 Page Not Found: Assets/public
ERROR - 2018-08-31 22:55:47 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-31 22:55:47 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-31 22:55:47 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-31 22:55:47 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-31 22:55:47 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-31 22:55:47 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-31 22:55:47 --> 404 Page Not Found: Assets/public
ERROR - 2018-08-31 22:56:32 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-31 22:56:32 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-31 22:56:32 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-31 22:56:32 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-31 22:56:32 --> 404 Page Not Found: Assets/public
ERROR - 2018-08-31 22:57:14 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-31 22:57:15 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-31 22:57:15 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-31 22:57:15 --> 404 Page Not Found: Assets/public
ERROR - 2018-08-31 22:57:42 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-31 22:57:42 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-31 22:57:42 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-31 22:57:42 --> 404 Page Not Found: Assets/public
ERROR - 2018-08-31 23:00:55 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-31 23:00:55 --> 404 Page Not Found: Assets/public
ERROR - 2018-08-31 23:02:53 --> 404 Page Not Found: Assets/public
ERROR - 2018-08-31 23:03:56 --> 404 Page Not Found: Assets/public
ERROR - 2018-08-31 23:05:22 --> 404 Page Not Found: Assets/public
ERROR - 2018-08-31 23:06:34 --> 404 Page Not Found: Assets/public
ERROR - 2018-08-31 23:13:05 --> 404 Page Not Found: Assets/public
ERROR - 2018-08-31 23:13:24 --> 404 Page Not Found: Assets/public
ERROR - 2018-08-31 23:14:11 --> 404 Page Not Found: Assets/public
ERROR - 2018-08-31 23:21:10 --> 404 Page Not Found: Assets/public
ERROR - 2018-08-31 23:24:51 --> 404 Page Not Found: Assets/public
ERROR - 2018-08-31 23:24:51 --> 404 Page Not Found: Assets/public
ERROR - 2018-08-31 23:24:51 --> 404 Page Not Found: Assets/public
ERROR - 2018-08-31 23:24:51 --> 404 Page Not Found: Assets/public
ERROR - 2018-08-31 23:25:39 --> 404 Page Not Found: Assets/public
ERROR - 2018-08-31 23:27:50 --> Severity: Notice --> Undefined variable: data C:\wamp64\www\gem\application\controllers\Base.php 57
ERROR - 2018-08-31 23:32:11 --> 404 Page Not Found: Assets/public
ERROR - 2018-08-31 23:40:33 --> 404 Page Not Found: Assets/public
ERROR - 2018-08-31 23:40:41 --> 404 Page Not Found: Assets/public
ERROR - 2018-08-31 23:40:48 --> 404 Page Not Found: Assets/public
ERROR - 2018-08-31 23:40:51 --> 404 Page Not Found: Assets/public
ERROR - 2018-08-31 23:42:07 --> 404 Page Not Found: Assets/public
ERROR - 2018-08-31 23:42:27 --> 404 Page Not Found: Assets/public
ERROR - 2018-08-31 23:49:51 --> 404 Page Not Found: Assets/public
ERROR - 2018-08-31 23:50:22 --> 404 Page Not Found: Assets/public
ERROR - 2018-08-31 23:50:26 --> 404 Page Not Found: Assets/public
ERROR - 2018-08-31 23:51:10 --> 404 Page Not Found: Assets/public
ERROR - 2018-08-31 23:51:44 --> 404 Page Not Found: Assets/public
ERROR - 2018-08-31 23:52:35 --> 404 Page Not Found: Assets/public
