<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-09-06 06:21:11 --> Severity: Notice --> Undefined variable: noOfComments C:\wamp64\www\gem\application\views\admin\profile.php 45
ERROR - 2018-09-06 06:21:11 --> Severity: Notice --> Undefined variable: total_unpaid_certificates C:\wamp64\www\gem\application\views\admin\profile.php 56
ERROR - 2018-09-06 06:22:20 --> Severity: Parsing Error --> syntax error, unexpected '''' (T_CONSTANT_ENCAPSED_STRING) C:\wamp64\www\gem\application\views\admin\report\add_gemstone.php 17
ERROR - 2018-09-06 06:22:58 --> Severity: Notice --> Undefined variable: gemid C:\wamp64\www\gem\application\views\admin\report\add_gemstone.php 32
ERROR - 2018-09-06 06:22:58 --> Severity: Notice --> Undefined variable: gemid C:\wamp64\www\gem\application\views\admin\report\add_gemstone.php 33
ERROR - 2018-09-06 06:29:25 --> Query error: Column 'cerno' cannot be null - Invalid query: INSERT INTO `tbl_certificate` (`cerno`, `cer_date`, `cer_object`, `cer_type`, `cer_identification`, `cer_weight`, `cer_gemWidth`, `cer_gemHeight`, `cer_gemlength`, `cer_cut`, `cer_shape`, `cer_color`, `cer_comment`, `customerID`, `cer_imagename`) VALUES (NULL, '2018-09-06', 'one', 'cert-report', 'diffusion', '8.50', '12.37', '9.64', '8.84', 'modified', 'oval', 'blue', 'Hello', NULL, '.jpg')
ERROR - 2018-09-06 06:38:57 --> 404 Page Not Found: Assets/css
ERROR - 2018-09-06 06:39:03 --> Severity: Notice --> Undefined variable: noOfComments C:\wamp64\www\gem\application\views\admin\profile.php 45
ERROR - 2018-09-06 06:39:03 --> Severity: Notice --> Undefined variable: total_unpaid_certificates C:\wamp64\www\gem\application\views\admin\profile.php 56
ERROR - 2018-09-06 06:39:08 --> 404 Page Not Found: Assets/css
ERROR - 2018-09-06 06:40:34 --> Severity: Notice --> Undefined variable: noOfComments C:\wamp64\www\gem\application\views\admin\profile.php 45
ERROR - 2018-09-06 06:40:34 --> Severity: Notice --> Undefined variable: total_unpaid_certificates C:\wamp64\www\gem\application\views\admin\profile.php 56
ERROR - 2018-09-06 06:40:36 --> 404 Page Not Found: Assets/css
ERROR - 2018-09-06 06:41:16 --> 404 Page Not Found: Assets/css
ERROR - 2018-09-06 06:41:20 --> Severity: Notice --> Undefined variable: noOfComments C:\wamp64\www\gem\application\views\admin\profile.php 45
ERROR - 2018-09-06 06:41:20 --> Severity: Notice --> Undefined variable: total_unpaid_certificates C:\wamp64\www\gem\application\views\admin\profile.php 56
ERROR - 2018-09-06 06:41:22 --> 404 Page Not Found: Assets/css
ERROR - 2018-09-06 06:41:31 --> Severity: Notice --> Undefined variable: noOfComments C:\wamp64\www\gem\application\views\admin\profile.php 45
ERROR - 2018-09-06 06:41:31 --> Severity: Notice --> Undefined variable: total_unpaid_certificates C:\wamp64\www\gem\application\views\admin\profile.php 56
ERROR - 2018-09-06 06:42:31 --> 404 Page Not Found: Assets/css
ERROR - 2018-09-06 06:42:58 --> Severity: Notice --> Undefined variable: noOfComments C:\wamp64\www\gem\application\views\admin\profile.php 45
ERROR - 2018-09-06 06:42:58 --> Severity: Notice --> Undefined variable: total_unpaid_certificates C:\wamp64\www\gem\application\views\admin\profile.php 56
ERROR - 2018-09-06 06:43:00 --> 404 Page Not Found: Assets/css
ERROR - 2018-09-06 06:43:53 --> 404 Page Not Found: Assets/css
ERROR - 2018-09-06 06:43:55 --> 404 Page Not Found: Assets/css
ERROR - 2018-09-06 06:43:59 --> Severity: Notice --> Undefined variable: noOfComments C:\wamp64\www\gem\application\views\admin\profile.php 45
ERROR - 2018-09-06 06:43:59 --> Severity: Notice --> Undefined variable: total_unpaid_certificates C:\wamp64\www\gem\application\views\admin\profile.php 56
ERROR - 2018-09-06 06:44:01 --> Severity: Notice --> Undefined variable: noOfComments C:\wamp64\www\gem\application\views\admin\profile.php 45
ERROR - 2018-09-06 06:44:01 --> Severity: Notice --> Undefined variable: total_unpaid_certificates C:\wamp64\www\gem\application\views\admin\profile.php 56
ERROR - 2018-09-06 07:02:12 --> Severity: Notice --> Undefined variable: id C:\wamp64\www\gem\application\controllers\admin\Report.php 80
ERROR - 2018-09-06 07:02:12 --> Severity: Notice --> Undefined variable: id C:\wamp64\www\gem\application\controllers\admin\Report.php 81
ERROR - 2018-09-06 07:02:12 --> Severity: Notice --> Undefined offset: 0 C:\wamp64\www\gem\application\models\Report_model.php 104
ERROR - 2018-09-06 07:02:12 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\models\Report_model.php 104
ERROR - 2018-09-06 07:02:12 --> Severity: Notice --> Undefined offset: 0 C:\wamp64\www\gem\application\models\Report_model.php 104
ERROR - 2018-09-06 07:02:12 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\models\Report_model.php 104
ERROR - 2018-09-06 07:02:12 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'ORDER BY cerno DESC LIMIT 0, 10' at line 1 - Invalid query: SELECT cerno, cer_type, cer_object, cer_identification, cer_paymentStatus, cer_weight, customerID FROM tbl_certificate  WHERE customerID =  ORDER BY cerno DESC LIMIT 0, 10
ERROR - 2018-09-06 07:03:22 --> Severity: Notice --> Undefined variable: id C:\wamp64\www\gem\application\controllers\admin\Report.php 80
ERROR - 2018-09-06 07:03:22 --> Severity: Notice --> Undefined variable: id C:\wamp64\www\gem\application\controllers\admin\Report.php 81
ERROR - 2018-09-06 07:03:22 --> Severity: Notice --> Undefined offset: 0 C:\wamp64\www\gem\application\models\Report_model.php 104
ERROR - 2018-09-06 07:03:22 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\models\Report_model.php 104
ERROR - 2018-09-06 07:03:22 --> Severity: Notice --> Undefined offset: 0 C:\wamp64\www\gem\application\models\Report_model.php 104
ERROR - 2018-09-06 07:03:22 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\models\Report_model.php 104
ERROR - 2018-09-06 07:03:22 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'ORDER BY cerno DESC LIMIT 0, 10' at line 1 - Invalid query: SELECT cerno, cer_type, cer_object, cer_identification, cer_paymentStatus, cer_weight, customerID FROM tbl_certificate  WHERE customerID =  ORDER BY cerno DESC LIMIT 0, 10
