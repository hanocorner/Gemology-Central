<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-08-25 18:14:11 --> 404 Page Not Found: Assets/css
ERROR - 2018-08-25 18:14:23 --> 404 Page Not Found: Assets/admin
ERROR - 2018-08-25 18:14:23 --> 404 Page Not Found: Assets/js
ERROR - 2018-08-25 18:14:23 --> 404 Page Not Found: Assets/js
ERROR - 2018-08-25 18:14:23 --> 404 Page Not Found: Assets/js
ERROR - 2018-08-25 18:14:23 --> 404 Page Not Found: Assets/js
ERROR - 2018-08-25 18:14:23 --> 404 Page Not Found: Assets/js
ERROR - 2018-08-25 18:14:23 --> 404 Page Not Found: Assets/js
ERROR - 2018-08-25 18:14:23 --> 404 Page Not Found: Assets/js
ERROR - 2018-08-25 18:14:23 --> 404 Page Not Found: Assets/admin
ERROR - 2018-08-25 18:14:23 --> 404 Page Not Found: Assets/js
ERROR - 2018-08-25 18:14:23 --> 404 Page Not Found: Assets/js
ERROR - 2018-08-25 18:14:23 --> 404 Page Not Found: Assets/js
ERROR - 2018-08-25 18:14:23 --> 404 Page Not Found: Assets/js
ERROR - 2018-08-25 18:14:23 --> 404 Page Not Found: Assets/js
ERROR - 2018-08-25 18:14:23 --> 404 Page Not Found: Assets/js
ERROR - 2018-08-25 18:14:23 --> 404 Page Not Found: Assets/js
ERROR - 2018-08-25 18:15:51 --> Severity: Notice --> Undefined property: CI_Loader::$layouts C:\wamp64\www\gem\application\views\layout.php 8
ERROR - 2018-08-25 18:15:51 --> Severity: Error --> Call to a member function print_includes() on null C:\wamp64\www\gem\application\views\layout.php 8
ERROR - 2018-08-25 18:19:01 --> Severity: Notice --> Undefined property: CI_Loader::$layouts C:\wamp64\www\gem\application\views\layout.php 8
ERROR - 2018-08-25 18:19:01 --> Severity: Error --> Call to a member function print_includes() on null C:\wamp64\www\gem\application\views\layout.php 8
ERROR - 2018-08-25 18:19:03 --> Severity: Notice --> Undefined property: CI_Loader::$layouts C:\wamp64\www\gem\application\views\layout.php 8
ERROR - 2018-08-25 18:19:03 --> Severity: Error --> Call to a member function print_includes() on null C:\wamp64\www\gem\application\views\layout.php 8
ERROR - 2018-08-25 18:19:33 --> 404 Page Not Found: Assets/img
ERROR - 2018-08-25 18:19:33 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-25 18:19:33 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-25 18:19:33 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-25 18:19:34 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-25 18:21:00 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-25 18:21:00 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-25 18:21:00 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-25 18:23:56 --> 404 Page Not Found: Assets/img
ERROR - 2018-08-25 18:23:56 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-25 18:23:56 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-25 18:23:56 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-25 18:23:57 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-25 18:24:22 --> 404 Page Not Found: admin/Blog/comment
ERROR - 2018-08-25 18:48:35 --> 404 Page Not Found: admin/Blog/comment
ERROR - 2018-08-25 18:48:36 --> 404 Page Not Found: admin/Blog/comment
ERROR - 2018-08-25 19:14:53 --> Severity: Compile Error --> Cannot use [] for reading C:\wamp64\www\gem\application\libraries\layout.php 55
ERROR - 2018-08-25 19:18:05 --> Severity: Error --> Call to a member function add_include() on array C:\wamp64\www\gem\application\controllers\admin\Comment.php 24
ERROR - 2018-08-25 19:21:11 --> Severity: Notice --> Array to string conversion C:\wamp64\www\gem\application\libraries\layout.php 48
ERROR - 2018-08-25 19:27:15 --> Severity: Notice --> Undefined property: CI_Loader::$file C:\wamp64\www\gem\application\views\admin\layouts\admin.php 9
ERROR - 2018-08-25 20:05:11 --> Severity: Notice --> Undefined property: CI_Loader::$layouts C:\wamp64\www\gem\application\views\admin\layouts\admin.php 9
ERROR - 2018-08-25 20:05:11 --> Severity: Error --> Call to a member function print_includes() on null C:\wamp64\www\gem\application\views\admin\layouts\admin.php 9
ERROR - 2018-08-25 20:41:48 --> Severity: Notice --> Undefined variable: title C:\wamp64\www\gem\application\views\admin\blog\header.php 7
ERROR - 2018-08-25 20:45:38 --> Severity: Notice --> Undefined variable: username C:\wamp64\www\gem\application\views\admin\blog\header.php 92
ERROR - 2018-08-25 20:45:38 --> 404 Page Not Found: Assets/admin
ERROR - 2018-08-25 20:45:38 --> 404 Page Not Found: Assets/js
ERROR - 2018-08-25 20:45:38 --> 404 Page Not Found: Assets/js
ERROR - 2018-08-25 20:45:38 --> 404 Page Not Found: Assets/js
ERROR - 2018-08-25 20:45:38 --> 404 Page Not Found: Assets/js
ERROR - 2018-08-25 20:45:38 --> 404 Page Not Found: Assets/js
ERROR - 2018-08-25 20:45:38 --> 404 Page Not Found: Assets/js
ERROR - 2018-08-25 20:45:38 --> 404 Page Not Found: Assets/js
ERROR - 2018-08-25 20:45:39 --> 404 Page Not Found: Assets/admin
ERROR - 2018-08-25 20:45:39 --> 404 Page Not Found: Assets/js
ERROR - 2018-08-25 20:45:39 --> 404 Page Not Found: Assets/js
ERROR - 2018-08-25 20:45:39 --> 404 Page Not Found: Assets/js
ERROR - 2018-08-25 20:45:39 --> 404 Page Not Found: Assets/js
ERROR - 2018-08-25 20:45:39 --> 404 Page Not Found: Assets/js
ERROR - 2018-08-25 20:45:39 --> 404 Page Not Found: Assets/js
ERROR - 2018-08-25 20:45:39 --> 404 Page Not Found: Assets/js
ERROR - 2018-08-25 20:51:47 --> Severity: Parsing Error --> syntax error, unexpected '.' C:\wamp64\www\gem\application\libraries\layout.php 63
ERROR - 2018-08-25 20:54:38 --> 404 Page Not Found: Assets/js
ERROR - 2018-08-25 20:54:38 --> 404 Page Not Found: Assets/js
ERROR - 2018-08-25 20:54:38 --> 404 Page Not Found: Assets/admin
ERROR - 2018-08-25 20:54:38 --> 404 Page Not Found: Assets/js
ERROR - 2018-08-25 20:54:38 --> 404 Page Not Found: Assets/js
ERROR - 2018-08-25 20:54:38 --> 404 Page Not Found: Assets/js
ERROR - 2018-08-25 20:54:38 --> 404 Page Not Found: Assets/js
ERROR - 2018-08-25 20:54:38 --> 404 Page Not Found: Assets/js
ERROR - 2018-08-25 20:54:38 --> 404 Page Not Found: Assets/admin
ERROR - 2018-08-25 20:54:39 --> 404 Page Not Found: Assets/js
ERROR - 2018-08-25 20:54:39 --> 404 Page Not Found: Assets/js
ERROR - 2018-08-25 20:54:39 --> 404 Page Not Found: Assets/js
ERROR - 2018-08-25 20:54:39 --> 404 Page Not Found: Assets/js
ERROR - 2018-08-25 20:54:39 --> 404 Page Not Found: Assets/js
ERROR - 2018-08-25 20:54:39 --> 404 Page Not Found: Assets/js
ERROR - 2018-08-25 20:54:39 --> 404 Page Not Found: Assets/js
ERROR - 2018-08-25 21:02:32 --> 404 Page Not Found: Assets/admin
ERROR - 2018-08-25 21:02:33 --> 404 Page Not Found: Assets/admin
ERROR - 2018-08-25 21:02:33 --> 404 Page Not Found: Assets/admin
ERROR - 2018-08-25 21:02:33 --> 404 Page Not Found: Assets/admin
ERROR - 2018-08-25 21:02:33 --> 404 Page Not Found: Assets/admin
ERROR - 2018-08-25 21:02:33 --> 404 Page Not Found: Assets/admin
ERROR - 2018-08-25 21:02:33 --> 404 Page Not Found: Assets/admin
ERROR - 2018-08-25 21:02:33 --> 404 Page Not Found: Assets/admin
ERROR - 2018-08-25 21:02:33 --> 404 Page Not Found: Assets/admin
ERROR - 2018-08-25 21:02:33 --> 404 Page Not Found: Assets/admin
ERROR - 2018-08-25 21:02:33 --> 404 Page Not Found: Assets/admin
ERROR - 2018-08-25 21:02:33 --> 404 Page Not Found: Assets/admin
ERROR - 2018-08-25 21:02:33 --> 404 Page Not Found: Assets/admin
ERROR - 2018-08-25 21:02:33 --> 404 Page Not Found: Assets/admin
ERROR - 2018-08-25 21:06:01 --> 404 Page Not Found: Assets/css
ERROR - 2018-08-25 21:06:09 --> 404 Page Not Found: admin/Blog/comment
ERROR - 2018-08-25 21:06:11 --> 404 Page Not Found: admin/Blog/comment
ERROR - 2018-08-25 21:10:15 --> 404 Page Not Found: admin/%3C/index
ERROR - 2018-08-25 21:10:34 --> Severity: Notice --> Undefined variable: username C:\wamp64\www\gem\application\views\admin\blog\header.php 90
ERROR - 2018-08-25 21:34:38 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\wamp64\www\gem\application\libraries\layout.php 67
ERROR - 2018-08-25 21:41:58 --> Severity: Notice --> Undefined variable: username C:\wamp64\www\gem\application\views\admin\blog\header.php 90
ERROR - 2018-08-25 21:42:54 --> 404 Page Not Found: admin/Blog/comment
ERROR - 2018-08-25 21:43:00 --> Severity: Notice --> Undefined variable: username C:\wamp64\www\gem\application\views\admin\blog\header.php 90
ERROR - 2018-08-25 22:25:17 --> 404 Page Not Found: admin/Blog/comment
ERROR - 2018-08-25 23:39:26 --> 404 Page Not Found: admin/Blog/comment
ERROR - 2018-08-25 23:39:53 --> 404 Page Not Found: Assets/css
ERROR - 2018-08-25 23:40:04 --> 404 Page Not Found: admin/Blog/comment
ERROR - 2018-08-25 23:43:03 --> 404 Page Not Found: admin/Layout/index
ERROR - 2018-08-25 23:43:25 --> 404 Page Not Found: Libraries/layout
