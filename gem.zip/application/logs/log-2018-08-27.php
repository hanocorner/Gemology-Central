<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-08-27 21:16:08 --> 404 Page Not Found: Assets/img
<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-08-27 21:16:08 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-27 21:16:08 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-27 21:16:09 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-27 21:16:09 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-27 21:16:09 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-27 21:16:09 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-27 21:16:09 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-27 21:16:09 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-27 21:16:09 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-27 21:16:10 --> 404 Page Not Found: Assets/public
ERROR - 2018-08-27 21:16:14 --> 404 Page Not Found: Assets/css
ERROR - 2018-08-27 21:16:25 --> 404 Page Not Found: admin/Blog/comment
ERROR - 2018-08-27 21:19:25 --> 404 Page Not Found: admin/Blog/comment
