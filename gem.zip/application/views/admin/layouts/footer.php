<footer class="sticky-footer bg-light">
  <div class="container">
    <div class="text-center">
      <small>Copyright © Gemology 2018</small>
    </div>
  </div>
</footer>
