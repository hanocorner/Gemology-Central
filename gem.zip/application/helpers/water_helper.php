<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
 *
 *
 */
if (!function_exists('template_table'))
{
  function template_table()
  {
    $ci = get_instance();

    

    return $template;
  }
}
?>
