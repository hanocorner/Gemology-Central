<?php
defined('BASEPATH') OR exit('No direct script access allowed');

if (!function_exists('template_pagination'))
{
  function template_pagination($total_rows, $rows_per_page)
  {
    

    return $config;
  }
}

?>
