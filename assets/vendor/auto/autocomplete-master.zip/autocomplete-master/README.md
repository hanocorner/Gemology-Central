Autocomplete
============

[Documentation & Demo][doc]

jQuery Autocomplete plugin like Google search

![ScreenShot](http://xdsoft.net/components/com_jquery_plugins/images/thumbs/9ef998646d551d73e4206f13b123be62.jpg)

[doc]: http://xdsoft.net/jqplugins/autocomplete

```html
npm install jquery-autocomplete
```