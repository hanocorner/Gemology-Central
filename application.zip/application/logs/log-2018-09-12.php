<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-09-12 08:01:24 --> Severity: Notice --> Undefined variable: noOfComments C:\wamp64\www\gem\application\views\admin\profile.php 45
ERROR - 2018-09-12 08:01:24 --> Severity: Notice --> Undefined variable: total_unpaid_certificates C:\wamp64\www\gem\application\views\admin\profile.php 56
ERROR - 2018-09-12 08:02:16 --> Severity: Notice --> Undefined variable: noOfComments C:\wamp64\www\gem\application\views\admin\profile.php 45
ERROR - 2018-09-12 08:02:16 --> Severity: Notice --> Undefined variable: total_unpaid_certificates C:\wamp64\www\gem\application\views\admin\profile.php 56
ERROR - 2018-09-12 08:07:41 --> Severity: Notice --> Undefined variable: noOfComments C:\wamp64\www\gem\application\views\admin\profile.php 45
ERROR - 2018-09-12 08:07:41 --> Severity: Notice --> Undefined variable: total_unpaid_certificates C:\wamp64\www\gem\application\views\admin\profile.php 56
ERROR - 2018-09-12 20:58:40 --> 404 Page Not Found: admin/Report/index
ERROR - 2018-09-12 21:11:14 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\models\Lab_model.php 50
