<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-09-26 06:58:59 --> 404 Page Not Found: Assets/admin
ERROR - 2018-09-26 07:00:45 --> 404 Page Not Found: Assets/admin
ERROR - 2018-09-26 07:00:57 --> 404 Page Not Found: Assets/admin
ERROR - 2018-09-26 07:15:10 --> 404 Page Not Found: Assets/admin
ERROR - 2018-09-26 07:17:01 --> 404 Page Not Found: Assets/admin
ERROR - 2018-09-26 07:18:55 --> 404 Page Not Found: Assets/admin
ERROR - 2018-09-26 07:19:10 --> 404 Page Not Found: Assets/admin
ERROR - 2018-09-26 07:30:43 --> 404 Page Not Found: Assets/admin
ERROR - 2018-09-26 07:31:09 --> 404 Page Not Found: Assets/admin
ERROR - 2018-09-26 08:04:41 --> 404 Page Not Found: Assets/admin
ERROR - 2018-09-26 08:39:41 --> Severity: Notice --> Undefined property: Report::$encrypt C:\wamp64\www\gem\application\controllers\admin\Report.php 520
ERROR - 2018-09-26 08:39:41 --> Severity: Error --> Call to a member function encode() on null C:\wamp64\www\gem\application\controllers\admin\Report.php 520
ERROR - 2018-09-26 08:50:24 --> 404 Page Not Found: admin/Assets/images
ERROR - 2018-09-26 08:51:24 --> 404 Page Not Found: Assets/admin
