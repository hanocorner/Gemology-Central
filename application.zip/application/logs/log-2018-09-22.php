<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-09-22 07:01:55 --> 404 Page Not Found: public/Base/report_verification
ERROR - 2018-09-22 07:02:01 --> 404 Page Not Found: public/Base/report_verification
ERROR - 2018-09-22 07:02:02 --> 404 Page Not Found: public/Base/report_verification
ERROR - 2018-09-22 07:02:20 --> 404 Page Not Found: public/Base/report_verification
ERROR - 2018-09-22 07:02:21 --> 404 Page Not Found: public/Base/report_verification
ERROR - 2018-09-22 07:02:40 --> 404 Page Not Found: public/Base/index
ERROR - 2018-09-22 07:02:41 --> 404 Page Not Found: public/Base/index
ERROR - 2018-09-22 07:02:44 --> 404 Page Not Found: Report/GCL_000003
ERROR - 2018-09-22 07:02:48 --> 404 Page Not Found: public/Base/index
ERROR - 2018-09-22 07:50:53 --> Severity: Parsing Error --> syntax error, unexpected '$data' (T_VARIABLE) C:\wamp64\www\gem\application\controllers\public\Report.php 57
ERROR - 2018-09-22 08:47:52 --> Severity: Notice --> Undefined variable: repno C:\wamp64\www\gem\application\controllers\public\Report.php 101
ERROR - 2018-09-22 08:48:30 --> 404 Page Not Found: Report/Xjyis79bzB0W%2BdL3YonCrqUuTwG3EYjHYqfZmwyT7Lv79ypjECkLu4bRBJhoTXrMsRu34zwdcMd4dJpXvpeSEA%3D%3D
ERROR - 2018-09-22 08:49:55 --> 404 Page Not Found: public/Base/report
ERROR - 2018-09-22 08:49:56 --> 404 Page Not Found: public/Base/report
ERROR - 2018-09-22 08:51:02 --> 404 Page Not Found: Base/report_data
ERROR - 2018-09-22 11:27:36 --> 404 Page Not Found: public/Report/_report
ERROR - 2018-09-22 11:29:08 --> 404 Page Not Found: public/Report/report
ERROR - 2018-09-22 11:29:11 --> 404 Page Not Found: public/Report/report
ERROR - 2018-09-22 11:29:54 --> 404 Page Not Found: public/Report/report
ERROR - 2018-09-22 12:24:23 --> 404 Page Not Found: Assets/admin
ERROR - 2018-09-22 12:28:14 --> 404 Page Not Found: Assets/admin
ERROR - 2018-09-22 12:37:50 --> 404 Page Not Found: Assets/admin
ERROR - 2018-09-22 12:51:57 --> 404 Page Not Found: Assets/admin
ERROR - 2018-09-22 13:20:28 --> 404 Page Not Found: Assets/admin
ERROR - 2018-09-22 13:21:07 --> 404 Page Not Found: Assets/admin
ERROR - 2018-09-22 13:22:00 --> 404 Page Not Found: Assets/admin
ERROR - 2018-09-22 13:22:32 --> 404 Page Not Found: Assets/admin
ERROR - 2018-09-22 13:23:14 --> 404 Page Not Found: Assets/admin
ERROR - 2018-09-22 13:25:31 --> 404 Page Not Found: Assets/admin
ERROR - 2018-09-22 13:25:50 --> 404 Page Not Found: Assets/admin
ERROR - 2018-09-22 13:26:09 --> 404 Page Not Found: Assets/admin
ERROR - 2018-09-22 13:26:22 --> 404 Page Not Found: Assets/admin
ERROR - 2018-09-22 13:26:27 --> 404 Page Not Found: Assets/admin
ERROR - 2018-09-22 13:27:13 --> 404 Page Not Found: Assets/admin
ERROR - 2018-09-22 13:31:03 --> 404 Page Not Found: Assets/admin
ERROR - 2018-09-22 15:26:45 --> 404 Page Not Found: Assets/admin
ERROR - 2018-09-22 16:57:29 --> Severity: error --> Exception: Class Report already exists and doesn't extend CI_Model C:\wamp64\www\gem\system\core\Loader.php 353
ERROR - 2018-09-22 17:18:14 --> Severity: error --> Exception: Class Report already exists and doesn't extend CI_Model C:\wamp64\www\gem\system\core\Loader.php 353
ERROR - 2018-09-22 17:19:52 --> 404 Page Not Found: Assets/admin
ERROR - 2018-09-22 18:24:51 --> Severity: Parsing Error --> syntax error, unexpected ''colors'' (T_CONSTANT_ENCAPSED_STRING), expecting ')' C:\wamp64\www\gem\application\controllers\public\Report.php 135
ERROR - 2018-09-22 18:25:05 --> Severity: Error --> Call to undefined method CI_DB_mysqli_driver::num_rows() C:\wamp64\www\gem\application\models\public\Report_model.php 45
ERROR - 2018-09-22 18:27:20 --> Severity: Error --> Call to a member function num_rows() on boolean C:\wamp64\www\gem\application\models\public\Report_model.php 45
ERROR - 2018-09-22 18:53:59 --> Severity: Error --> Call to a member function num_rows() on boolean C:\wamp64\www\gem\application\models\public\Report_model.php 45
ERROR - 2018-09-22 18:55:40 --> Query error: Table 'gemology_central_db.captcha' doesn't exist - Invalid query: DELETE FROM `captcha`
WHERE `captcha_time` < 1537615540
ERROR - 2018-09-22 18:56:24 --> Query error: Table 'gemology_central_db.captcha' doesn't exist - Invalid query: SELECT COUNT(*) AS count FROM captcha WHERE word = '4023' AND ip_address = '::1' AND captcha_time > 1537615584
ERROR - 2018-09-22 22:06:00 --> Severity: Notice --> Undefined variable: csrf C:\wamp64\www\gem\application\views\public\report\form_verification.php 17
ERROR - 2018-09-22 22:06:00 --> Severity: Notice --> Undefined variable: csrf C:\wamp64\www\gem\application\views\public\report\form_verification.php 17
ERROR - 2018-09-22 22:47:26 --> 404 Page Not Found: Assets/admin
ERROR - 2018-09-22 22:49:14 --> 404 Page Not Found: Assets/admin
ERROR - 2018-09-22 22:49:27 --> 404 Page Not Found: Assets/admin
