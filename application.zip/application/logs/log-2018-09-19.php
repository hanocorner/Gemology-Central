<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-09-19 09:52:35 --> 404 Page Not Found: admin/Edit/memo
ERROR - 2018-09-19 14:52:27 --> 404 Page Not Found: Assets/admin
ERROR - 2018-09-19 14:53:05 --> 404 Page Not Found: Assets/admin
ERROR - 2018-09-19 23:06:21 --> 404 Page Not Found: Report/GCL_000003
ERROR - 2018-09-19 23:16:35 --> Severity: Notice --> Undefined property: Base::$Base_model C:\wamp64\www\gem\application\controllers\Base.php 67
ERROR - 2018-09-19 23:16:36 --> Severity: Error --> Call to a member function get_labreport_by_id() on null C:\wamp64\www\gem\application\controllers\Base.php 67
ERROR - 2018-09-19 23:17:54 --> Severity: Notice --> Undefined property: Base::$Base_model C:\wamp64\www\gem\application\controllers\Base.php 67
ERROR - 2018-09-19 23:17:54 --> Severity: Error --> Call to a member function get_labreport_by_id() on null C:\wamp64\www\gem\application\controllers\Base.php 67
ERROR - 2018-09-19 23:17:59 --> Severity: Notice --> Undefined property: Base::$Base_model C:\wamp64\www\gem\application\controllers\Base.php 67
ERROR - 2018-09-19 23:17:59 --> Severity: Error --> Call to a member function get_labreport_by_id() on null C:\wamp64\www\gem\application\controllers\Base.php 67
ERROR - 2018-09-19 23:18:22 --> Severity: Notice --> Undefined property: Base::$Base_model C:\wamp64\www\gem\application\controllers\Base.php 67
ERROR - 2018-09-19 23:18:22 --> Severity: Error --> Call to a member function get_labreport_by_id() on null C:\wamp64\www\gem\application\controllers\Base.php 67
ERROR - 2018-09-19 23:18:26 --> Severity: Notice --> Undefined property: Base::$Base_model C:\wamp64\www\gem\application\controllers\Base.php 67
ERROR - 2018-09-19 23:18:26 --> Severity: Error --> Call to a member function get_labreport_by_id() on null C:\wamp64\www\gem\application\controllers\Base.php 67
ERROR - 2018-09-19 23:19:25 --> Severity: Notice --> Undefined property: Base::$D_model C:\wamp64\www\gem\application\controllers\Base.php 67
ERROR - 2018-09-19 23:19:25 --> Severity: Error --> Call to a member function get_labreport_by_id() on null C:\wamp64\www\gem\application\controllers\Base.php 67
ERROR - 2018-09-19 23:20:50 --> Severity: Notice --> Undefined property: Base::$D_model C:\wamp64\www\gem\application\controllers\Base.php 67
ERROR - 2018-09-19 23:20:51 --> Severity: Error --> Call to a member function get_labreport_by_id() on null C:\wamp64\www\gem\application\controllers\Base.php 67
ERROR - 2018-09-19 23:20:58 --> Severity: Notice --> Undefined property: Base::$D_model C:\wamp64\www\gem\application\controllers\Base.php 67
ERROR - 2018-09-19 23:20:59 --> Severity: Error --> Call to a member function get_labreport_by_id() on null C:\wamp64\www\gem\application\controllers\Base.php 67
ERROR - 2018-09-19 23:21:24 --> Severity: Warning --> json_decode() expects parameter 1 to be string, object given C:\wamp64\www\gem\application\controllers\Base.php 68
