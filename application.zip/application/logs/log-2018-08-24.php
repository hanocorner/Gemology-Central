<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-08-24 00:06:53 --> Severity: Notice --> Undefined index: id C:\wamp64\www\gem\application\controllers\admin\Report.php 76
ERROR - 2018-08-24 00:06:53 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1 - Invalid query: SELECT cerno, cer_object, cer_identification, cer_weight, customerID FROM tbl_certificate WHERE customerID =  
ERROR - 2018-08-24 00:15:34 --> Severity: Parsing Error --> syntax error, unexpected '$sql' (T_VARIABLE) C:\wamp64\www\gem\application\models\Report_model.php 47
ERROR - 2018-08-24 07:30:11 --> 404 Page Not Found: Assets/css
ERROR - 2018-08-24 08:25:51 --> 404 Page Not Found: admin/%3C/index
ERROR - 2018-08-24 08:34:44 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '[object Object]' at line 1 - Invalid query: SELECT cerno, cer_object, cer_identification, cer_weight, customerID FROM tbl_certificate WHERE customerID = [object Object] 
ERROR - 2018-08-24 23:14:49 --> 404 Page Not Found: Assets/css
ERROR - 2018-08-24 23:27:04 --> 404 Page Not Found: Assets/admin
ERROR - 2018-08-24 23:27:04 --> 404 Page Not Found: Assets/js
ERROR - 2018-08-24 23:27:04 --> 404 Page Not Found: Assets/js
ERROR - 2018-08-24 23:27:04 --> 404 Page Not Found: Assets/js
ERROR - 2018-08-24 23:27:04 --> 404 Page Not Found: Assets/js
ERROR - 2018-08-24 23:27:04 --> 404 Page Not Found: Assets/js
ERROR - 2018-08-24 23:27:04 --> 404 Page Not Found: Assets/js
ERROR - 2018-08-24 23:27:04 --> 404 Page Not Found: Assets/js
ERROR - 2018-08-24 23:27:04 --> 404 Page Not Found: Assets/admin
ERROR - 2018-08-24 23:27:04 --> 404 Page Not Found: Assets/js
ERROR - 2018-08-24 23:27:04 --> 404 Page Not Found: Assets/js
ERROR - 2018-08-24 23:27:04 --> 404 Page Not Found: Assets/js
ERROR - 2018-08-24 23:27:04 --> 404 Page Not Found: Assets/js
ERROR - 2018-08-24 23:27:04 --> 404 Page Not Found: Assets/js
ERROR - 2018-08-24 23:27:04 --> 404 Page Not Found: Assets/js
ERROR - 2018-08-24 23:27:04 --> 404 Page Not Found: Assets/js
