<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-08-28 07:08:30 --> 404 Page Not Found: Assets/css
ERROR - 2018-08-28 21:17:05 --> 404 Page Not Found: Assets/css
ERROR - 2018-08-28 22:24:55 --> 404 Page Not Found: Assets/css
ERROR - 2018-08-28 22:27:33 --> Severity: Notice --> Undefined variable: username C:\wamp64\www\gem\application\views\admin\profile.php 23
