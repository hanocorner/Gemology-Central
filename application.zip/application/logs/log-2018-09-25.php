<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-09-25 06:41:55 --> Severity: Notice --> Undefined index: error C:\wamp64\www\gem\application\views\admin\lab\gemstone\search.php 109
ERROR - 2018-09-25 07:11:19 --> Query error: Unknown column 't1.memoid' in 'where clause' - Invalid query: SELECT *
FROM `tbl_lab_report` AS `t1`
JOIN `tbl_gem_memocard` AS `t2` ON `t1`.`reportid` = `t2`.`reportid`
WHERE `t1`.`memoid` IS NULL
ERROR - 2018-09-25 07:11:56 --> Severity: Error --> Call to undefined method CI_DB_mysqli_driver::num_rows() C:\wamp64\www\gem\application\models\Gem_model.php 208
