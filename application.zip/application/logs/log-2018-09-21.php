<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-09-21 05:25:17 --> Severity: Error --> Call to undefined method Base::set_flashdata() C:\wamp64\www\gem\application\controllers\Base.php 100
ERROR - 2018-09-21 06:39:39 --> Query error: Table 'gemology_central_db.tbl_lab_reportas' doesn't exist - Invalid query: SELECT *
FROM `tbl_lab_reportAS` `t1`
LEFT JOIN `tbl_gem_memocardAS` `t2` ON `t1`.`reportid` = `t2`.`reportid`
WHERE `memoid` = 'GCL2018-091005'
ERROR - 2018-09-21 06:39:53 --> Query error: Table 'gemology_central_db.tbl_lab_reportas' doesn't exist - Invalid query: SELECT *
FROM `tbl_lab_reportAS` `t1`
LEFT JOIN `tbl_gem_memocardAS` `t2` ON `t1`.`reportid` = `t2`.`reportid`
WHERE `memoid` = 'GCL2018-091005'
ERROR - 2018-09-21 06:40:23 --> Query error: Table 'gemology_central_db.tbl_lab_reportas' doesn't exist - Invalid query: SELECT *
FROM `tbl_lab_reportAS` `t1`
LEFT JOIN `tbl_gem_memocardAS` `t2` ON `t1`.`reportid` = `t2`.`reportid`
WHERE `memoid` = 'GCL2018-091005'
ERROR - 2018-09-21 06:40:53 --> Query error: Unknown column 'tbl_t2.reportid' in 'on clause' - Invalid query: SELECT *
FROM `tbl_lab_report` AS `t1`
LEFT JOIN `tbl_gem_memocard` AS `t2` ON `t1`.`reportid` = `tbl_t2`.`reportid`
WHERE `memoid` = 'GCL2018-091005'
ERROR - 2018-09-21 06:42:17 --> Severity: Parsing Error --> syntax error, unexpected '$this' (T_VARIABLE) C:\wamp64\www\gem\application\models\Base_model.php 24
ERROR - 2018-09-21 06:43:26 --> Query error: Unknown column 'tbl_t2.reportid' in 'on clause' - Invalid query: SELECT *
FROM `tbl_lab_report` AS `t1`
LEFT JOIN `tbl_gem_memocard` AS `t2` ON `t1`.`reportid` = `tbl_t2`.`reportid`
WHERE `memoid` = 'GCL2018-091005'
ERROR - 2018-09-21 06:45:44 --> 404 Page Not Found: Assets/admin
ERROR - 2018-09-21 06:51:00 --> 404 Page Not Found: Assets/admin
ERROR - 2018-09-21 06:53:14 --> 404 Page Not Found: Assets/admin
ERROR - 2018-09-21 06:58:45 --> Query error: Unknown column 'tbl_lab_report.reportid' in 'field list' - Invalid query: SELECT `tbl_lab_report`.`reportid`, `tbl_gemstone_report`.`reportid`, `gsrid`, `rep_weight`
FROM `tbl_lab_report` AS `t1`
LEFT JOIN `tbl_gemstone_report` AS `t2` ON `t1`.`reportid` = `t2`.`reportid`
WHERE `gsrid` = 'GCL2018-091005'
AND `rep_weight` = '8.50'
ERROR - 2018-09-21 07:00:07 --> 404 Page Not Found: Assets/admin
ERROR - 2018-09-21 07:03:33 --> 404 Page Not Found: Report/index
