<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-09-03 07:40:43 --> 404 Page Not Found: Assets/css
ERROR - 2018-09-03 07:40:48 --> Severity: Notice --> Undefined variable: noOfComments C:\wamp64\www\gem\application\views\admin\profile.php 45
ERROR - 2018-09-03 07:40:48 --> Severity: Notice --> Undefined variable: total_unpaid_certificates C:\wamp64\www\gem\application\views\admin\profile.php 56
ERROR - 2018-09-03 07:41:04 --> Severity: Notice --> Undefined variable: img_url C:\wamp64\www\gem\application\views\admin\report\memo_card.php 124
ERROR - 2018-09-03 07:43:51 --> Severity: Notice --> Undefined variable: img_url C:\wamp64\www\gem\application\views\admin\report\memo_card.php 124
ERROR - 2018-09-03 08:47:40 --> Severity: Notice --> Undefined variable: img_allowed_type C:\wamp64\www\gem\application\controllers\admin\Report.php 345
ERROR - 2018-09-03 08:47:40 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\wamp64\www\gem\application\controllers\admin\Report.php 345
ERROR - 2018-09-03 08:47:40 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`gemology_central_db`.`tbl_certificate`, CONSTRAINT `FK_CustomerCertificate` FOREIGN KEY (`customerID`) REFERENCES `tbl_customer` (`custid`) ON UPDATE CASCADE) - Invalid query: INSERT INTO `tbl_certificate` (`cerno`, `cer_date`, `cer_object`, `cer_type`, `cer_identification`, `cer_weight`, `cer_gemWidth`, `cer_gemHeight`, `cer_gemlength`, `cer_cut`, `cer_shape`, `cer_color`, `cer_comment`, `customerID`, `cer_imagename`) VALUES ('GCL2018-091001', '2018-09-03', 'one', 'cert-report', 'diffusion', '8.50', '12.37', '9.64', '8.84', 'modified', 'oval', 'blue', 'Hello', '', '')
ERROR - 2018-09-03 08:50:29 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`gemology_central_db`.`tbl_certificate`, CONSTRAINT `FK_CustomerCertificate` FOREIGN KEY (`customerID`) REFERENCES `tbl_customer` (`custid`) ON UPDATE CASCADE) - Invalid query: INSERT INTO `tbl_certificate` (`cerno`, `cer_date`, `cer_object`, `cer_type`, `cer_identification`, `cer_weight`, `cer_gemWidth`, `cer_gemHeight`, `cer_gemlength`, `cer_cut`, `cer_shape`, `cer_color`, `cer_comment`, `customerID`, `cer_imagename`) VALUES ('GCL2018-091001', '2018-09-03', 'one', 'cert-report', 'diffusion', '8.50', '12.37', '9.64', '8.84', '', 'oval', 'blue', 'Hello ', '', 'GCL2018-091001.jpg')
ERROR - 2018-09-03 20:32:27 --> 404 Page Not Found: Assets/css
ERROR - 2018-09-03 20:33:46 --> Severity: Notice --> Undefined variable: noOfComments C:\wamp64\www\gem\application\views\admin\profile.php 45
ERROR - 2018-09-03 20:33:46 --> Severity: Notice --> Undefined variable: total_unpaid_certificates C:\wamp64\www\gem\application\views\admin\profile.php 56
ERROR - 2018-09-03 20:44:50 --> Severity: Notice --> Undefined variable: noOfComments C:\wamp64\www\gem\application\views\admin\profile.php 45
ERROR - 2018-09-03 20:44:50 --> Severity: Notice --> Undefined variable: total_unpaid_certificates C:\wamp64\www\gem\application\views\admin\profile.php 56
