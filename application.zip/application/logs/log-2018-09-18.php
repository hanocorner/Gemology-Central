<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-09-18 05:45:35 --> Severity: Notice --> Undefined property: stdClass::$mem_amount C:\wamp64\www\gem\application\views\admin\lab\report\edit.php 98
ERROR - 2018-09-18 05:46:26 --> Severity: Notice --> Undefined property: stdClass::$mem_amount C:\wamp64\www\gem\application\views\admin\lab\report\edit.php 98
ERROR - 2018-09-18 05:46:48 --> Severity: Notice --> Undefined property: stdClass::$mem_amount C:\wamp64\www\gem\application\views\admin\lab\report\edit.php 98
ERROR - 2018-09-18 05:48:35 --> Severity: Notice --> Undefined property: stdClass::$mem_amount C:\wamp64\www\gem\application\views\admin\lab\report\edit.php 99
ERROR - 2018-09-18 05:50:02 --> Severity: Notice --> Undefined property: stdClass::$mem_amount C:\wamp64\www\gem\application\views\admin\lab\report\edit.php 101
ERROR - 2018-09-18 07:01:02 --> 404 Page Not Found: Assets/admin
ERROR - 2018-09-18 07:02:05 --> 404 Page Not Found: Assets/admin
ERROR - 2018-09-18 07:04:20 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\gem\application\views\admin\lab\report\edit.php 48
ERROR - 2018-09-18 07:04:20 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\admin\lab\report\edit.php 48
ERROR - 2018-09-18 07:04:20 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\gem\application\views\admin\lab\report\edit.php 57
ERROR - 2018-09-18 07:04:20 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\admin\lab\report\edit.php 57
ERROR - 2018-09-18 07:04:20 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\gem\application\views\admin\lab\report\edit.php 111
ERROR - 2018-09-18 07:04:20 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\admin\lab\report\edit.php 111
ERROR - 2018-09-18 07:04:20 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\gem\application\views\admin\lab\report\edit.php 116
ERROR - 2018-09-18 07:04:20 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\admin\lab\report\edit.php 116
ERROR - 2018-09-18 07:04:20 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\gem\application\views\admin\lab\report\edit.php 125
ERROR - 2018-09-18 07:04:20 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\admin\lab\report\edit.php 125
ERROR - 2018-09-18 07:04:20 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\gem\application\views\admin\lab\report\edit.php 133
ERROR - 2018-09-18 07:04:20 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\admin\lab\report\edit.php 133
ERROR - 2018-09-18 07:04:20 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\gem\application\views\admin\lab\report\edit.php 138
ERROR - 2018-09-18 07:04:20 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\admin\lab\report\edit.php 138
ERROR - 2018-09-18 07:04:20 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\gem\application\views\admin\lab\report\edit.php 146
ERROR - 2018-09-18 07:04:20 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\admin\lab\report\edit.php 146
ERROR - 2018-09-18 07:04:21 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\gem\application\views\admin\lab\report\edit.php 156
ERROR - 2018-09-18 07:04:21 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\admin\lab\report\edit.php 156
ERROR - 2018-09-18 07:04:21 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\gem\application\views\admin\lab\report\edit.php 166
ERROR - 2018-09-18 07:04:21 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\admin\lab\report\edit.php 166
ERROR - 2018-09-18 07:04:21 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\gem\application\views\admin\lab\report\edit.php 176
ERROR - 2018-09-18 07:04:21 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\admin\lab\report\edit.php 176
ERROR - 2018-09-18 07:04:21 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\gem\application\views\admin\lab\report\edit.php 181
ERROR - 2018-09-18 07:04:21 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\admin\lab\report\edit.php 181
ERROR - 2018-09-18 07:05:00 --> 404 Page Not Found: Assets/admin
ERROR - 2018-09-18 07:05:42 --> Severity: Notice --> Undefined variable: memid C:\wamp64\www\gem\application\models\Report_model.php 96
ERROR - 2018-09-18 07:07:47 --> Severity: Notice --> Undefined variable: memid C:\wamp64\www\gem\application\models\Report_model.php 96
ERROR - 2018-09-18 07:08:45 --> 404 Page Not Found: Assets/admin
ERROR - 2018-09-18 07:09:21 --> Severity: Notice --> Undefined variable: memid C:\wamp64\www\gem\application\models\Report_model.php 96
ERROR - 2018-09-18 07:11:33 --> Severity: Notice --> Undefined variable: memid C:\wamp64\www\gem\application\models\Report_model.php 96
ERROR - 2018-09-18 07:12:57 --> Severity: Notice --> Undefined variable: memid C:\wamp64\www\gem\application\models\Report_model.php 96
ERROR - 2018-09-18 07:17:19 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\gem\application\views\admin\lab\report\edit.php 48
ERROR - 2018-09-18 07:17:19 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\admin\lab\report\edit.php 48
ERROR - 2018-09-18 07:17:19 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\gem\application\views\admin\lab\report\edit.php 57
ERROR - 2018-09-18 07:17:19 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\admin\lab\report\edit.php 57
ERROR - 2018-09-18 07:17:19 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\gem\application\views\admin\lab\report\edit.php 111
ERROR - 2018-09-18 07:17:19 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\admin\lab\report\edit.php 111
ERROR - 2018-09-18 07:17:19 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\gem\application\views\admin\lab\report\edit.php 116
ERROR - 2018-09-18 07:17:19 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\admin\lab\report\edit.php 116
ERROR - 2018-09-18 07:17:19 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\gem\application\views\admin\lab\report\edit.php 125
ERROR - 2018-09-18 07:17:19 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\admin\lab\report\edit.php 125
ERROR - 2018-09-18 07:17:19 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\gem\application\views\admin\lab\report\edit.php 133
ERROR - 2018-09-18 07:17:19 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\admin\lab\report\edit.php 133
ERROR - 2018-09-18 07:17:19 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\gem\application\views\admin\lab\report\edit.php 138
ERROR - 2018-09-18 07:17:19 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\admin\lab\report\edit.php 138
ERROR - 2018-09-18 07:17:20 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\gem\application\views\admin\lab\report\edit.php 146
ERROR - 2018-09-18 07:17:20 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\admin\lab\report\edit.php 146
ERROR - 2018-09-18 07:17:20 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\gem\application\views\admin\lab\report\edit.php 156
ERROR - 2018-09-18 07:17:20 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\admin\lab\report\edit.php 156
ERROR - 2018-09-18 07:17:20 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\gem\application\views\admin\lab\report\edit.php 166
ERROR - 2018-09-18 07:17:20 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\admin\lab\report\edit.php 166
ERROR - 2018-09-18 07:17:20 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\gem\application\views\admin\lab\report\edit.php 176
ERROR - 2018-09-18 07:17:20 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\admin\lab\report\edit.php 176
ERROR - 2018-09-18 07:17:20 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\gem\application\views\admin\lab\report\edit.php 181
ERROR - 2018-09-18 07:17:20 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\admin\lab\report\edit.php 181
ERROR - 2018-09-18 07:21:30 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\gem\application\views\admin\lab\report\edit.php 48
ERROR - 2018-09-18 07:21:30 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\admin\lab\report\edit.php 48
ERROR - 2018-09-18 07:21:30 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\gem\application\views\admin\lab\report\edit.php 57
ERROR - 2018-09-18 07:21:30 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\admin\lab\report\edit.php 57
ERROR - 2018-09-18 07:21:30 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\gem\application\views\admin\lab\report\edit.php 111
ERROR - 2018-09-18 07:21:30 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\admin\lab\report\edit.php 111
ERROR - 2018-09-18 07:21:30 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\gem\application\views\admin\lab\report\edit.php 116
ERROR - 2018-09-18 07:21:30 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\admin\lab\report\edit.php 116
ERROR - 2018-09-18 07:21:31 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\gem\application\views\admin\lab\report\edit.php 125
ERROR - 2018-09-18 07:21:31 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\admin\lab\report\edit.php 125
ERROR - 2018-09-18 07:21:31 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\gem\application\views\admin\lab\report\edit.php 133
ERROR - 2018-09-18 07:21:31 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\admin\lab\report\edit.php 133
ERROR - 2018-09-18 07:21:31 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\gem\application\views\admin\lab\report\edit.php 138
ERROR - 2018-09-18 07:21:31 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\admin\lab\report\edit.php 138
ERROR - 2018-09-18 07:21:31 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\gem\application\views\admin\lab\report\edit.php 146
ERROR - 2018-09-18 07:21:31 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\admin\lab\report\edit.php 146
ERROR - 2018-09-18 07:21:31 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\gem\application\views\admin\lab\report\edit.php 156
ERROR - 2018-09-18 07:21:31 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\admin\lab\report\edit.php 156
ERROR - 2018-09-18 07:21:31 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\gem\application\views\admin\lab\report\edit.php 166
ERROR - 2018-09-18 07:21:31 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\admin\lab\report\edit.php 166
ERROR - 2018-09-18 07:21:31 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\gem\application\views\admin\lab\report\edit.php 176
ERROR - 2018-09-18 07:21:31 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\admin\lab\report\edit.php 176
ERROR - 2018-09-18 07:21:31 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\gem\application\views\admin\lab\report\edit.php 181
ERROR - 2018-09-18 07:21:31 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\admin\lab\report\edit.php 181
ERROR - 2018-09-18 07:35:45 --> Severity: Notice --> Undefined variable: id C:\wamp64\www\gem\application\controllers\admin\Report.php 299
ERROR - 2018-09-18 07:35:45 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\gem\application\views\admin\lab\report\edit.php 48
ERROR - 2018-09-18 07:35:45 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\admin\lab\report\edit.php 48
ERROR - 2018-09-18 07:35:45 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\gem\application\views\admin\lab\report\edit.php 57
ERROR - 2018-09-18 07:35:45 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\admin\lab\report\edit.php 57
ERROR - 2018-09-18 07:35:45 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\gem\application\views\admin\lab\report\edit.php 111
ERROR - 2018-09-18 07:35:45 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\admin\lab\report\edit.php 111
ERROR - 2018-09-18 07:35:45 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\gem\application\views\admin\lab\report\edit.php 116
ERROR - 2018-09-18 07:35:45 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\admin\lab\report\edit.php 116
ERROR - 2018-09-18 07:35:45 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\gem\application\views\admin\lab\report\edit.php 125
ERROR - 2018-09-18 07:35:45 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\admin\lab\report\edit.php 125
ERROR - 2018-09-18 07:35:45 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\gem\application\views\admin\lab\report\edit.php 133
ERROR - 2018-09-18 07:35:45 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\admin\lab\report\edit.php 133
ERROR - 2018-09-18 07:35:45 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\gem\application\views\admin\lab\report\edit.php 138
ERROR - 2018-09-18 07:35:45 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\admin\lab\report\edit.php 138
ERROR - 2018-09-18 07:35:45 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\gem\application\views\admin\lab\report\edit.php 146
ERROR - 2018-09-18 07:35:45 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\admin\lab\report\edit.php 146
ERROR - 2018-09-18 07:35:45 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\gem\application\views\admin\lab\report\edit.php 156
ERROR - 2018-09-18 07:35:45 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\admin\lab\report\edit.php 156
ERROR - 2018-09-18 07:35:45 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\gem\application\views\admin\lab\report\edit.php 166
ERROR - 2018-09-18 07:35:45 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\admin\lab\report\edit.php 166
ERROR - 2018-09-18 07:35:45 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\gem\application\views\admin\lab\report\edit.php 176
ERROR - 2018-09-18 07:35:45 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\admin\lab\report\edit.php 176
ERROR - 2018-09-18 07:35:45 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\gem\application\views\admin\lab\report\edit.php 181
ERROR - 2018-09-18 07:35:45 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\admin\lab\report\edit.php 181
ERROR - 2018-09-18 07:37:01 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\gem\application\views\admin\lab\report\edit.php 48
ERROR - 2018-09-18 07:37:01 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\admin\lab\report\edit.php 48
ERROR - 2018-09-18 07:37:01 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\gem\application\views\admin\lab\report\edit.php 57
ERROR - 2018-09-18 07:37:01 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\admin\lab\report\edit.php 57
ERROR - 2018-09-18 07:37:01 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\gem\application\views\admin\lab\report\edit.php 111
ERROR - 2018-09-18 07:37:01 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\admin\lab\report\edit.php 111
ERROR - 2018-09-18 07:37:01 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\gem\application\views\admin\lab\report\edit.php 116
ERROR - 2018-09-18 07:37:01 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\admin\lab\report\edit.php 116
ERROR - 2018-09-18 07:37:01 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\gem\application\views\admin\lab\report\edit.php 125
ERROR - 2018-09-18 07:37:01 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\admin\lab\report\edit.php 125
ERROR - 2018-09-18 07:37:01 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\gem\application\views\admin\lab\report\edit.php 133
ERROR - 2018-09-18 07:37:01 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\admin\lab\report\edit.php 133
ERROR - 2018-09-18 07:37:02 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\gem\application\views\admin\lab\report\edit.php 138
ERROR - 2018-09-18 07:37:02 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\admin\lab\report\edit.php 138
ERROR - 2018-09-18 07:37:02 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\gem\application\views\admin\lab\report\edit.php 146
ERROR - 2018-09-18 07:37:02 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\admin\lab\report\edit.php 146
ERROR - 2018-09-18 07:37:02 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\gem\application\views\admin\lab\report\edit.php 156
ERROR - 2018-09-18 07:37:02 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\admin\lab\report\edit.php 156
ERROR - 2018-09-18 07:37:02 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\gem\application\views\admin\lab\report\edit.php 166
ERROR - 2018-09-18 07:37:02 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\admin\lab\report\edit.php 166
ERROR - 2018-09-18 07:37:02 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\gem\application\views\admin\lab\report\edit.php 176
ERROR - 2018-09-18 07:37:02 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\admin\lab\report\edit.php 176
ERROR - 2018-09-18 07:37:02 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\gem\application\views\admin\lab\report\edit.php 181
ERROR - 2018-09-18 07:37:02 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\admin\lab\report\edit.php 181
ERROR - 2018-09-18 08:14:29 --> Severity: Notice --> Undefined variable: id C:\wamp64\www\gem\application\controllers\admin\Report.php 284
ERROR - 2018-09-18 08:16:23 --> Severity: Notice --> Undefined variable: data C:\wamp64\www\gem\application\controllers\admin\Report.php 287
ERROR - 2018-09-18 21:50:20 --> Severity: Notice --> Undefined property: stdClass::$memoid C:\wamp64\www\gem\application\models\Report_model.php 79
