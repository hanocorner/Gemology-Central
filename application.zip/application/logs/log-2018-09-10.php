<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-09-10 06:21:53 --> 404 Page Not Found: Assets/css
ERROR - 2018-09-10 06:21:53 --> 404 Page Not Found: Assets/css
ERROR - 2018-09-10 06:21:57 --> Severity: Notice --> Undefined variable: noOfComments C:\wamp64\www\gem\application\views\admin\profile.php 45
ERROR - 2018-09-10 06:21:57 --> Severity: Notice --> Undefined variable: total_unpaid_certificates C:\wamp64\www\gem\application\views\admin\profile.php 56
ERROR - 2018-09-10 06:21:58 --> Severity: Notice --> Undefined variable: noOfComments C:\wamp64\www\gem\application\views\admin\profile.php 45
ERROR - 2018-09-10 06:21:58 --> Severity: Notice --> Undefined variable: total_unpaid_certificates C:\wamp64\www\gem\application\views\admin\profile.php 56
ERROR - 2018-09-10 06:28:08 --> Severity: Notice --> Undefined variable: start C:\wamp64\www\gem\application\controllers\admin\Report.php 174
ERROR - 2018-09-10 07:05:59 --> Severity: Notice --> Undefined variable: links C:\wamp64\www\gem\application\views\admin\report\customer_list.php 27
ERROR - 2018-09-10 07:06:00 --> Severity: Notice --> Undefined variable: links C:\wamp64\www\gem\application\views\admin\report\customer_list.php 27
ERROR - 2018-09-10 07:06:00 --> Severity: Notice --> Undefined variable: links C:\wamp64\www\gem\application\views\admin\report\customer_list.php 27
ERROR - 2018-09-10 07:06:00 --> Severity: Notice --> Undefined variable: links C:\wamp64\www\gem\application\views\admin\report\customer_list.php 27
ERROR - 2018-09-10 07:06:00 --> Severity: Notice --> Undefined variable: links C:\wamp64\www\gem\application\views\admin\report\customer_list.php 27
ERROR - 2018-09-10 09:16:33 --> Severity: Notice --> Array to string conversion C:\wamp64\www\gem\application\controllers\admin\Report.php 191
ERROR - 2018-09-10 09:16:33 --> Severity: Notice --> Array to string conversion C:\wamp64\www\gem\application\controllers\admin\Report.php 191
ERROR - 2018-09-10 09:16:33 --> Severity: Notice --> Array to string conversion C:\wamp64\www\gem\application\controllers\admin\Report.php 191
ERROR - 2018-09-10 09:16:33 --> Severity: Notice --> Array to string conversion C:\wamp64\www\gem\application\controllers\admin\Report.php 191
ERROR - 2018-09-10 09:16:34 --> Severity: Notice --> Array to string conversion C:\wamp64\www\gem\application\controllers\admin\Report.php 191
ERROR - 2018-09-10 21:28:48 --> 404 Page Not Found: Assets/css
ERROR - 2018-09-10 21:28:52 --> 404 Page Not Found: Assets/css
ERROR - 2018-09-10 21:28:58 --> Severity: Notice --> Undefined variable: noOfComments C:\wamp64\www\gem\application\views\admin\profile.php 45
ERROR - 2018-09-10 21:28:58 --> Severity: Notice --> Undefined variable: total_unpaid_certificates C:\wamp64\www\gem\application\views\admin\profile.php 56
ERROR - 2018-09-10 21:34:38 --> Severity: Error --> Call to undefined method Customer_model::get_certificate_data() C:\wamp64\www\gem\application\controllers\admin\Report.php 98
ERROR - 2018-09-10 21:44:31 --> Severity: Error --> Call to undefined method Customer_model::get_customer_data() C:\wamp64\www\gem\application\controllers\admin\Report.php 179
ERROR - 2018-09-10 22:07:32 --> Severity: Error --> Call to undefined method Customer_model::get_certificate_data() C:\wamp64\www\gem\application\controllers\admin\Report.php 98
ERROR - 2018-09-10 22:12:35 --> Query error: Table 'gemology_central_db.tbl_customer' doesn't exist - Invalid query: INSERT INTO `tbl_customer` (`cus_firstname`, `cus_lastname`, `cus_number`, `cus_email`) VALUES ('Dulip', 'mendis', '0771234567', 'dulip@hotmail.com')
ERROR - 2018-09-10 22:14:50 --> Query error: Table 'gemology_central_db.tbl_customer' doesn't exist - Invalid query: SELECT `custid`
FROM `tbl_customer`
ORDER BY `custid` DESC
 LIMIT 1
ERROR - 2018-09-10 22:17:34 --> Query error: Table 'gemology_central_db.tbl_customer' doesn't exist - Invalid query: SELECT COUNT(*) AS `numrows` FROM `tbl_customer`
ERROR - 2018-09-10 22:19:16 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\models\Customer_model.php 107
ERROR - 2018-09-10 22:19:16 --> Severity: Error --> Call to undefined method Report::set_gem_id() C:\wamp64\www\gem\application\controllers\admin\Report.php 285
ERROR - 2018-09-10 22:19:26 --> Severity: Error --> Call to undefined method Customer_model::get_customer_data() C:\wamp64\www\gem\application\controllers\admin\Report.php 179
ERROR - 2018-09-10 22:32:31 --> Severity: Error --> Call to undefined method Report::set_gem_id() C:\wamp64\www\gem\application\controllers\admin\Report.php 262
ERROR - 2018-09-10 22:32:39 --> Severity: Error --> Call to undefined method Customer_model::search_data() C:\wamp64\www\gem\application\controllers\admin\Report.php 158
ERROR - 2018-09-10 22:32:39 --> Severity: Error --> Call to undefined method Customer_model::search_data() C:\wamp64\www\gem\application\controllers\admin\Report.php 158
ERROR - 2018-09-10 22:32:40 --> Severity: Error --> Call to undefined method Customer_model::search_data() C:\wamp64\www\gem\application\controllers\admin\Report.php 158
ERROR - 2018-09-10 22:32:41 --> Severity: Error --> Call to undefined method Customer_model::search_data() C:\wamp64\www\gem\application\controllers\admin\Report.php 158
ERROR - 2018-09-10 22:32:41 --> Severity: Error --> Call to undefined method Customer_model::search_data() C:\wamp64\www\gem\application\controllers\admin\Report.php 158
ERROR - 2018-09-10 22:32:41 --> Severity: Error --> Call to undefined method Customer_model::search_data() C:\wamp64\www\gem\application\controllers\admin\Report.php 158
ERROR - 2018-09-10 22:32:42 --> Severity: Error --> Call to undefined method Customer_model::search_data() C:\wamp64\www\gem\application\controllers\admin\Report.php 158
ERROR - 2018-09-10 22:32:42 --> Severity: Error --> Call to undefined method Customer_model::search_data() C:\wamp64\www\gem\application\controllers\admin\Report.php 158
ERROR - 2018-09-10 22:33:15 --> Severity: Error --> Call to undefined method Customer_model::search_data() C:\wamp64\www\gem\application\controllers\admin\Report.php 158
ERROR - 2018-09-10 22:36:54 --> Query error: Duplicate entry 'GCLC-1' for key 'PRIMARY' - Invalid query: INSERT INTO `tbl_customer` (`custid`, `cus_firstname`, `cus_lastname`, `cus_number`, `cus_email`) VALUES ('GCLC-1', 'Yahoo', 'finance', '0784561239', 'fin@hotmail.com')
ERROR - 2018-09-10 22:41:46 --> Severity: Error --> Call to undefined method Customer_model::get_certificate_data() C:\wamp64\www\gem\application\controllers\admin\Report.php 170
ERROR - 2018-09-10 23:51:41 --> Severity: Error --> Call to undefined method Customer_model::sorted_data() C:\wamp64\www\gem\application\controllers\admin\Report.php 170
ERROR - 2018-09-10 23:52:05 --> Severity: Error --> Call to undefined method Customer_model::sorted_data() C:\wamp64\www\gem\application\controllers\admin\Report.php 170
ERROR - 2018-09-10 23:52:22 --> Severity: Notice --> Undefined property: Report::$Lab_model C:\wamp64\www\gem\application\controllers\admin\Report.php 170
ERROR - 2018-09-10 23:52:22 --> Severity: Error --> Call to a member function sorted_data() on null C:\wamp64\www\gem\application\controllers\admin\Report.php 170
ERROR - 2018-09-10 23:53:01 --> Query error: Unknown column 't1custid' in 'where clause' - Invalid query: SELECT * FROM `tbl_customer` as t1 LEFT JOIN `tbl_lab_report` as t2 ON t1.custid = t2.rep_customerID LEFT JOIN `tbl_gem_memocard` as t3
            ON t2.reportid = t3.reportid LEFT JOIN `tbl_gemstone_report` as t4 ON t2.reportid = t4.reportid WHERE t1custid = GCLC-1001
ERROR - 2018-09-10 23:53:18 --> Query error: Unknown column 'GCLC' in 'where clause' - Invalid query: SELECT * FROM `tbl_customer` as t1 LEFT JOIN `tbl_lab_report` as t2 ON t1.custid = t2.rep_customerID LEFT JOIN `tbl_gem_memocard` as t3
            ON t2.reportid = t3.reportid LEFT JOIN `tbl_gemstone_report` as t4 ON t2.reportid = t4.reportid WHERE t1.custid = GCLC-1001
ERROR - 2018-09-10 23:53:45 --> Severity: Notice --> Undefined property: stdClass::$cerno C:\wamp64\www\gem\application\views\admin\report\specific_data.php 40
ERROR - 2018-09-10 23:53:45 --> Severity: Notice --> Undefined property: stdClass::$cer_object C:\wamp64\www\gem\application\views\admin\report\specific_data.php 41
ERROR - 2018-09-10 23:53:45 --> Severity: Notice --> Undefined property: stdClass::$cer_weight C:\wamp64\www\gem\application\views\admin\report\specific_data.php 42
ERROR - 2018-09-10 23:53:45 --> Severity: Notice --> Undefined property: stdClass::$cer_color C:\wamp64\www\gem\application\views\admin\report\specific_data.php 43
ERROR - 2018-09-10 23:53:45 --> Severity: Notice --> Undefined property: stdClass::$cer_identification C:\wamp64\www\gem\application\views\admin\report\specific_data.php 44
