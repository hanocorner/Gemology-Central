<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-09-01 04:26:44 --> 404 Page Not Found: Assets/public
ERROR - 2018-09-01 04:30:39 --> 404 Page Not Found: Assets/public
ERROR - 2018-09-01 04:31:31 --> 404 Page Not Found: Assets/public
ERROR - 2018-09-01 04:31:53 --> 404 Page Not Found: Assets/public
ERROR - 2018-09-01 04:32:06 --> 404 Page Not Found: Assets/public
ERROR - 2018-09-01 04:32:20 --> 404 Page Not Found: Assets/public
ERROR - 2018-09-01 04:33:40 --> 404 Page Not Found: Assets/public
ERROR - 2018-09-01 04:33:44 --> 404 Page Not Found: Assets/public
ERROR - 2018-09-01 04:35:59 --> 404 Page Not Found: Assets/public
ERROR - 2018-09-01 04:36:05 --> 404 Page Not Found: Assets/public
ERROR - 2018-09-01 04:36:24 --> 404 Page Not Found: Assets/public
ERROR - 2018-09-01 04:36:35 --> 404 Page Not Found: Assets/public
ERROR - 2018-09-01 04:37:01 --> 404 Page Not Found: Assets/public
ERROR - 2018-09-01 04:38:23 --> 404 Page Not Found: Assets/public
ERROR - 2018-09-01 04:42:01 --> 404 Page Not Found: Assets/public
ERROR - 2018-09-01 04:42:10 --> 404 Page Not Found: Assets/public
ERROR - 2018-09-01 04:46:02 --> 404 Page Not Found: Assets/public
ERROR - 2018-09-01 04:47:17 --> 404 Page Not Found: Assets/public
ERROR - 2018-09-01 04:48:08 --> 404 Page Not Found: Assets/public
ERROR - 2018-09-01 04:49:10 --> 404 Page Not Found: Assets/public
ERROR - 2018-09-01 04:50:55 --> 404 Page Not Found: Assets/public
ERROR - 2018-09-01 04:51:33 --> 404 Page Not Found: Assets/public
ERROR - 2018-09-01 04:51:43 --> 404 Page Not Found: Assets/public
ERROR - 2018-09-01 04:54:06 --> 404 Page Not Found: Assets/public
ERROR - 2018-09-01 04:55:20 --> 404 Page Not Found: Assets/public
ERROR - 2018-09-01 04:58:40 --> 404 Page Not Found: Assets/public
ERROR - 2018-09-01 04:59:23 --> 404 Page Not Found: Assets/public
ERROR - 2018-09-01 05:00:22 --> 404 Page Not Found: Assets/public
ERROR - 2018-09-01 05:01:03 --> 404 Page Not Found: Assets/public
ERROR - 2018-09-01 05:09:07 --> 404 Page Not Found: Assets/images
ERROR - 2018-09-01 05:09:07 --> 404 Page Not Found: Assets/images
ERROR - 2018-09-01 05:09:07 --> 404 Page Not Found: Assets/images
ERROR - 2018-09-01 05:09:07 --> 404 Page Not Found: Assets/images
ERROR - 2018-09-01 05:09:35 --> 404 Page Not Found: Assets/images
ERROR - 2018-09-01 05:09:35 --> 404 Page Not Found: Assets/images
ERROR - 2018-09-01 05:09:35 --> 404 Page Not Found: Assets/images
ERROR - 2018-09-01 05:11:16 --> 404 Page Not Found: Assets/images
ERROR - 2018-09-01 05:11:16 --> 404 Page Not Found: Assets/images
ERROR - 2018-09-01 05:11:16 --> 404 Page Not Found: Assets/images
ERROR - 2018-09-01 05:11:16 --> 404 Page Not Found: Assets/images
ERROR - 2018-09-01 05:13:23 --> 404 Page Not Found: Assets/images
ERROR - 2018-09-01 05:13:23 --> 404 Page Not Found: Assets/images
ERROR - 2018-09-01 05:13:23 --> 404 Page Not Found: Assets/images
ERROR - 2018-09-01 05:13:24 --> 404 Page Not Found: Assets/images
ERROR - 2018-09-01 05:13:55 --> 404 Page Not Found: Assets/images
ERROR - 2018-09-01 05:13:55 --> 404 Page Not Found: Assets/images
ERROR - 2018-09-01 05:13:55 --> 404 Page Not Found: Assets/images
ERROR - 2018-09-01 05:13:55 --> 404 Page Not Found: Assets/images
ERROR - 2018-09-01 05:14:59 --> 404 Page Not Found: Assets/images
ERROR - 2018-09-01 05:14:59 --> 404 Page Not Found: Assets/images
ERROR - 2018-09-01 05:14:59 --> 404 Page Not Found: Assets/images
ERROR - 2018-09-01 05:14:59 --> 404 Page Not Found: Assets/images
ERROR - 2018-09-01 05:15:14 --> 404 Page Not Found: Assets/images
ERROR - 2018-09-01 05:15:14 --> 404 Page Not Found: Assets/images
ERROR - 2018-09-01 05:15:14 --> 404 Page Not Found: Assets/images
ERROR - 2018-09-01 05:15:14 --> 404 Page Not Found: Assets/images
ERROR - 2018-09-01 05:16:47 --> 404 Page Not Found: Assets/images
ERROR - 2018-09-01 05:16:47 --> 404 Page Not Found: Assets/images
ERROR - 2018-09-01 05:16:47 --> 404 Page Not Found: Assets/images
ERROR - 2018-09-01 05:16:48 --> 404 Page Not Found: Assets/images
ERROR - 2018-09-01 05:17:30 --> 404 Page Not Found: Assets/images
ERROR - 2018-09-01 05:17:30 --> 404 Page Not Found: Assets/images
ERROR - 2018-09-01 05:17:30 --> 404 Page Not Found: Assets/images
ERROR - 2018-09-01 05:17:30 --> 404 Page Not Found: Assets/images
ERROR - 2018-09-01 05:22:22 --> 404 Page Not Found: Assets/images
ERROR - 2018-09-01 05:22:22 --> 404 Page Not Found: Assets/images
ERROR - 2018-09-01 05:22:22 --> 404 Page Not Found: Assets/images
ERROR - 2018-09-01 05:22:22 --> 404 Page Not Found: Assets/images
ERROR - 2018-09-01 05:23:19 --> 404 Page Not Found: Assets/images
ERROR - 2018-09-01 05:23:19 --> 404 Page Not Found: Assets/images
ERROR - 2018-09-01 05:23:19 --> 404 Page Not Found: Assets/images
ERROR - 2018-09-01 05:23:19 --> 404 Page Not Found: Assets/images
ERROR - 2018-09-01 05:25:19 --> 404 Page Not Found: Assets/images
ERROR - 2018-09-01 05:25:19 --> 404 Page Not Found: Assets/images
ERROR - 2018-09-01 05:25:19 --> 404 Page Not Found: Assets/images
ERROR - 2018-09-01 05:25:19 --> 404 Page Not Found: Assets/images
ERROR - 2018-09-01 05:29:16 --> 404 Page Not Found: Assets/images
ERROR - 2018-09-01 05:29:16 --> 404 Page Not Found: Assets/images
ERROR - 2018-09-01 05:29:16 --> 404 Page Not Found: Assets/images
ERROR - 2018-09-01 05:30:24 --> 404 Page Not Found: Assets/images
ERROR - 2018-09-01 05:30:24 --> 404 Page Not Found: Assets/images
ERROR - 2018-09-01 05:30:24 --> 404 Page Not Found: Assets/images
ERROR - 2018-09-01 05:30:28 --> 404 Page Not Found: Assets/images
ERROR - 2018-09-01 05:30:28 --> 404 Page Not Found: Assets/images
ERROR - 2018-09-01 05:30:28 --> 404 Page Not Found: Assets/images
ERROR - 2018-09-01 05:30:28 --> 404 Page Not Found: Assets/images
ERROR - 2018-09-01 05:30:34 --> 404 Page Not Found: Assets/images
ERROR - 2018-09-01 05:30:34 --> 404 Page Not Found: Assets/images
ERROR - 2018-09-01 05:30:34 --> 404 Page Not Found: Assets/images
ERROR - 2018-09-01 05:30:34 --> 404 Page Not Found: Assets/images
ERROR - 2018-09-01 05:30:56 --> 404 Page Not Found: Assets/images
ERROR - 2018-09-01 05:30:57 --> 404 Page Not Found: Assets/images
ERROR - 2018-09-01 05:30:57 --> 404 Page Not Found: Assets/images
ERROR - 2018-09-01 05:30:57 --> 404 Page Not Found: Assets/images
ERROR - 2018-09-01 05:30:59 --> 404 Page Not Found: Assets/images
ERROR - 2018-09-01 05:30:59 --> 404 Page Not Found: Assets/images
ERROR - 2018-09-01 05:30:59 --> 404 Page Not Found: Assets/images
ERROR - 2018-09-01 05:31:00 --> 404 Page Not Found: Assets/images
ERROR - 2018-09-01 05:31:26 --> 404 Page Not Found: Assets/images
ERROR - 2018-09-01 05:31:26 --> 404 Page Not Found: Assets/images
ERROR - 2018-09-01 05:31:26 --> 404 Page Not Found: Assets/images
ERROR - 2018-09-01 05:31:47 --> 404 Page Not Found: Assets/images
ERROR - 2018-09-01 05:31:47 --> 404 Page Not Found: Assets/images
ERROR - 2018-09-01 05:31:47 --> 404 Page Not Found: Assets/images
ERROR - 2018-09-01 05:32:36 --> 404 Page Not Found: Assets/images
ERROR - 2018-09-01 05:32:36 --> 404 Page Not Found: Assets/images
ERROR - 2018-09-01 05:32:36 --> 404 Page Not Found: Assets/images
ERROR - 2018-09-01 05:32:36 --> 404 Page Not Found: Assets/images
ERROR - 2018-09-01 05:33:02 --> 404 Page Not Found: Assets/images
ERROR - 2018-09-01 05:33:02 --> 404 Page Not Found: Assets/images
ERROR - 2018-09-01 05:33:02 --> 404 Page Not Found: Assets/images
ERROR - 2018-09-01 05:33:13 --> 404 Page Not Found: Assets/images
ERROR - 2018-09-01 05:33:13 --> 404 Page Not Found: Assets/images
ERROR - 2018-09-01 05:33:13 --> 404 Page Not Found: Assets/images
ERROR - 2018-09-01 05:34:25 --> 404 Page Not Found: Assets/images
ERROR - 2018-09-01 05:34:25 --> 404 Page Not Found: Assets/images
ERROR - 2018-09-01 05:34:26 --> 404 Page Not Found: Assets/images
ERROR - 2018-09-01 05:34:26 --> 404 Page Not Found: Assets/images
ERROR - 2018-09-01 05:34:37 --> 404 Page Not Found: Assets/images
ERROR - 2018-09-01 05:34:37 --> 404 Page Not Found: Assets/images
ERROR - 2018-09-01 05:34:37 --> 404 Page Not Found: Assets/images
ERROR - 2018-09-01 05:34:54 --> 404 Page Not Found: Assets/images
ERROR - 2018-09-01 05:34:54 --> 404 Page Not Found: Assets/images
ERROR - 2018-09-01 05:34:54 --> 404 Page Not Found: Assets/images
ERROR - 2018-09-01 05:34:54 --> 404 Page Not Found: Assets/images
ERROR - 2018-09-01 05:35:56 --> 404 Page Not Found: Assets/images
ERROR - 2018-09-01 05:35:56 --> 404 Page Not Found: Assets/images
ERROR - 2018-09-01 05:35:56 --> 404 Page Not Found: Assets/images
ERROR - 2018-09-01 05:35:56 --> 404 Page Not Found: Assets/images
ERROR - 2018-09-01 05:36:55 --> 404 Page Not Found: Assets/images
ERROR - 2018-09-01 05:36:55 --> 404 Page Not Found: Assets/images
ERROR - 2018-09-01 05:36:55 --> 404 Page Not Found: Assets/images
ERROR - 2018-09-01 05:36:55 --> 404 Page Not Found: Assets/images
ERROR - 2018-09-01 05:39:49 --> 404 Page Not Found: Assets/images
ERROR - 2018-09-01 05:39:49 --> 404 Page Not Found: Assets/images
ERROR - 2018-09-01 05:39:49 --> 404 Page Not Found: Assets/images
ERROR - 2018-09-01 05:39:49 --> 404 Page Not Found: Assets/images
ERROR - 2018-09-01 05:41:52 --> 404 Page Not Found: Assets/images
ERROR - 2018-09-01 05:41:52 --> 404 Page Not Found: Assets/images
ERROR - 2018-09-01 05:41:52 --> 404 Page Not Found: Assets/images
ERROR - 2018-09-01 05:41:52 --> 404 Page Not Found: Assets/images
ERROR - 2018-09-01 05:43:07 --> 404 Page Not Found: Assets/images
ERROR - 2018-09-01 05:43:07 --> 404 Page Not Found: Assets/images
ERROR - 2018-09-01 05:44:18 --> 404 Page Not Found: Assets/images
ERROR - 2018-09-01 05:44:18 --> 404 Page Not Found: Assets/images
ERROR - 2018-09-01 05:44:19 --> 404 Page Not Found: Assets/images
ERROR - 2018-09-01 05:44:50 --> 404 Page Not Found: Assets/images
ERROR - 2018-09-01 05:44:50 --> 404 Page Not Found: Assets/images
ERROR - 2018-09-01 05:44:50 --> 404 Page Not Found: Assets/images
ERROR - 2018-09-01 05:45:52 --> 404 Page Not Found: Assets/images
ERROR - 2018-09-01 05:45:52 --> 404 Page Not Found: Assets/images
ERROR - 2018-09-01 05:45:52 --> 404 Page Not Found: Assets/images
ERROR - 2018-09-01 05:48:05 --> 404 Page Not Found: Assets/images
ERROR - 2018-09-01 05:48:05 --> 404 Page Not Found: Assets/images
ERROR - 2018-09-01 05:48:06 --> 404 Page Not Found: Assets/images
ERROR - 2018-09-01 05:48:07 --> 404 Page Not Found: Assets/images
ERROR - 2018-09-01 05:48:07 --> 404 Page Not Found: Assets/images
ERROR - 2018-09-01 05:48:08 --> 404 Page Not Found: Assets/images
ERROR - 2018-09-01 05:48:19 --> 404 Page Not Found: Assets/images
ERROR - 2018-09-01 05:48:19 --> 404 Page Not Found: Assets/images
ERROR - 2018-09-01 05:48:19 --> 404 Page Not Found: Assets/images
ERROR - 2018-09-01 05:48:22 --> 404 Page Not Found: Assets/images
ERROR - 2018-09-01 05:48:22 --> 404 Page Not Found: Assets/images
ERROR - 2018-09-01 05:48:22 --> 404 Page Not Found: Assets/images
ERROR - 2018-09-01 05:56:36 --> 404 Page Not Found: Assets/images
ERROR - 2018-09-01 05:56:36 --> 404 Page Not Found: Assets/images
ERROR - 2018-09-01 05:56:36 --> 404 Page Not Found: Assets/images
ERROR - 2018-09-01 05:56:37 --> 404 Page Not Found: Assets/images
ERROR - 2018-09-01 05:56:47 --> 404 Page Not Found: Assets/images
ERROR - 2018-09-01 05:56:47 --> 404 Page Not Found: Assets/images
ERROR - 2018-09-01 05:56:47 --> 404 Page Not Found: Assets/images
ERROR - 2018-09-01 05:56:47 --> 404 Page Not Found: Assets/images
ERROR - 2018-09-01 05:57:07 --> 404 Page Not Found: Assets/images
ERROR - 2018-09-01 05:58:36 --> 404 Page Not Found: Assets/images
ERROR - 2018-09-01 05:58:39 --> 404 Page Not Found: Assets/images
ERROR - 2018-09-01 05:59:38 --> Severity: Notice --> Undefined variable: body C:\wamp64\www\gem\application\views\public\about.php 58
ERROR - 2018-09-01 05:59:38 --> Severity: Notice --> Undefined variable: body C:\wamp64\www\gem\application\views\public\about.php 58
ERROR - 2018-09-01 05:59:38 --> Severity: Notice --> Undefined variable: body C:\wamp64\www\gem\application\views\public\about.php 58
ERROR - 2018-09-01 05:59:38 --> Severity: Notice --> Undefined variable: body C:\wamp64\www\gem\application\views\public\about.php 58
ERROR - 2018-09-01 05:59:38 --> 404 Page Not Found: Assets/images
ERROR - 2018-09-01 05:59:57 --> Severity: Notice --> Undefined property: stdClass::$body C:\wamp64\www\gem\application\views\public\about.php 58
ERROR - 2018-09-01 05:59:57 --> Severity: Notice --> Undefined property: stdClass::$body C:\wamp64\www\gem\application\views\public\about.php 58
ERROR - 2018-09-01 05:59:57 --> Severity: Notice --> Undefined property: stdClass::$body C:\wamp64\www\gem\application\views\public\about.php 58
ERROR - 2018-09-01 05:59:57 --> Severity: Notice --> Undefined property: stdClass::$body C:\wamp64\www\gem\application\views\public\about.php 58
ERROR - 2018-09-01 05:59:57 --> 404 Page Not Found: Assets/images
ERROR - 2018-09-01 06:00:00 --> Severity: Notice --> Undefined property: stdClass::$body C:\wamp64\www\gem\application\views\public\about.php 58
ERROR - 2018-09-01 06:00:00 --> Severity: Notice --> Undefined property: stdClass::$body C:\wamp64\www\gem\application\views\public\about.php 58
ERROR - 2018-09-01 06:00:00 --> Severity: Notice --> Undefined property: stdClass::$body C:\wamp64\www\gem\application\views\public\about.php 58
ERROR - 2018-09-01 06:00:00 --> Severity: Notice --> Undefined property: stdClass::$body C:\wamp64\www\gem\application\views\public\about.php 58
ERROR - 2018-09-01 06:00:01 --> 404 Page Not Found: Assets/images
ERROR - 2018-09-01 06:00:26 --> 404 Page Not Found: Assets/images
ERROR - 2018-09-01 06:01:05 --> 404 Page Not Found: Assets/images
ERROR - 2018-09-01 06:03:10 --> 404 Page Not Found: Assets/images
ERROR - 2018-09-01 06:03:17 --> 404 Page Not Found: Assets/images
ERROR - 2018-09-01 06:03:36 --> 404 Page Not Found: Assets/images
ERROR - 2018-09-01 06:04:09 --> 404 Page Not Found: Assets/images
ERROR - 2018-09-01 06:04:22 --> 404 Page Not Found: Assets/images
ERROR - 2018-09-01 06:05:36 --> 404 Page Not Found: Assets/images
ERROR - 2018-09-01 06:05:48 --> 404 Page Not Found: Assets/images
ERROR - 2018-09-01 06:06:12 --> 404 Page Not Found: Assets/images
ERROR - 2018-09-01 06:06:39 --> 404 Page Not Found: Assets/images
ERROR - 2018-09-01 06:07:23 --> 404 Page Not Found: Assets/images
ERROR - 2018-09-01 06:07:43 --> 404 Page Not Found: Assets/images
ERROR - 2018-09-01 06:07:52 --> 404 Page Not Found: Assets/images
ERROR - 2018-09-01 06:09:52 --> 404 Page Not Found: Assets/images
ERROR - 2018-09-01 06:10:27 --> 404 Page Not Found: Assets/images
ERROR - 2018-09-01 06:10:27 --> 404 Page Not Found: Assets/images
ERROR - 2018-09-01 06:10:27 --> 404 Page Not Found: Assets/images
ERROR - 2018-09-01 06:11:16 --> 404 Page Not Found: Assets/images
ERROR - 2018-09-01 06:11:16 --> 404 Page Not Found: Assets/images
ERROR - 2018-09-01 06:11:16 --> 404 Page Not Found: Assets/images
ERROR - 2018-09-01 06:11:28 --> 404 Page Not Found: Assets/images
ERROR - 2018-09-01 06:11:28 --> 404 Page Not Found: Assets/images
ERROR - 2018-09-01 06:16:32 --> Severity: Notice --> Undefined variable: key C:\wamp64\www\gem\application\views\public\blog.php 12
ERROR - 2018-09-01 06:16:32 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\public\blog.php 12
ERROR - 2018-09-01 06:30:06 --> Severity: Notice --> Undefined property: stdClass::$body C:\wamp64\www\gem\application\views\public\blog.php 33
ERROR - 2018-09-01 06:30:06 --> Severity: Notice --> Undefined property: stdClass::$body C:\wamp64\www\gem\application\views\public\blog.php 33
ERROR - 2018-09-01 06:35:58 --> Severity: Notice --> Undefined variable: data C:\wamp64\www\gem\application\controllers\Base.php 57
ERROR - 2018-09-01 07:04:25 --> 404 Page Not Found: Captcha_imgjpg/1535765664.846.jpg
ERROR - 2018-09-01 07:05:25 --> 404 Page Not Found: Captcha_imgjpg/1535765725.7777.jpg
ERROR - 2018-09-01 07:05:29 --> 404 Page Not Found: Captcha_imgjpg/1535765729.2665.jpg
ERROR - 2018-09-01 07:06:39 --> 404 Page Not Found: Captcha1535765664846jpg/1535765799.278.jpg
ERROR - 2018-09-01 07:07:27 --> 404 Page Not Found: Captcha1535765664846jpg/1535765846.978.jpg
ERROR - 2018-09-01 07:07:27 --> 404 Page Not Found: Assets/public
ERROR - 2018-09-01 07:07:27 --> 404 Page Not Found: Assets/public
ERROR - 2018-09-01 07:12:08 --> 404 Page Not Found: Assets/public
ERROR - 2018-09-01 07:12:08 --> 404 Page Not Found: Assets/public
ERROR - 2018-09-01 07:12:14 --> 404 Page Not Found: Assets/public
ERROR - 2018-09-01 07:12:14 --> 404 Page Not Found: Assets/public
ERROR - 2018-09-01 07:13:22 --> 404 Page Not Found: Assets/public
ERROR - 2018-09-01 07:19:34 --> 404 Page Not Found: Assets/public
ERROR - 2018-09-01 07:19:34 --> 404 Page Not Found: Assets/public
ERROR - 2018-09-01 07:19:34 --> 404 Page Not Found: Assets/public
ERROR - 2018-09-01 07:19:34 --> 404 Page Not Found: Assets/public
ERROR - 2018-09-01 07:19:34 --> 404 Page Not Found: Assets/public
ERROR - 2018-09-01 07:19:34 --> 404 Page Not Found: Assets/public
ERROR - 2018-09-01 07:19:34 --> 404 Page Not Found: Assets/public
ERROR - 2018-09-01 08:03:50 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\public\report\report_verified.php 10
ERROR - 2018-09-01 08:03:50 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\public\report\report_verified.php 21
ERROR - 2018-09-01 08:03:50 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\public\report\report_verified.php 32
ERROR - 2018-09-01 08:03:50 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\public\report\report_verified.php 43
ERROR - 2018-09-01 08:03:50 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\public\report\report_verified.php 57
ERROR - 2018-09-01 08:03:50 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\public\report\report_verified.php 75
ERROR - 2018-09-01 08:03:50 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\public\report\report_verified.php 87
ERROR - 2018-09-01 08:03:50 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\public\report\report_verified.php 87
ERROR - 2018-09-01 08:03:50 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\public\report\report_verified.php 87
ERROR - 2018-09-01 08:03:50 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\public\report\report_verified.php 99
ERROR - 2018-09-01 08:03:50 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\public\report\report_verified.php 111
ERROR - 2018-09-01 08:03:50 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\public\report\report_verified.php 123
ERROR - 2018-09-01 08:03:50 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\public\report\report_verified.php 135
ERROR - 2018-09-01 08:08:16 --> 404 Page Not Found: Report_verification/index
ERROR - 2018-09-01 08:13:58 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\public\report\report_verified.php 10
ERROR - 2018-09-01 08:13:58 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\public\report\report_verified.php 21
ERROR - 2018-09-01 08:13:58 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\public\report\report_verified.php 32
ERROR - 2018-09-01 08:13:58 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\public\report\report_verified.php 43
ERROR - 2018-09-01 08:13:58 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\public\report\report_verified.php 57
ERROR - 2018-09-01 08:13:58 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\public\report\report_verified.php 75
ERROR - 2018-09-01 08:13:58 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\public\report\report_verified.php 87
ERROR - 2018-09-01 08:13:58 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\public\report\report_verified.php 87
ERROR - 2018-09-01 08:13:58 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\public\report\report_verified.php 87
ERROR - 2018-09-01 08:13:58 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\public\report\report_verified.php 99
ERROR - 2018-09-01 08:13:58 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\public\report\report_verified.php 111
ERROR - 2018-09-01 08:13:58 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\public\report\report_verified.php 123
ERROR - 2018-09-01 08:13:58 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\public\report\report_verified.php 135
ERROR - 2018-09-01 08:14:50 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\public\report\report_verified.php 10
ERROR - 2018-09-01 08:14:50 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\public\report\report_verified.php 21
ERROR - 2018-09-01 08:14:50 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\public\report\report_verified.php 32
ERROR - 2018-09-01 08:14:50 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\public\report\report_verified.php 43
ERROR - 2018-09-01 08:14:50 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\public\report\report_verified.php 57
ERROR - 2018-09-01 08:14:50 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\public\report\report_verified.php 75
ERROR - 2018-09-01 08:14:50 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\public\report\report_verified.php 87
ERROR - 2018-09-01 08:14:50 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\public\report\report_verified.php 87
ERROR - 2018-09-01 08:14:50 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\public\report\report_verified.php 87
ERROR - 2018-09-01 08:14:50 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\public\report\report_verified.php 99
ERROR - 2018-09-01 08:14:50 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\public\report\report_verified.php 111
ERROR - 2018-09-01 08:14:50 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\public\report\report_verified.php 123
ERROR - 2018-09-01 08:14:50 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\public\report\report_verified.php 135
ERROR - 2018-09-01 08:14:59 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\public\report\report_verified.php 10
ERROR - 2018-09-01 08:14:59 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\public\report\report_verified.php 21
ERROR - 2018-09-01 08:14:59 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\public\report\report_verified.php 32
ERROR - 2018-09-01 08:14:59 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\public\report\report_verified.php 43
ERROR - 2018-09-01 08:14:59 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\public\report\report_verified.php 57
ERROR - 2018-09-01 08:14:59 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\public\report\report_verified.php 75
ERROR - 2018-09-01 08:14:59 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\public\report\report_verified.php 87
ERROR - 2018-09-01 08:14:59 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\public\report\report_verified.php 87
ERROR - 2018-09-01 08:14:59 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\public\report\report_verified.php 87
ERROR - 2018-09-01 08:14:59 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\public\report\report_verified.php 99
ERROR - 2018-09-01 08:14:59 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\public\report\report_verified.php 111
ERROR - 2018-09-01 08:14:59 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\public\report\report_verified.php 123
ERROR - 2018-09-01 08:14:59 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\public\report\report_verified.php 135
ERROR - 2018-09-01 08:15:45 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\public\report\report_verified.php 10
ERROR - 2018-09-01 08:15:45 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\public\report\report_verified.php 21
ERROR - 2018-09-01 08:15:45 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\public\report\report_verified.php 32
ERROR - 2018-09-01 08:15:45 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\public\report\report_verified.php 43
ERROR - 2018-09-01 08:15:45 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\public\report\report_verified.php 57
ERROR - 2018-09-01 08:15:45 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\public\report\report_verified.php 75
ERROR - 2018-09-01 08:15:45 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\public\report\report_verified.php 87
ERROR - 2018-09-01 08:15:45 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\public\report\report_verified.php 87
ERROR - 2018-09-01 08:15:45 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\public\report\report_verified.php 87
ERROR - 2018-09-01 08:15:45 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\public\report\report_verified.php 99
ERROR - 2018-09-01 08:15:45 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\public\report\report_verified.php 111
ERROR - 2018-09-01 08:15:45 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\public\report\report_verified.php 123
ERROR - 2018-09-01 08:15:45 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\public\report\report_verified.php 135
ERROR - 2018-09-01 08:16:03 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\public\report\report_verified.php 10
ERROR - 2018-09-01 08:16:03 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\public\report\report_verified.php 21
ERROR - 2018-09-01 08:16:03 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\public\report\report_verified.php 32
ERROR - 2018-09-01 08:16:03 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\public\report\report_verified.php 43
ERROR - 2018-09-01 08:16:03 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\public\report\report_verified.php 57
ERROR - 2018-09-01 08:16:03 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\public\report\report_verified.php 75
ERROR - 2018-09-01 08:16:03 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\public\report\report_verified.php 87
ERROR - 2018-09-01 08:16:03 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\public\report\report_verified.php 87
ERROR - 2018-09-01 08:16:03 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\public\report\report_verified.php 87
ERROR - 2018-09-01 08:16:03 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\public\report\report_verified.php 99
ERROR - 2018-09-01 08:16:03 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\public\report\report_verified.php 111
ERROR - 2018-09-01 08:16:03 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\public\report\report_verified.php 123
ERROR - 2018-09-01 08:16:03 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\public\report\report_verified.php 135
ERROR - 2018-09-01 08:46:37 --> 404 Page Not Found: Assets/public
ERROR - 2018-09-01 08:46:37 --> 404 Page Not Found: Assets/public
ERROR - 2018-09-01 08:46:38 --> 404 Page Not Found: Assets/public
ERROR - 2018-09-01 08:46:38 --> 404 Page Not Found: Assets/public
ERROR - 2018-09-01 08:46:38 --> 404 Page Not Found: Assets/public
ERROR - 2018-09-01 08:46:38 --> 404 Page Not Found: Assets/public
ERROR - 2018-09-01 08:48:58 --> 404 Page Not Found: Assets/public
ERROR - 2018-09-01 08:48:58 --> 404 Page Not Found: Assets/public
ERROR - 2018-09-01 08:48:58 --> 404 Page Not Found: Assets/public
ERROR - 2018-09-01 08:48:58 --> 404 Page Not Found: Assets/public
ERROR - 2018-09-01 08:49:26 --> 404 Page Not Found: Assets/public
ERROR - 2018-09-01 08:49:26 --> 404 Page Not Found: Assets/public
ERROR - 2018-09-01 08:49:26 --> 404 Page Not Found: Assets/public
ERROR - 2018-09-01 08:49:26 --> 404 Page Not Found: Assets/public
ERROR - 2018-09-01 08:51:46 --> 404 Page Not Found: Assets/public
ERROR - 2018-09-01 08:51:46 --> 404 Page Not Found: Assets/public
ERROR - 2018-09-01 08:51:46 --> 404 Page Not Found: Assets/public
ERROR - 2018-09-01 08:51:46 --> 404 Page Not Found: Assets/public
ERROR - 2018-09-01 08:52:07 --> 404 Page Not Found: Assets/public
ERROR - 2018-09-01 08:52:07 --> 404 Page Not Found: Assets/public
ERROR - 2018-09-01 08:52:07 --> 404 Page Not Found: Assets/public
ERROR - 2018-09-01 08:52:07 --> 404 Page Not Found: Assets/public
ERROR - 2018-09-01 08:55:39 --> 404 Page Not Found: Assets/public
ERROR - 2018-09-01 08:55:39 --> 404 Page Not Found: Assets/public
ERROR - 2018-09-01 08:55:39 --> 404 Page Not Found: Assets/images
ERROR - 2018-09-01 08:56:09 --> 404 Page Not Found: Assets/public
ERROR - 2018-09-01 08:56:09 --> 404 Page Not Found: Assets/public
ERROR - 2018-09-01 08:56:09 --> 404 Page Not Found: Assets/public
ERROR - 2018-09-01 08:56:09 --> 404 Page Not Found: Assets/public
ERROR - 2018-09-01 08:59:35 --> 404 Page Not Found: Assets/public
ERROR - 2018-09-01 08:59:35 --> 404 Page Not Found: Assets/public
ERROR - 2018-09-01 08:59:36 --> 404 Page Not Found: Assets/public
ERROR - 2018-09-01 08:59:36 --> 404 Page Not Found: Assets/public
ERROR - 2018-09-01 08:59:51 --> 404 Page Not Found: Assets/public
ERROR - 2018-09-01 08:59:51 --> 404 Page Not Found: Assets/public
ERROR - 2018-09-01 08:59:56 --> 404 Page Not Found: Assets/public
ERROR - 2018-09-01 08:59:56 --> 404 Page Not Found: Assets/public
ERROR - 2018-09-01 08:59:56 --> 404 Page Not Found: Assets/public
ERROR - 2018-09-01 09:00:29 --> 404 Page Not Found: Assets/public
ERROR - 2018-09-01 09:00:29 --> 404 Page Not Found: Assets/public
ERROR - 2018-09-01 09:00:29 --> 404 Page Not Found: Assets/public
ERROR - 2018-09-01 09:01:11 --> 404 Page Not Found: Assets/public
ERROR - 2018-09-01 09:01:11 --> 404 Page Not Found: Assets/public
ERROR - 2018-09-01 09:01:11 --> 404 Page Not Found: Assets/public
ERROR - 2018-09-01 09:01:14 --> 404 Page Not Found: Assets/public
ERROR - 2018-09-01 09:01:14 --> 404 Page Not Found: Assets/public
ERROR - 2018-09-01 09:01:14 --> 404 Page Not Found: Assets/public
ERROR - 2018-09-01 09:01:35 --> 404 Page Not Found: Assets/public
ERROR - 2018-09-01 09:01:35 --> 404 Page Not Found: Assets/public
ERROR - 2018-09-01 09:01:35 --> 404 Page Not Found: Assets/public
ERROR - 2018-09-01 09:03:13 --> 404 Page Not Found: Assets/public
ERROR - 2018-09-01 09:06:37 --> 404 Page Not Found: Assets/public
ERROR - 2018-09-01 09:12:08 --> 404 Page Not Found: Assets/public
ERROR - 2018-09-01 12:01:02 --> 404 Page Not Found: Assets/public
ERROR - 2018-09-01 12:01:07 --> 404 Page Not Found: Assets/public
ERROR - 2018-09-01 12:01:15 --> 404 Page Not Found: Assets/public
