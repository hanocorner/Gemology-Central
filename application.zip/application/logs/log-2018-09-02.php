<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-09-02 07:36:45 --> 404 Page Not Found: Assets/css
ERROR - 2018-09-02 07:36:50 --> Severity: Notice --> Undefined variable: noOfComments C:\wamp64\www\gem\application\views\admin\profile.php 45
ERROR - 2018-09-02 07:36:50 --> Severity: Notice --> Undefined variable: total_unpaid_certificates C:\wamp64\www\gem\application\views\admin\profile.php 56
