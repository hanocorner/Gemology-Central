<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-09-11 00:00:59 --> Severity: Notice --> Undefined variable: data C:\wamp64\www\gem\application\views\admin\report\specific_data.php 4
ERROR - 2018-09-11 00:00:59 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\admin\report\specific_data.php 4
ERROR - 2018-09-11 00:00:59 --> Severity: Notice --> Undefined variable: data C:\wamp64\www\gem\application\views\admin\report\specific_data.php 4
ERROR - 2018-09-11 00:00:59 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\admin\report\specific_data.php 4
ERROR - 2018-09-11 00:00:59 --> Severity: Notice --> Undefined variable: data C:\wamp64\www\gem\application\views\admin\report\specific_data.php 5
ERROR - 2018-09-11 00:00:59 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\admin\report\specific_data.php 5
ERROR - 2018-09-11 00:00:59 --> Severity: Notice --> Undefined variable: data C:\wamp64\www\gem\application\views\admin\report\specific_data.php 10
ERROR - 2018-09-11 00:00:59 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\admin\report\specific_data.php 10
ERROR - 2018-09-11 00:00:59 --> Severity: Notice --> Undefined property: stdClass::$rep_identification C:\wamp64\www\gem\application\views\admin\report\specific_data.php 44
ERROR - 2018-09-11 00:00:59 --> Severity: Notice --> Undefined property: stdClass::$rep_identification C:\wamp64\www\gem\application\views\admin\report\specific_data.php 91
ERROR - 2018-09-11 00:03:22 --> Severity: Notice --> Undefined variable: data C:\wamp64\www\gem\application\views\admin\report\specific_data.php 4
ERROR - 2018-09-11 00:03:22 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\admin\report\specific_data.php 4
ERROR - 2018-09-11 00:03:22 --> Severity: Notice --> Undefined variable: data C:\wamp64\www\gem\application\views\admin\report\specific_data.php 4
ERROR - 2018-09-11 00:03:22 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\admin\report\specific_data.php 4
ERROR - 2018-09-11 00:03:22 --> Severity: Notice --> Undefined variable: data C:\wamp64\www\gem\application\views\admin\report\specific_data.php 5
ERROR - 2018-09-11 00:03:22 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\admin\report\specific_data.php 5
ERROR - 2018-09-11 00:03:22 --> Severity: Notice --> Undefined variable: data C:\wamp64\www\gem\application\views\admin\report\specific_data.php 10
ERROR - 2018-09-11 00:03:22 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\views\admin\report\specific_data.php 10
ERROR - 2018-09-11 00:03:22 --> Severity: Notice --> Undefined property: stdClass::$rep_identification C:\wamp64\www\gem\application\views\admin\report\specific_data.php 44
ERROR - 2018-09-11 00:03:22 --> Severity: Notice --> Undefined property: stdClass::$rep_identification C:\wamp64\www\gem\application\views\admin\report\specific_data.php 91
ERROR - 2018-09-11 00:05:09 --> Severity: Notice --> Undefined property: stdClass::$rep_identification C:\wamp64\www\gem\application\views\admin\report\specific_data.php 45
ERROR - 2018-09-11 00:05:09 --> Severity: Notice --> Undefined property: stdClass::$rep_identification C:\wamp64\www\gem\application\views\admin\report\specific_data.php 93
ERROR - 2018-09-11 06:37:47 --> 404 Page Not Found: Assets/css
ERROR - 2018-09-11 06:58:23 --> 404 Page Not Found: Assets/admin
ERROR - 2018-09-11 07:00:56 --> Query error: Table 'gemology_central_db.tbl_certificate' doesn't exist - Invalid query: SELECT COUNT(*) AS total FROM tbl_postComments, tbl_certificate
ERROR - 2018-09-11 07:01:38 --> Severity: Notice --> Undefined variable: noOfComments C:\wamp64\www\gem\application\views\admin\profile.php 45
ERROR - 2018-09-11 07:01:39 --> Severity: Notice --> Undefined variable: total_unpaid_certificates C:\wamp64\www\gem\application\views\admin\profile.php 56
ERROR - 2018-09-11 20:37:56 --> Severity: Notice --> Undefined variable: noOfComments C:\wamp64\www\gem\application\views\admin\profile.php 45
ERROR - 2018-09-11 20:37:56 --> Severity: Notice --> Undefined variable: total_unpaid_certificates C:\wamp64\www\gem\application\views\admin\profile.php 56
ERROR - 2018-09-11 20:56:10 --> Severity: Notice --> Undefined variable: noOfComments C:\wamp64\www\gem\application\views\admin\profile.php 45
ERROR - 2018-09-11 20:56:10 --> Severity: Notice --> Undefined variable: total_unpaid_certificates C:\wamp64\www\gem\application\views\admin\profile.php 56
