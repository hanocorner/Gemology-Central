<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-09-29 21:17:14 --> 404 Page Not Found: Assets/admin
ERROR - 2018-09-29 21:17:22 --> 404 Page Not Found: admin/R/verbalid
ERROR - 2018-09-29 21:17:30 --> Severity: Parsing Error --> syntax error, unexpected '(int)' (int) (T_INT_CAST) C:\wamp64\www\gem\application\libraries\Id.php 24
ERROR - 2018-09-29 21:21:26 --> Severity: 4096 --> Object of class Id could not be converted to string C:\wamp64\www\gem\application\libraries\Id.php 75
ERROR - 2018-09-29 21:44:46 --> Severity: Notice --> Undefined offset: 0 C:\wamp64\www\gem\application\libraries\Id.php 96
ERROR - 2018-09-29 21:50:24 --> Severity: Compile Error --> Cannot use [] for reading C:\wamp64\www\gem\application\libraries\Id.php 96
ERROR - 2018-09-29 21:50:31 --> Severity: Notice --> Undefined offset: 0 C:\wamp64\www\gem\application\libraries\Id.php 96
ERROR - 2018-09-29 21:52:25 --> Severity: Parsing Error --> syntax error, unexpected '}' C:\wamp64\www\gem\application\libraries\Id.php 99
ERROR - 2018-09-29 21:52:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\gem\application\libraries\Id.php 105
ERROR - 2018-09-29 21:52:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\gem\application\libraries\Id.php 105
ERROR - 2018-09-29 21:53:09 --> Severity: Warning --> Illegal string offset 'format' C:\wamp64\www\gem\application\libraries\Id.php 105
ERROR - 2018-09-29 21:53:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\gem\application\libraries\Id.php 105
ERROR - 2018-09-29 21:53:09 --> Severity: Notice --> Undefined index: format C:\wamp64\www\gem\application\libraries\Id.php 105
ERROR - 2018-09-29 21:53:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\gem\application\libraries\Id.php 105
ERROR - 2018-09-29 21:54:30 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\gem\application\libraries\Id.php 105
ERROR - 2018-09-29 21:54:30 --> Severity: Warning --> Illegal string offset 'month' C:\wamp64\www\gem\application\libraries\Id.php 108
ERROR - 2018-09-29 21:54:30 --> Severity: Warning --> Illegal string offset 'month' C:\wamp64\www\gem\application\libraries\Id.php 108
ERROR - 2018-09-29 21:55:48 --> Severity: Parsing Error --> syntax error, unexpected '$this' (T_VARIABLE) C:\wamp64\www\gem\application\libraries\Id.php 99
ERROR - 2018-09-29 21:55:54 --> Severity: Warning --> Illegal string offset 'month' C:\wamp64\www\gem\application\libraries\Id.php 109
ERROR - 2018-09-29 21:55:54 --> Severity: Warning --> Illegal string offset 'month' C:\wamp64\www\gem\application\libraries\Id.php 109
ERROR - 2018-09-29 22:00:22 --> Severity: Parsing Error --> syntax error, unexpected '}' C:\wamp64\www\gem\application\libraries\Id.php 111
ERROR - 2018-09-29 22:00:29 --> Severity: Warning --> Illegal offset type C:\wamp64\www\gem\application\libraries\Id.php 110
ERROR - 2018-09-29 22:00:29 --> Severity: Warning --> Illegal offset type C:\wamp64\www\gem\application\libraries\Id.php 110
ERROR - 2018-09-29 22:00:29 --> Severity: Warning --> Illegal offset type C:\wamp64\www\gem\application\libraries\Id.php 110
ERROR - 2018-09-29 22:00:29 --> Severity: Notice --> Array to string conversion C:\wamp64\www\gem\application\libraries\Id.php 112
ERROR - 2018-09-29 22:00:29 --> Severity: Notice --> Undefined index: 09 C:\wamp64\www\gem\application\libraries\Id.php 110
ERROR - 2018-09-29 22:00:29 --> Severity: Notice --> Undefined index: 09 C:\wamp64\www\gem\application\libraries\Id.php 110
ERROR - 2018-09-29 22:00:29 --> Severity: Notice --> Undefined index: 09 C:\wamp64\www\gem\application\libraries\Id.php 110
ERROR - 2018-09-29 22:00:29 --> Severity: Notice --> Undefined index: - C:\wamp64\www\gem\application\libraries\Id.php 110
ERROR - 2018-09-29 22:00:29 --> Severity: Notice --> Undefined index: - C:\wamp64\www\gem\application\libraries\Id.php 110
ERROR - 2018-09-29 22:00:29 --> Severity: Notice --> Undefined index: - C:\wamp64\www\gem\application\libraries\Id.php 110
ERROR - 2018-09-29 22:00:46 --> Severity: Notice --> Undefined offset: 0 C:\wamp64\www\gem\application\libraries\Id.php 110
ERROR - 2018-09-29 22:00:46 --> Severity: Notice --> Undefined offset: 1 C:\wamp64\www\gem\application\libraries\Id.php 110
ERROR - 2018-09-29 22:00:46 --> Severity: Notice --> Undefined offset: 2 C:\wamp64\www\gem\application\libraries\Id.php 110
ERROR - 2018-09-29 22:00:46 --> Severity: Notice --> Array to string conversion C:\wamp64\www\gem\application\libraries\Id.php 112
ERROR - 2018-09-29 22:00:46 --> Severity: Notice --> Uninitialized string offset: 2 C:\wamp64\www\gem\application\libraries\Id.php 110
ERROR - 2018-09-29 22:00:46 --> Severity: Notice --> Uninitialized string offset: 1 C:\wamp64\www\gem\application\libraries\Id.php 110
ERROR - 2018-09-29 22:00:46 --> Severity: Notice --> Uninitialized string offset: 2 C:\wamp64\www\gem\application\libraries\Id.php 110
ERROR - 2018-09-29 22:01:34 --> Severity: Notice --> Undefined offset: 0 C:\wamp64\www\gem\application\libraries\Id.php 110
ERROR - 2018-09-29 22:01:34 --> Severity: Notice --> Array to string conversion C:\wamp64\www\gem\application\libraries\Id.php 112
ERROR - 2018-09-29 22:45:11 --> Severity: Notice --> Undefined offset: 0 C:\wamp64\www\gem\application\libraries\Id.php 110
ERROR - 2018-09-29 22:45:11 --> Severity: Notice --> Undefined offset: 1 C:\wamp64\www\gem\application\libraries\Id.php 110
ERROR - 2018-09-29 22:45:11 --> Severity: Notice --> Undefined offset: 2 C:\wamp64\www\gem\application\libraries\Id.php 110
ERROR - 2018-09-29 22:45:11 --> Severity: Notice --> Undefined offset: 0 C:\wamp64\www\gem\application\libraries\Id.php 110
ERROR - 2018-09-29 22:45:12 --> Severity: Notice --> Undefined offset: 1 C:\wamp64\www\gem\application\libraries\Id.php 110
ERROR - 2018-09-29 22:45:12 --> Severity: Notice --> Undefined offset: 2 C:\wamp64\www\gem\application\libraries\Id.php 110
ERROR - 2018-09-29 22:45:14 --> Severity: Notice --> Undefined offset: 0 C:\wamp64\www\gem\application\libraries\Id.php 110
ERROR - 2018-09-29 22:45:14 --> Severity: Notice --> Undefined offset: 1 C:\wamp64\www\gem\application\libraries\Id.php 110
ERROR - 2018-09-29 22:45:14 --> Severity: Notice --> Undefined offset: 2 C:\wamp64\www\gem\application\libraries\Id.php 110
ERROR - 2018-09-29 22:45:14 --> Severity: Notice --> Undefined offset: 0 C:\wamp64\www\gem\application\libraries\Id.php 110
ERROR - 2018-09-29 22:45:14 --> Severity: Notice --> Undefined offset: 1 C:\wamp64\www\gem\application\libraries\Id.php 110
ERROR - 2018-09-29 22:45:14 --> Severity: Notice --> Undefined offset: 2 C:\wamp64\www\gem\application\libraries\Id.php 110
ERROR - 2018-09-29 22:46:39 --> Severity: Notice --> Array to string conversion C:\wamp64\www\gem\application\libraries\Id.php 112
ERROR - 2018-09-29 22:47:12 --> Severity: Notice --> Array to string conversion C:\wamp64\www\gem\application\libraries\Id.php 112
ERROR - 2018-09-29 22:47:31 --> Severity: Warning --> Illegal string offset 'month' C:\wamp64\www\gem\application\libraries\Id.php 112
ERROR - 2018-09-29 22:47:31 --> Severity: Warning --> Illegal string offset 'month' C:\wamp64\www\gem\application\libraries\Id.php 112
ERROR - 2018-09-29 22:48:00 --> Severity: Warning --> Illegal string offset 'month' C:\wamp64\www\gem\application\libraries\Id.php 112
ERROR - 2018-09-29 22:48:00 --> Severity: Warning --> Illegal string offset 'month' C:\wamp64\www\gem\application\libraries\Id.php 112
ERROR - 2018-09-29 22:48:00 --> Severity: Warning --> Illegal string offset 'month' C:\wamp64\www\gem\application\libraries\Id.php 112
ERROR - 2018-09-29 22:48:17 --> Severity: Notice --> Undefined index: month C:\wamp64\www\gem\application\libraries\Id.php 112
ERROR - 2018-09-29 22:48:17 --> Severity: Notice --> Undefined index: month C:\wamp64\www\gem\application\libraries\Id.php 112
ERROR - 2018-09-29 22:48:17 --> Severity: Notice --> Undefined index: month C:\wamp64\www\gem\application\libraries\Id.php 112
ERROR - 2018-09-29 22:48:37 --> Severity: Warning --> Illegal offset type C:\wamp64\www\gem\application\libraries\Id.php 112
ERROR - 2018-09-29 22:48:37 --> Severity: Notice --> Undefined index: 09 C:\wamp64\www\gem\application\libraries\Id.php 112
ERROR - 2018-09-29 22:48:37 --> Severity: Notice --> Undefined index: - C:\wamp64\www\gem\application\libraries\Id.php 112
ERROR - 2018-09-29 22:49:17 --> Severity: Warning --> Illegal offset type C:\wamp64\www\gem\application\libraries\Id.php 112
ERROR - 2018-09-29 22:49:17 --> Severity: Notice --> Uninitialized string offset: 9 C:\wamp64\www\gem\application\libraries\Id.php 112
ERROR - 2018-09-29 22:49:17 --> Severity: Warning --> Illegal string offset '-' C:\wamp64\www\gem\application\libraries\Id.php 112
ERROR - 2018-09-29 22:49:26 --> Severity: Warning --> Illegal string offset 'month' C:\wamp64\www\gem\application\libraries\Id.php 112
ERROR - 2018-09-29 22:49:26 --> Severity: Warning --> Illegal string offset 'month' C:\wamp64\www\gem\application\libraries\Id.php 112
ERROR - 2018-09-29 22:51:13 --> Severity: Warning --> Illegal offset type in isset or empty C:\wamp64\www\gem\application\libraries\Id.php 112
ERROR - 2018-09-29 22:51:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\gem\application\libraries\Id.php 109
ERROR - 2018-09-29 22:51:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\gem\application\libraries\Id.php 109
ERROR - 2018-09-29 22:51:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\gem\application\libraries\Id.php 109
ERROR - 2018-09-29 22:51:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\gem\application\libraries\Id.php 109
ERROR - 2018-09-29 22:52:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\gem\application\libraries\Id.php 109
ERROR - 2018-09-29 22:52:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\gem\application\libraries\Id.php 109
ERROR - 2018-09-29 23:47:53 --> Severity: Notice --> Undefined variable: options C:\wamp64\www\gem\application\libraries\Id.php 94
ERROR - 2018-09-29 23:47:53 --> Severity: Notice --> Undefined property: Id::$_options C:\wamp64\www\gem\application\libraries\Id.php 65
ERROR - 2018-09-29 23:48:41 --> Severity: Notice --> Undefined property: Id::$_options C:\wamp64\www\gem\application\libraries\Id.php 65
