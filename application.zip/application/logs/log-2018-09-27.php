<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-09-27 00:05:01 --> 404 Page Not Found: Assets/admin
ERROR - 2018-09-27 00:05:04 --> 404 Page Not Found: Assets/admin
ERROR - 2018-09-27 00:05:04 --> 404 Page Not Found: Assets/admin
ERROR - 2018-09-27 00:21:24 --> 404 Page Not Found: Assets/admin
ERROR - 2018-09-27 05:14:55 --> 404 Page Not Found: Assets/admin
ERROR - 2018-09-27 05:14:55 --> 404 Page Not Found: Assets/admin
ERROR - 2018-09-27 05:14:59 --> 404 Page Not Found: Assets/admin
ERROR - 2018-09-27 05:23:21 --> Severity: Parsing Error --> syntax error, unexpected ':' C:\wamp64\www\gem\application\controllers\admin\Report.php 159
ERROR - 2018-09-27 05:32:13 --> 404 Page Not Found: Assets/admin
ERROR - 2018-09-27 05:32:13 --> 404 Page Not Found: Assets/admin
ERROR - 2018-09-27 05:33:42 --> 404 Page Not Found: Assets/admin
ERROR - 2018-09-27 05:33:43 --> 404 Page Not Found: Assets/admin
ERROR - 2018-09-27 17:20:54 --> 404 Page Not Found: Assets/admin
ERROR - 2018-09-27 17:20:56 --> 404 Page Not Found: Assets/admin
ERROR - 2018-09-27 17:21:09 --> Severity: Parsing Error --> syntax error, unexpected '(', expecting ',' or ';' C:\wamp64\www\gem\application\controllers\admin\Report.php 31
ERROR - 2018-09-27 17:22:56 --> Severity: Parsing Error --> syntax error, unexpected '(', expecting ',' or ';' C:\wamp64\www\gem\application\controllers\admin\Report.php 31
ERROR - 2018-09-27 17:23:13 --> Severity: Parsing Error --> syntax error, unexpected '(', expecting ',' or ';' C:\wamp64\www\gem\application\controllers\admin\Report.php 31
ERROR - 2018-09-27 17:23:52 --> Severity: Parsing Error --> syntax error, unexpected '(', expecting ',' or ';' C:\wamp64\www\gem\application\controllers\admin\Report.php 31
ERROR - 2018-09-27 17:36:14 --> Severity: Parsing Error --> syntax error, unexpected '(', expecting ',' or ';' C:\wamp64\www\gem\application\controllers\admin\Report.php 31
