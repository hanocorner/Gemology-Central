<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-09-30 00:05:08 --> Severity: Warning --> Missing argument 1 for Id::set_lastid(), called in C:\wamp64\www\gem\application\controllers\admin\Report.php on line 499 and defined C:\wamp64\www\gem\application\libraries\Id.php 82
ERROR - 2018-09-30 02:53:02 --> 404 Page Not Found: Assets/admin
ERROR - 2018-09-30 03:10:16 --> Severity: Notice --> Undefined variable: _customer C:\wamp64\www\gem\application\views\admin\lab\report\add_report.php 34
ERROR - 2018-09-30 03:10:16 --> Severity: Notice --> Undefined variable: cid C:\wamp64\www\gem\application\views\admin\lab\report\add_report.php 35
ERROR - 2018-09-30 03:12:16 --> 404 Page Not Found: Assets/admin
ERROR - 2018-09-30 03:12:17 --> 404 Page Not Found: Assets/admin
ERROR - 2018-09-30 03:12:20 --> 404 Page Not Found: admin/Report/index
ERROR - 2018-09-30 03:12:25 --> Severity: Notice --> Undefined variable: data C:\wamp64\www\gem\application\controllers\admin\Report.php 51
ERROR - 2018-09-30 03:12:25 --> Severity: Notice --> Undefined variable: _customer C:\wamp64\www\gem\application\views\admin\lab\report\add_report.php 34
ERROR - 2018-09-30 03:12:25 --> Severity: Notice --> Undefined variable: cid C:\wamp64\www\gem\application\views\admin\lab\report\add_report.php 35
ERROR - 2018-09-30 03:13:33 --> Severity: Notice --> Undefined variable: _customer C:\wamp64\www\gem\application\views\admin\lab\report\add_report.php 34
ERROR - 2018-09-30 03:13:33 --> Severity: Notice --> Undefined variable: cid C:\wamp64\www\gem\application\views\admin\lab\report\add_report.php 35
ERROR - 2018-09-30 03:14:54 --> Severity: Notice --> Undefined variable: data C:\wamp64\www\gem\application\views\admin\lab\report\add_report.php 34
ERROR - 2018-09-30 03:14:54 --> Severity: Notice --> Undefined variable: cid C:\wamp64\www\gem\application\views\admin\lab\report\add_report.php 35
ERROR - 2018-09-30 03:16:36 --> Severity: Notice --> Array to string conversion C:\wamp64\www\gem\application\views\admin\lab\report\add_report.php 34
ERROR - 2018-09-30 03:16:36 --> Severity: Notice --> Undefined variable: cid C:\wamp64\www\gem\application\views\admin\lab\report\add_report.php 35
ERROR - 2018-09-30 03:16:52 --> Severity: Notice --> Undefined index: name C:\wamp64\www\gem\application\controllers\admin\Report.php 60
ERROR - 2018-09-30 03:16:52 --> Severity: Notice --> Undefined index: csid C:\wamp64\www\gem\application\controllers\admin\Report.php 61
ERROR - 2018-09-30 03:16:52 --> Severity: Notice --> Array to string conversion C:\wamp64\www\gem\application\views\admin\lab\report\add_report.php 34
ERROR - 2018-09-30 03:16:52 --> Severity: Notice --> Undefined variable: cid C:\wamp64\www\gem\application\views\admin\lab\report\add_report.php 35
ERROR - 2018-09-30 03:21:49 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\gem\application\controllers\admin\Report.php 39
ERROR - 2018-09-30 03:21:49 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\controllers\admin\Report.php 39
ERROR - 2018-09-30 03:21:49 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\gem\application\controllers\admin\Report.php 39
ERROR - 2018-09-30 03:21:49 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\controllers\admin\Report.php 39
ERROR - 2018-09-30 03:21:49 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\gem\application\controllers\admin\Report.php 40
ERROR - 2018-09-30 03:21:49 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\controllers\admin\Report.php 40
ERROR - 2018-09-30 07:14:54 --> 404 Page Not Found: Assets/admin
ERROR - 2018-09-30 07:14:54 --> 404 Page Not Found: Assets/admin
ERROR - 2018-09-30 07:15:01 --> 404 Page Not Found: Assets/admin
ERROR - 2018-09-30 07:15:16 --> 404 Page Not Found: admin/Report/index
ERROR - 2018-09-30 07:16:06 --> 404 Page Not Found: Assets/admin
ERROR - 2018-09-30 07:16:37 --> 404 Page Not Found: Assets/admin
ERROR - 2018-09-30 07:16:37 --> 404 Page Not Found: Assets/admin
ERROR - 2018-09-30 07:38:57 --> Could not find the language line "form_validation_alpha_dash_space"
ERROR - 2018-09-30 07:38:57 --> Could not find the language line "form_validation_alpha_dash_space"
ERROR - 2018-09-30 07:38:57 --> Could not find the language line "form_validation_alpha_dash_space"
ERROR - 2018-09-30 07:43:48 --> Could not find the language line "form_validation_alpha_dash_space"
ERROR - 2018-09-30 07:43:48 --> Could not find the language line "form_validation_alpha_dash_space"
ERROR - 2018-09-30 07:43:48 --> Could not find the language line "form_validation_alpha_dash_space"
ERROR - 2018-09-30 07:45:30 --> Severity: Notice --> Undefined property: Report::$_date C:\wamp64\www\gem\application\controllers\admin\Report.php 136
ERROR - 2018-09-30 07:45:31 --> Severity: Notice --> Undefined property: Report::$_rep_type C:\wamp64\www\gem\application\controllers\admin\Report.php 137
ERROR - 2018-09-30 07:45:31 --> Query error: Column 'rep_date' cannot be null - Invalid query: INSERT INTO `tbl_lab_report` (`rep_customerID`, `rep_date`, `rep_type`, `rep_object`, `rep_identification`, `rep_weight`, `rep_gemID`, `rep_cut`, `rep_gemWidth`, `rep_gemHeight`, `rep_gemLength`, `rep_color`, `rep_shape`, `rep_comment`) VALUES ('GCLC-1002', NULL, NULL, 'fuse', 'text', '4.90', '1', '', '', '', '', 'Red', 'Oval', 'treated')
ERROR - 2018-09-30 07:46:38 --> Severity: Notice --> Undefined property: Report::$_date C:\wamp64\www\gem\application\controllers\admin\Report.php 136
ERROR - 2018-09-30 07:46:38 --> Severity: Notice --> Undefined property: Report::$_rep_type C:\wamp64\www\gem\application\controllers\admin\Report.php 137
ERROR - 2018-09-30 07:46:38 --> Query error: Column 'rep_type' cannot be null - Invalid query: INSERT INTO `tbl_lab_report` (`rep_customerID`, `rep_date`, `rep_type`, `rep_object`, `rep_identification`, `rep_weight`, `rep_gemID`, `rep_cut`, `rep_gemWidth`, `rep_gemHeight`, `rep_gemLength`, `rep_color`, `rep_shape`, `rep_comment`) VALUES ('GCLC-1002', '', NULL, 'fuse', 'syga', '7.6', '2', '', '', '', '', '', '', 'treat')
ERROR - 2018-09-30 07:48:40 --> Severity: Notice --> Undefined property: Report::$_date C:\wamp64\www\gem\application\controllers\admin\Report.php 136
ERROR - 2018-09-30 07:48:40 --> Severity: Warning --> pathinfo() expects parameter 1 to be string, array given C:\wamp64\www\gem\application\controllers\admin\Report.php 220
ERROR - 2018-09-30 07:48:41 --> Severity: Error --> Call to undefined method Report::set_message() C:\wamp64\www\gem\application\controllers\admin\Report.php 108
ERROR - 2018-09-30 07:52:47 --> Severity: Notice --> Undefined property: Report::$_date C:\wamp64\www\gem\application\controllers\admin\Report.php 136
ERROR - 2018-09-30 08:18:20 --> Query error: Unknown column 'memoid' in 'field list' - Invalid query: SELECT `memoid`
FROM `tbl_gem_verbal`
ORDER BY `verbid` DESC
 LIMIT 1
ERROR - 2018-09-30 08:18:49 --> Query error: Unknown column 'memoid' in 'field list' - Invalid query: SELECT `memoid`
FROM `tbl_gem_verbal`
ORDER BY `verbid` DESC
 LIMIT 1
ERROR - 2018-09-30 08:19:00 --> Query error: Unknown column 'memoid' in 'field list' - Invalid query: SELECT `memoid`
FROM `tbl_gem_verbal`
ORDER BY `verbid` DESC
 LIMIT 1
ERROR - 2018-09-30 08:19:03 --> Query error: Unknown column 'memoid' in 'field list' - Invalid query: SELECT `memoid`
FROM `tbl_gem_verbal`
ORDER BY `verbid` DESC
 LIMIT 1
ERROR - 2018-09-30 08:32:11 --> Severity: Notice --> Array to string conversion C:\wamp64\www\gem\application\controllers\admin\Report.php 105
ERROR - 2018-09-30 08:41:48 --> Severity: Error --> Call to undefined method Report_model::insert_image() C:\wamp64\www\gem\application\controllers\admin\Report.php 218
ERROR - 2018-09-30 08:45:57 --> Query error: Unknown column 'reportid' in 'field list' - Invalid query: INSERT INTO `tbl_gem_image` (`reportid`, `img_gemstone`, `img_qrcode`, `img_date`) VALUES (66, '', 'GCLV-100001.png', '2018-09-30')
ERROR - 2018-09-30 09:17:22 --> Severity: Error --> Call to undefined method Report::qr_generator() C:\wamp64\www\gem\application\controllers\admin\Report.php 253
ERROR - 2018-09-30 10:14:11 --> Severity: Parsing Error --> syntax error, unexpected '=>' (T_DOUBLE_ARROW) C:\wamp64\www\gem\application\controllers\admin\Report.php 308
ERROR - 2018-09-30 11:37:19 --> 404 Page Not Found: admin/Report/index
ERROR - 2018-09-30 13:35:21 --> 404 Page Not Found: Assets/admin
ERROR - 2018-09-30 13:35:22 --> 404 Page Not Found: Assets/admin
ERROR - 2018-09-30 13:35:37 --> 404 Page Not Found: admin/Report/index
ERROR - 2018-09-30 13:57:34 --> 404 Page Not Found: Assets/admin
ERROR - 2018-09-30 13:57:34 --> 404 Page Not Found: Assets/admin
ERROR - 2018-09-30 13:57:50 --> 404 Page Not Found: Assets/admin
ERROR - 2018-09-30 13:57:51 --> 404 Page Not Found: Assets/admin
ERROR - 2018-09-30 13:58:40 --> 404 Page Not Found: Assets/admin
ERROR - 2018-09-30 13:58:41 --> 404 Page Not Found: Assets/admin
ERROR - 2018-09-30 13:58:43 --> 404 Page Not Found: Assets/admin
ERROR - 2018-09-30 13:58:44 --> 404 Page Not Found: Assets/admin
ERROR - 2018-09-30 13:59:45 --> 404 Page Not Found: Assets/admin
ERROR - 2018-09-30 13:59:45 --> 404 Page Not Found: Assets/admin
ERROR - 2018-09-30 14:00:13 --> 404 Page Not Found: Assets/admin
ERROR - 2018-09-30 14:00:13 --> 404 Page Not Found: Assets/admin
ERROR - 2018-09-30 14:15:01 --> 404 Page Not Found: Assets/admin
ERROR - 2018-09-30 14:15:02 --> 404 Page Not Found: Assets/admin
ERROR - 2018-09-30 14:15:57 --> 404 Page Not Found: Assets/admin
ERROR - 2018-09-30 14:15:57 --> 404 Page Not Found: Assets/admin
ERROR - 2018-09-30 14:16:50 --> 404 Page Not Found: Assets/admin
ERROR - 2018-09-30 14:16:58 --> 404 Page Not Found: Assets/admin
ERROR - 2018-09-30 14:16:59 --> 404 Page Not Found: Assets/admin
ERROR - 2018-09-30 14:17:24 --> 404 Page Not Found: Assets/admin
ERROR - 2018-09-30 14:18:31 --> 404 Page Not Found: admin/Report/GCLV_100010.png
ERROR - 2018-09-30 14:23:49 --> 404 Page Not Found: admin/Report/document3.zip
ERROR - 2018-09-30 14:43:27 --> 404 Page Not Found: Assets/admin
ERROR - 2018-09-30 14:43:27 --> 404 Page Not Found: Assets/admin
ERROR - 2018-09-30 14:49:57 --> 404 Page Not Found: admin/Report/index
ERROR - 2018-09-30 14:51:55 --> 404 Page Not Found: Assets/admin
ERROR - 2018-09-30 14:51:55 --> 404 Page Not Found: Assets/admin
ERROR - 2018-09-30 14:54:31 --> 404 Page Not Found: Assets/admin
ERROR - 2018-09-30 14:54:31 --> 404 Page Not Found: Assets/admin
ERROR - 2018-09-30 14:55:47 --> 404 Page Not Found: Assets/admin
ERROR - 2018-09-30 14:55:48 --> 404 Page Not Found: Assets/admin
ERROR - 2018-09-30 14:56:28 --> 404 Page Not Found: admin/Report/edit
ERROR - 2018-09-30 15:02:48 --> 404 Page Not Found: Assets/admin
ERROR - 2018-09-30 15:02:48 --> 404 Page Not Found: Assets/admin
ERROR - 2018-09-30 15:09:50 --> 404 Page Not Found: Assets/admin
ERROR - 2018-09-30 15:09:50 --> 404 Page Not Found: Assets/admin
ERROR - 2018-09-30 15:13:59 --> 404 Page Not Found: Assets/admin
ERROR - 2018-09-30 15:13:59 --> 404 Page Not Found: Assets/admin
ERROR - 2018-09-30 15:14:34 --> 404 Page Not Found: Assets/admin
ERROR - 2018-09-30 15:14:34 --> 404 Page Not Found: Assets/admin
ERROR - 2018-09-30 15:15:49 --> 404 Page Not Found: Assets/admin
ERROR - 2018-09-30 15:15:49 --> 404 Page Not Found: Assets/admin
ERROR - 2018-09-30 15:17:22 --> 404 Page Not Found: Assets/admin
ERROR - 2018-09-30 15:17:22 --> 404 Page Not Found: Assets/admin
ERROR - 2018-09-30 15:19:36 --> Severity: Parsing Error --> syntax error, unexpected ':' C:\wamp64\www\gem\application\views\admin\lab\report\download.php 17
ERROR - 2018-09-30 15:23:42 --> 404 Page Not Found: Assets/admin
ERROR - 2018-09-30 15:23:42 --> 404 Page Not Found: Assets/admin
ERROR - 2018-09-30 15:25:20 --> 404 Page Not Found: Assets/admin
ERROR - 2018-09-30 15:25:21 --> 404 Page Not Found: Assets/admin
ERROR - 2018-09-30 15:26:36 --> 404 Page Not Found: Assets/admin
ERROR - 2018-09-30 15:26:36 --> 404 Page Not Found: Assets/admin
ERROR - 2018-09-30 15:26:53 --> 404 Page Not Found: Assets/admin
ERROR - 2018-09-30 15:26:53 --> 404 Page Not Found: Assets/admin
ERROR - 2018-09-30 15:28:21 --> 404 Page Not Found: Assets/admin
ERROR - 2018-09-30 15:28:47 --> 404 Page Not Found: Report_verification/index
ERROR - 2018-09-30 15:32:07 --> 404 Page Not Found: Assets/admin
ERROR - 2018-09-30 16:04:21 --> 404 Page Not Found: Repor/FGCL_100002
ERROR - 2018-09-30 16:04:28 --> 404 Page Not Found: Repor/GCL_100002
ERROR - 2018-09-30 16:04:42 --> 404 Page Not Found: Repor/GCL_100002
ERROR - 2018-09-30 16:04:50 --> 404 Page Not Found: Assets/admin
ERROR - 2018-09-30 16:05:41 --> 404 Page Not Found: Assets/admin
