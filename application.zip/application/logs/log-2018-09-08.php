<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-09-08 08:14:25 --> 404 Page Not Found: Assets/css
ERROR - 2018-09-08 08:14:30 --> Severity: Notice --> Undefined variable: noOfComments C:\wamp64\www\gem\application\views\admin\profile.php 45
ERROR - 2018-09-08 08:14:30 --> Severity: Notice --> Undefined variable: total_unpaid_certificates C:\wamp64\www\gem\application\views\admin\profile.php 56
ERROR - 2018-09-08 08:14:39 --> Severity: Notice --> Undefined variable: id C:\wamp64\www\gem\application\models\Report_model.php 54
ERROR - 2018-09-08 08:14:48 --> Severity: Notice --> Undefined variable: id C:\wamp64\www\gem\application\models\Report_model.php 54
ERROR - 2018-09-08 09:58:17 --> Severity: Notice --> Undefined variable: data C:\wamp64\www\gem\application\views\admin\report\index.php 58
ERROR - 2018-09-08 09:59:02 --> Severity: Warning --> strpos() expects parameter 1 to be string, array given C:\wamp64\www\gem\system\helpers\form_helper.php 74
ERROR - 2018-09-08 09:59:02 --> Severity: Notice --> Array to string conversion C:\wamp64\www\gem\system\helpers\form_helper.php 91
ERROR - 2018-09-08 09:59:02 --> Severity: Warning --> strpos() expects parameter 1 to be string, array given C:\wamp64\www\gem\system\helpers\form_helper.php 102
ERROR - 2018-09-08 10:47:11 --> Severity: Notice --> Undefined variable: noOfComments C:\wamp64\www\gem\application\views\admin\profile.php 45
ERROR - 2018-09-08 10:47:11 --> Severity: Notice --> Undefined variable: total_unpaid_certificates C:\wamp64\www\gem\application\views\admin\profile.php 56
ERROR - 2018-09-08 13:24:32 --> Severity: Notice --> Array to string conversion C:\wamp64\www\gem\application\controllers\admin\Report.php 101
ERROR - 2018-09-08 13:27:19 --> Severity: Notice --> Undefined property: stdClass::$cer_color C:\wamp64\www\gem\application\views\admin\report\specific_data.php 42
ERROR - 2018-09-08 15:02:39 --> 404 Page Not Found: admin/Undefinedadmin/report
ERROR - 2018-09-08 15:22:07 --> 404 Page Not Found: admin/Undefinedadmin/report
ERROR - 2018-09-08 18:26:01 --> 404 Page Not Found: admin/Undefinedadmin/report
ERROR - 2018-09-08 18:26:02 --> 404 Page Not Found: admin/Undefinedadmin/report
ERROR - 2018-09-08 18:26:32 --> 404 Page Not Found: admin/Undefinedadmin/report
ERROR - 2018-09-08 18:33:36 --> 404 Page Not Found: admin/Undefinedadmin/report
ERROR - 2018-09-08 18:39:16 --> 404 Page Not Found: admin/Undefinedadmin/report
ERROR - 2018-09-08 19:22:06 --> 404 Page Not Found: admin/Undefinedadmin/report
ERROR - 2018-09-08 19:35:16 --> 404 Page Not Found: admin/Undefinedadmin/report
ERROR - 2018-09-08 19:47:30 --> 404 Page Not Found: admin/Undefinedadmin/report
ERROR - 2018-09-08 19:48:05 --> 404 Page Not Found: admin/Undefinedadmin/report
ERROR - 2018-09-08 19:48:56 --> 404 Page Not Found: admin/Undefinedadmin/report
ERROR - 2018-09-08 19:49:19 --> 404 Page Not Found: admin/Undefinedadmin/report
ERROR - 2018-09-08 19:50:25 --> 404 Page Not Found: admin/Undefinedadmin/report
ERROR - 2018-09-08 19:51:37 --> 404 Page Not Found: admin/Undefinedadmin/report
ERROR - 2018-09-08 19:53:41 --> 404 Page Not Found: admin/Undefinedadmin/report
ERROR - 2018-09-08 19:55:24 --> 404 Page Not Found: admin/Undefinedadmin/report
ERROR - 2018-09-08 19:56:01 --> 404 Page Not Found: admin/Undefinedadmin/report
ERROR - 2018-09-08 19:57:02 --> 404 Page Not Found: admin/Undefinedadmin/report
ERROR - 2018-09-08 19:57:56 --> 404 Page Not Found: admin/Undefinedadmin/report
ERROR - 2018-09-08 19:58:36 --> 404 Page Not Found: admin/Undefinedadmin/report
ERROR - 2018-09-08 20:58:41 --> 404 Page Not Found: admin/Undefinedadmin/report
ERROR - 2018-09-08 21:01:58 --> 404 Page Not Found: admin/Undefinedadmin/report
ERROR - 2018-09-08 21:02:53 --> 404 Page Not Found: admin/Undefinedadmin/report
ERROR - 2018-09-08 21:05:13 --> 404 Page Not Found: admin/Undefinedadmin/report
ERROR - 2018-09-08 21:07:19 --> 404 Page Not Found: admin/Undefinedadmin/report
ERROR - 2018-09-08 21:21:49 --> 404 Page Not Found: admin/Undefinedadmin/report
ERROR - 2018-09-08 21:25:01 --> 404 Page Not Found: admin/Undefinedadmin/report
