<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-09-04 06:22:02 --> 404 Page Not Found: admin/Report/add_new_report
ERROR - 2018-09-04 06:22:17 --> 404 Page Not Found: Assets/css
ERROR - 2018-09-04 06:22:21 --> 404 Page Not Found: Assets/css
ERROR - 2018-09-04 06:22:26 --> Severity: Notice --> Undefined variable: noOfComments C:\wamp64\www\gem\application\views\admin\profile.php 45
ERROR - 2018-09-04 06:22:26 --> Severity: Notice --> Undefined variable: total_unpaid_certificates C:\wamp64\www\gem\application\views\admin\profile.php 56
ERROR - 2018-09-04 06:22:32 --> 404 Page Not Found: admin/Report/add_new_report
ERROR - 2018-09-04 18:45:55 --> 404 Page Not Found: Assets/css
ERROR - 2018-09-04 18:45:59 --> Severity: Notice --> Undefined variable: noOfComments C:\wamp64\www\gem\application\views\admin\profile.php 45
ERROR - 2018-09-04 18:45:59 --> Severity: Notice --> Undefined variable: total_unpaid_certificates C:\wamp64\www\gem\application\views\admin\profile.php 56
ERROR - 2018-09-04 18:46:02 --> 404 Page Not Found: admin/Report/add_new_report
ERROR - 2018-09-04 21:30:28 --> 404 Page Not Found: admin/Report/add_new_report
ERROR - 2018-09-04 21:31:24 --> Query error: Unknown column 'fname' in 'field list' - Invalid query: INSERT INTO `tbl_customer` (`fname`, `lname`, `number`, `email`) VALUES ('Harry', 'Jayawardana', '0771234567', 'jack@gmail.com')
