<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-09-07 00:24:30 --> 404 Page Not Found: Assets/css
ERROR - 2018-09-07 00:24:35 --> Severity: Notice --> Undefined variable: noOfComments C:\wamp64\www\gem\application\views\admin\profile.php 45
ERROR - 2018-09-07 00:24:35 --> Severity: Notice --> Undefined variable: total_unpaid_certificates C:\wamp64\www\gem\application\views\admin\profile.php 56
ERROR - 2018-09-07 07:14:28 --> 404 Page Not Found: Assets/css
ERROR - 2018-09-07 07:14:33 --> Severity: Notice --> Undefined variable: noOfComments C:\wamp64\www\gem\application\views\admin\profile.php 45
ERROR - 2018-09-07 07:14:33 --> Severity: Notice --> Undefined variable: total_unpaid_certificates C:\wamp64\www\gem\application\views\admin\profile.php 56
ERROR - 2018-09-07 07:14:38 --> Severity: Notice --> Undefined variable: id C:\wamp64\www\gem\application\controllers\admin\Report.php 80
ERROR - 2018-09-07 07:14:38 --> Severity: Notice --> Undefined variable: id C:\wamp64\www\gem\application\controllers\admin\Report.php 81
ERROR - 2018-09-07 07:14:38 --> Severity: Notice --> Undefined offset: 0 C:\wamp64\www\gem\application\models\Report_model.php 104
ERROR - 2018-09-07 07:14:38 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\models\Report_model.php 104
ERROR - 2018-09-07 07:14:38 --> Severity: Notice --> Undefined offset: 0 C:\wamp64\www\gem\application\models\Report_model.php 104
ERROR - 2018-09-07 07:14:38 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\models\Report_model.php 104
ERROR - 2018-09-07 07:14:38 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'ORDER BY cerno DESC LIMIT 0, 10' at line 1 - Invalid query: SELECT cerno, cer_type, cer_object, cer_identification, cer_paymentStatus, cer_weight, customerID FROM tbl_certificate  WHERE customerID =  ORDER BY cerno DESC LIMIT 0, 10
ERROR - 2018-09-07 07:14:41 --> Severity: Notice --> Undefined variable: id C:\wamp64\www\gem\application\controllers\admin\Report.php 80
ERROR - 2018-09-07 07:14:41 --> Severity: Notice --> Undefined variable: id C:\wamp64\www\gem\application\controllers\admin\Report.php 81
ERROR - 2018-09-07 07:14:41 --> Severity: Notice --> Undefined offset: 0 C:\wamp64\www\gem\application\models\Report_model.php 104
ERROR - 2018-09-07 07:14:41 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\models\Report_model.php 104
ERROR - 2018-09-07 07:14:41 --> Severity: Notice --> Undefined offset: 0 C:\wamp64\www\gem\application\models\Report_model.php 104
ERROR - 2018-09-07 07:14:41 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\models\Report_model.php 104
ERROR - 2018-09-07 07:14:42 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'ORDER BY cerno DESC LIMIT 0, 10' at line 1 - Invalid query: SELECT cerno, cer_type, cer_object, cer_identification, cer_paymentStatus, cer_weight, customerID FROM tbl_certificate  WHERE customerID =  ORDER BY cerno DESC LIMIT 0, 10
