<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-09-23 11:12:40 --> Severity: Error --> Call to undefined function id() C:\wamp64\www\gem\application\controllers\admin\Customer.php 39
ERROR - 2018-09-23 11:13:08 --> Severity: Compile Error --> Cannot redeclare id() (previously declared in C:\wamp64\www\gem\application\helpers\myid_helper.php:4) C:\wamp64\www\gem\system\helpers\myid_helper.php 7
ERROR - 2018-09-23 12:28:03 --> Severity: Notice --> Undefined variable: data C:\wamp64\www\gem\application\controllers\admin\Gemstone.php 40
ERROR - 2018-09-23 13:50:41 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\controllers\admin\Gemstone.php 93
ERROR - 2018-09-23 13:50:41 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\controllers\admin\Gemstone.php 95
ERROR - 2018-09-23 13:50:41 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\controllers\admin\Gemstone.php 96
ERROR - 2018-09-23 13:50:41 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\controllers\admin\Gemstone.php 97
ERROR - 2018-09-23 13:50:43 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\controllers\admin\Gemstone.php 93
ERROR - 2018-09-23 13:50:43 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\controllers\admin\Gemstone.php 95
ERROR - 2018-09-23 13:50:43 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\controllers\admin\Gemstone.php 96
ERROR - 2018-09-23 13:50:43 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\controllers\admin\Gemstone.php 97
ERROR - 2018-09-23 13:50:44 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\controllers\admin\Gemstone.php 93
ERROR - 2018-09-23 13:50:44 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\controllers\admin\Gemstone.php 95
ERROR - 2018-09-23 13:50:44 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\controllers\admin\Gemstone.php 96
ERROR - 2018-09-23 13:50:44 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\controllers\admin\Gemstone.php 97
ERROR - 2018-09-23 13:50:44 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\controllers\admin\Gemstone.php 93
ERROR - 2018-09-23 13:50:44 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\controllers\admin\Gemstone.php 95
ERROR - 2018-09-23 13:50:44 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\controllers\admin\Gemstone.php 96
ERROR - 2018-09-23 13:50:44 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\controllers\admin\Gemstone.php 97
ERROR - 2018-09-23 13:50:45 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\controllers\admin\Gemstone.php 93
ERROR - 2018-09-23 13:50:45 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\controllers\admin\Gemstone.php 95
ERROR - 2018-09-23 13:50:45 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\controllers\admin\Gemstone.php 96
ERROR - 2018-09-23 13:50:45 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\controllers\admin\Gemstone.php 97
ERROR - 2018-09-23 13:52:00 --> Severity: Notice --> Undefined offset: 0 C:\wamp64\www\gem\application\controllers\admin\Gemstone.php 93
ERROR - 2018-09-23 13:52:00 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\controllers\admin\Gemstone.php 93
ERROR - 2018-09-23 13:52:00 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\controllers\admin\Gemstone.php 95
ERROR - 2018-09-23 13:52:01 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\controllers\admin\Gemstone.php 96
ERROR - 2018-09-23 13:52:01 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\controllers\admin\Gemstone.php 97
ERROR - 2018-09-23 13:53:02 --> Severity: Error --> Cannot use object of type stdClass as array C:\wamp64\www\gem\application\controllers\admin\Gemstone.php 93
ERROR - 2018-09-23 13:57:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\gem\application\controllers\admin\Gemstone.php 89
ERROR - 2018-09-23 14:02:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\gem\application\controllers\admin\Gemstone.php 89
ERROR - 2018-09-23 16:26:31 --> Severity: Parsing Error --> syntax error, unexpected '{' C:\wamp64\www\gem\application\controllers\admin\Gemstone.php 75
ERROR - 2018-09-23 16:26:53 --> Severity: Notice --> Undefined variable: repid C:\wamp64\www\gem\application\controllers\admin\Gemstone.php 79
ERROR - 2018-09-23 16:31:03 --> Severity: Notice --> Undefined property: stdClass::$gsrid C:\wamp64\www\gem\application\controllers\admin\Gemstone.php 72
ERROR - 2018-09-23 16:31:13 --> Severity: Notice --> Undefined property: stdClass::$gsrid C:\wamp64\www\gem\application\controllers\admin\Gemstone.php 72
ERROR - 2018-09-23 16:50:40 --> Severity: Notice --> Undefined property: stdClass::$gsrid C:\wamp64\www\gem\application\controllers\admin\Gemstone.php 70
ERROR - 2018-09-23 16:52:36 --> Severity: Notice --> Undefined property: stdClass::$gsrid C:\wamp64\www\gem\application\controllers\admin\Gemstone.php 80
ERROR - 2018-09-23 16:52:36 --> Severity: Notice --> Undefined property: stdClass::$gsrid C:\wamp64\www\gem\application\controllers\admin\Gemstone.php 80
ERROR - 2018-09-23 16:52:36 --> Severity: Notice --> Undefined property: stdClass::$gsrid C:\wamp64\www\gem\application\controllers\admin\Gemstone.php 80
ERROR - 2018-09-23 16:52:36 --> Severity: Notice --> Undefined property: stdClass::$gsrid C:\wamp64\www\gem\application\controllers\admin\Gemstone.php 80
ERROR - 2018-09-23 16:52:36 --> Severity: Notice --> Undefined property: stdClass::$gsrid C:\wamp64\www\gem\application\controllers\admin\Gemstone.php 80
ERROR - 2018-09-23 16:52:36 --> Severity: Notice --> Undefined property: stdClass::$gsrid C:\wamp64\www\gem\application\controllers\admin\Gemstone.php 80
ERROR - 2018-09-23 16:52:36 --> Severity: Notice --> Undefined property: stdClass::$gsrid C:\wamp64\www\gem\application\controllers\admin\Gemstone.php 80
ERROR - 2018-09-23 16:52:36 --> Severity: Notice --> Undefined property: stdClass::$gsrid C:\wamp64\www\gem\application\controllers\admin\Gemstone.php 80
ERROR - 2018-09-23 16:52:36 --> Severity: Notice --> Undefined property: stdClass::$gsrid C:\wamp64\www\gem\application\controllers\admin\Gemstone.php 80
ERROR - 2018-09-23 16:52:36 --> Severity: Notice --> Undefined property: stdClass::$gsrid C:\wamp64\www\gem\application\controllers\admin\Gemstone.php 80
ERROR - 2018-09-23 16:52:36 --> Severity: Notice --> Undefined property: stdClass::$gsrid C:\wamp64\www\gem\application\controllers\admin\Gemstone.php 80
ERROR - 2018-09-23 16:56:42 --> Severity: Notice --> Undefined property: stdClass::$gsrid C:\wamp64\www\gem\application\controllers\admin\Gemstone.php 80
ERROR - 2018-09-23 17:11:32 --> Severity: Notice --> Undefined variable: repid C:\wamp64\www\gem\application\controllers\admin\Gemstone.php 80
ERROR - 2018-09-23 17:11:32 --> Severity: Notice --> Undefined variable: repid C:\wamp64\www\gem\application\controllers\admin\Gemstone.php 80
ERROR - 2018-09-23 17:13:31 --> Severity: Notice --> Undefined variable: repid C:\wamp64\www\gem\application\controllers\admin\Gemstone.php 80
ERROR - 2018-09-23 17:13:31 --> Severity: Notice --> Undefined variable: repid C:\wamp64\www\gem\application\controllers\admin\Gemstone.php 80
ERROR - 2018-09-23 17:17:06 --> Severity: Notice --> Undefined variable: repid C:\wamp64\www\gem\application\controllers\admin\Gemstone.php 80
ERROR - 2018-09-23 17:17:08 --> Severity: Notice --> Undefined variable: repid C:\wamp64\www\gem\application\controllers\admin\Gemstone.php 80
ERROR - 2018-09-23 17:21:25 --> Severity: Notice --> Undefined variable: repid C:\wamp64\www\gem\application\controllers\admin\Gemstone.php 80
ERROR - 2018-09-23 17:22:25 --> Severity: Notice --> Undefined variable: repid C:\wamp64\www\gem\application\controllers\admin\Gemstone.php 80
ERROR - 2018-09-23 17:22:27 --> Severity: Notice --> Undefined variable: repid C:\wamp64\www\gem\application\controllers\admin\Gemstone.php 80
ERROR - 2018-09-23 17:22:49 --> Severity: Notice --> Undefined variable: repid C:\wamp64\www\gem\application\controllers\admin\Gemstone.php 80
