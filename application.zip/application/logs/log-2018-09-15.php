<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-09-15 11:45:59 --> 404 Page Not Found: admin/Report/data
ERROR - 2018-09-15 12:00:13 --> Query error: Duplicate entry 'GCL2018-091' for key 'PRIMARY' - Invalid query: INSERT INTO `tbl_gemstone_report` (`gsrid`, `reportid`, `gsr_date`, `gsr_paymentStatus`, `gsr_amount`) VALUES ('GCL2018-091001', 7, '2018-09-15', '0', '65.00')
ERROR - 2018-09-15 12:21:52 --> 404 Page Not Found: admin/Report/index
ERROR - 2018-09-15 13:48:11 --> Severity: Notice --> Undefined property: stdClass::$rep_identification C:\wamp64\www\gem\application\views\admin\lab\customer\specific_data.php 111
ERROR - 2018-09-15 14:29:49 --> 404 Page Not Found: admin/Add/index
ERROR - 2018-09-15 17:08:31 --> Severity: Notice --> Undefined offset: 0 C:\wamp64\www\gem\application\controllers\admin\Report.php 192
ERROR - 2018-09-15 17:08:31 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\controllers\admin\Report.php 192
ERROR - 2018-09-15 17:08:31 --> Severity: Notice --> Undefined offset: 0 C:\wamp64\www\gem\application\controllers\admin\Report.php 193
ERROR - 2018-09-15 17:08:31 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\controllers\admin\Report.php 193
ERROR - 2018-09-15 17:08:31 --> Severity: Notice --> Undefined offset: 0 C:\wamp64\www\gem\application\controllers\admin\Report.php 196
ERROR - 2018-09-15 17:08:31 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\controllers\admin\Report.php 196
ERROR - 2018-09-15 17:08:31 --> Severity: Notice --> Undefined offset: 0 C:\wamp64\www\gem\application\controllers\admin\Report.php 197
ERROR - 2018-09-15 17:08:31 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\controllers\admin\Report.php 197
ERROR - 2018-09-15 17:08:31 --> Severity: Notice --> Undefined offset: 0 C:\wamp64\www\gem\application\controllers\admin\Report.php 197
ERROR - 2018-09-15 17:08:31 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\controllers\admin\Report.php 197
ERROR - 2018-09-15 17:08:32 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\wamp64\www\gem\system\core\Exceptions.php:271) C:\wamp64\www\gem\system\core\Common.php 570
ERROR - 2018-09-15 17:08:32 --> Severity: Parsing Error --> syntax error, unexpected 'echo' (T_ECHO) C:\wamp64\www\gem\application\views\admin\lab\report\add_lab_report.php 108
ERROR - 2018-09-15 17:09:05 --> Severity: Notice --> Undefined offset: 0 C:\wamp64\www\gem\application\controllers\admin\Report.php 192
ERROR - 2018-09-15 17:09:05 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\controllers\admin\Report.php 192
ERROR - 2018-09-15 17:09:05 --> Severity: Notice --> Undefined offset: 0 C:\wamp64\www\gem\application\controllers\admin\Report.php 193
ERROR - 2018-09-15 17:09:05 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\controllers\admin\Report.php 193
ERROR - 2018-09-15 17:09:05 --> Severity: Notice --> Undefined offset: 0 C:\wamp64\www\gem\application\controllers\admin\Report.php 196
ERROR - 2018-09-15 17:09:05 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\controllers\admin\Report.php 196
ERROR - 2018-09-15 17:09:05 --> Severity: Notice --> Undefined offset: 0 C:\wamp64\www\gem\application\controllers\admin\Report.php 197
ERROR - 2018-09-15 17:09:05 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\controllers\admin\Report.php 197
ERROR - 2018-09-15 17:09:05 --> Severity: Notice --> Undefined offset: 0 C:\wamp64\www\gem\application\controllers\admin\Report.php 197
ERROR - 2018-09-15 17:09:05 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\controllers\admin\Report.php 197
ERROR - 2018-09-15 17:12:07 --> Severity: Notice --> Undefined property: stdClass::$rep_identification C:\wamp64\www\gem\application\views\admin\lab\customer\specific_data.php 111
ERROR - 2018-09-15 17:12:11 --> Severity: Notice --> Undefined property: stdClass::$rep_identification C:\wamp64\www\gem\application\views\admin\lab\customer\specific_data.php 111
ERROR - 2018-09-15 17:15:15 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\gem\application\controllers\admin\Report.php 192
ERROR - 2018-09-15 23:12:05 --> Severity: Notice --> Undefined property: stdClass::$rep_identification C:\wamp64\www\gem\application\views\admin\lab\customer\specific_data.php 111
ERROR - 2018-09-15 23:13:24 --> Severity: Notice --> Undefined property: stdClass::$rep_identification C:\wamp64\www\gem\application\views\admin\lab\customer\specific_data.php 111
