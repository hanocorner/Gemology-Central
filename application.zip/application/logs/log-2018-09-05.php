<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-09-05 06:40:01 --> 404 Page Not Found: Assets/css
ERROR - 2018-09-05 06:40:06 --> Severity: Notice --> Undefined variable: noOfComments C:\wamp64\www\gem\application\views\admin\profile.php 45
ERROR - 2018-09-05 06:40:06 --> Severity: Notice --> Undefined variable: total_unpaid_certificates C:\wamp64\www\gem\application\views\admin\profile.php 56
ERROR - 2018-09-05 06:49:37 --> 404 Page Not Found: admin/Report/add_new_report
ERROR - 2018-09-05 06:50:25 --> Severity: Notice --> Undefined variable: noOfComments C:\wamp64\www\gem\application\views\admin\profile.php 45
ERROR - 2018-09-05 06:50:25 --> Severity: Notice --> Undefined variable: total_unpaid_certificates C:\wamp64\www\gem\application\views\admin\profile.php 56
ERROR - 2018-09-05 21:17:01 --> 404 Page Not Found: Assets/css
ERROR - 2018-09-05 21:17:05 --> Severity: Notice --> Undefined variable: noOfComments C:\wamp64\www\gem\application\views\admin\profile.php 45
ERROR - 2018-09-05 21:17:05 --> Severity: Notice --> Undefined variable: total_unpaid_certificates C:\wamp64\www\gem\application\views\admin\profile.php 56
ERROR - 2018-09-05 22:25:22 --> Severity: Error --> Call to undefined method Report_model::add_customer() C:\wamp64\www\gem\application\controllers\admin\Report.php 171
ERROR - 2018-09-05 22:26:44 --> Severity: Parsing Error --> syntax error, unexpected '''' (T_CONSTANT_ENCAPSED_STRING) C:\wamp64\www\gem\application\views\admin\report\add_gemstone.php 17
ERROR - 2018-09-05 22:27:50 --> Query error: Duplicate entry 'katherine@gmail.com' for key 'cus_email' - Invalid query: INSERT INTO `tbl_customer` (`cus_firstname`, `cus_lastname`, `cus_number`, `cus_email`) VALUES ('Katherine', 'Perera', '0774567891', 'katherine@gmail.com')
