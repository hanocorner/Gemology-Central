<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-09-16 08:19:21 --> Severity: Compile Error --> Cannot use isset() on the result of a function call (you can use "null !== func()" instead) C:\wamp64\www\gem\application\views\admin\lab\report\add_report.php 186
ERROR - 2018-09-16 10:18:33 --> Severity: Notice --> Undefined property: stdClass::$rep_identification C:\wamp64\www\gem\application\views\admin\lab\customer\specific_data.php 111
ERROR - 2018-09-16 10:18:35 --> 404 Page Not Found: admin/Report/add
ERROR - 2018-09-16 10:19:48 --> Severity: Notice --> Undefined property: stdClass::$rep_identification C:\wamp64\www\gem\application\views\admin\lab\customer\specific_data.php 111
ERROR - 2018-09-16 10:19:49 --> 404 Page Not Found: admin/Report/add
ERROR - 2018-09-16 10:19:56 --> Severity: Notice --> Undefined property: stdClass::$rep_identification C:\wamp64\www\gem\application\views\admin\lab\customer\specific_data.php 111
ERROR - 2018-09-16 10:19:57 --> 404 Page Not Found: admin/Report/add
ERROR - 2018-09-16 10:20:20 --> Severity: Notice --> Undefined property: stdClass::$rep_identification C:\wamp64\www\gem\application\views\admin\lab\customer\specific_data.php 111
ERROR - 2018-09-16 12:35:49 --> Query error: Unknown column 'rep_identification' in 'field list' - Invalid query: INSERT INTO `tbl_lab_report` (`rep_customerID`, `rep_object`, `rep_identification`, `rep_weight`, `rep_cut`, `rep_gemWidth`, `rep_gemHeight`, `rep_gemLength`, `rep_color`, `rep_shape`, `rep_comment`, `rep_imagename`) VALUES ('GCLC-1002', 'fusion', 'active', '8.50', 'gh', '8.50', '4.50', '5.50', 'Blue', 'oval', 'hello', 'gcl-GCL-000008.jpg')
ERROR - 2018-09-16 12:38:36 --> Query error: Duplicate entry '000000' for key 'PRIMARY' - Invalid query: INSERT INTO `tbl_gem_memocard` (`memoid`, `reportid`, `mem_date`, `mem_paymentStatus`, `mem_amount`) VALUES ('GCL-000008', 25, '2018-09-16', '0', '650.00')
ERROR - 2018-09-16 12:57:56 --> Severity: Notice --> Undefined variable: date C:\wamp64\www\gem\application\controllers\admin\Report.php 167
ERROR - 2018-09-16 12:57:56 --> Query error: Column 'mem_date' cannot be null - Invalid query: INSERT INTO `tbl_gem_memocard` (`memoid`, `reportid`, `mem_date`, `mem_paymentStatus`, `mem_amount`) VALUES ('GCL-000001', 26, NULL, 'Choose...', '650.00')
ERROR - 2018-09-16 13:06:17 --> Severity: Notice --> Undefined variable: date C:\wamp64\www\gem\application\controllers\admin\Report.php 167
ERROR - 2018-09-16 13:06:17 --> Query error: Column 'mem_date' cannot be null - Invalid query: INSERT INTO `tbl_gem_memocard` (`memoid`, `reportid`, `mem_date`, `mem_paymentStatus`, `mem_amount`) VALUES ('GCL-000001', 27, NULL, '0', '650.00')
ERROR - 2018-09-16 23:51:28 --> Severity: Notice --> Undefined index: message C:\wamp64\www\gem\application\views\admin\lab\report\add_report.php 205
