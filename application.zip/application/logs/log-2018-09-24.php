<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-09-24 08:21:45 --> Severity: Parsing Error --> syntax error, unexpected ')' C:\wamp64\www\gem\application\controllers\admin\Gemstone.php 71
ERROR - 2018-09-24 08:22:57 --> Query error: Unknown column 't2.gsrid' in 'where clause' - Invalid query: SELECT `t1`.`rep_weight`, `t1`.`rep_color`, `t1`.`rep_shape`, `t1`.`rep_comment`, `t1`.`rep_gemWidth`, `t1`.`rep_gemHeight`, `t1`.`rep_gemLength`, `t2`.`memoid` AS `repid`, `t3`.`gsrid` AS `repid`
FROM `tbl_lab_report` AS `t1`
LEFT JOIN `tbl_gem_memocard` AS `t2` ON `t1`.`reportid` = `t2`.`reportid`
LEFT JOIN `tbl_gemstone_report` AS `t3` ON `t1`.`reportid` = `t3`.`reportid`
WHERE  t2.memoid  LIKE '%GCL-000003%' ESCAPE '!' 
AND  t2.gsrid  LIKE '%GCL-000003%' ESCAPE '!' 
ERROR - 2018-09-24 12:18:16 --> Severity: Notice --> Undefined index: reportid C:\wamp64\www\gem\application\models\Gem_model.php 75
ERROR - 2018-09-24 12:18:17 --> Severity: Warning --> Division by zero C:\wamp64\www\gem\application\models\Gem_model.php 83
ERROR - 2018-09-24 12:18:17 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'JOINtbl_gem_memocard AS t2 ON t1.reportid = t2.reportid LEFT JOIN tbl_gemstone_r' at line 1 - Invalid query: SELECT t1.rep_weight, t1.rep_color, t1.rep_shape, t1.rep_comment, t1.rep_gemWidth, t1.rep_gemHeight, t1.rep_gemLength, t2.memoid AS repid, t3.gsrid AS repid FROM tbl_lab_report AS t1 LEFT JOINtbl_gem_memocard AS t2 ON t1.reportid = t2.reportid LEFT JOIN tbl_gemstone_report AS t3 ON t1.reportid = t3.reportid 
ERROR - 2018-09-24 12:19:03 --> Severity: Warning --> Division by zero C:\wamp64\www\gem\application\models\Gem_model.php 83
ERROR - 2018-09-24 12:19:03 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'JOINtbl_gem_memocard AS t2 ON t1.reportid = t2.reportid LEFT JOIN tbl_gemstone_r' at line 1 - Invalid query: SELECT t1.rep_weight, t1.rep_color, t1.rep_shape, t1.rep_comment, t1.rep_gemWidth, t1.rep_gemHeight, t1.rep_gemLength, t2.memoid AS repid, t3.gsrid AS repid FROM tbl_lab_report AS t1 LEFT JOINtbl_gem_memocard AS t2 ON t1.reportid = t2.reportid LEFT JOIN tbl_gemstone_report AS t3 ON t1.reportid = t3.reportid 
ERROR - 2018-09-24 12:20:38 --> Severity: Warning --> Division by zero C:\wamp64\www\gem\application\models\Gem_model.php 83
ERROR - 2018-09-24 12:21:55 --> Severity: Warning --> Division by zero C:\wamp64\www\gem\application\models\Gem_model.php 84
ERROR - 2018-09-24 12:22:11 --> Severity: Warning --> Division by zero C:\wamp64\www\gem\application\models\Gem_model.php 84
ERROR - 2018-09-24 12:24:09 --> Severity: Warning --> Division by zero C:\wamp64\www\gem\application\models\Gem_model.php 84
ERROR - 2018-09-24 12:24:09 --> Severity: Warning --> Division by zero C:\wamp64\www\gem\application\models\Gem_model.php 89
ERROR - 2018-09-24 12:24:09 --> Severity: Warning --> Division by zero C:\wamp64\www\gem\application\models\Gem_model.php 89
ERROR - 2018-09-24 12:24:18 --> Severity: Warning --> Division by zero C:\wamp64\www\gem\application\models\Gem_model.php 89
ERROR - 2018-09-24 12:24:18 --> Severity: Warning --> Division by zero C:\wamp64\www\gem\application\models\Gem_model.php 89
ERROR - 2018-09-24 12:25:55 --> Severity: Notice --> Undefined index: repid C:\wamp64\www\gem\application\models\Gem_model.php 75
ERROR - 2018-09-24 12:25:55 --> Severity: Notice --> Undefined index: repid C:\wamp64\www\gem\application\models\Gem_model.php 77
ERROR - 2018-09-24 13:21:13 --> Severity: Notice --> Undefined index: reportid C:\wamp64\www\gem\application\models\Gem_model.php 74
ERROR - 2018-09-24 13:21:13 --> Severity: Notice --> Undefined index: reportid C:\wamp64\www\gem\application\models\Gem_model.php 75
ERROR - 2018-09-24 13:21:13 --> Severity: Notice --> Undefined index: reportid C:\wamp64\www\gem\application\models\Gem_model.php 79
ERROR - 2018-09-24 13:23:37 --> Severity: Notice --> Undefined index: reportid C:\wamp64\www\gem\application\models\Gem_model.php 74
ERROR - 2018-09-24 13:23:37 --> Severity: Notice --> Undefined index: reportid C:\wamp64\www\gem\application\models\Gem_model.php 75
ERROR - 2018-09-24 13:23:37 --> Severity: Notice --> Undefined index: reportid C:\wamp64\www\gem\application\models\Gem_model.php 79
ERROR - 2018-09-24 13:24:28 --> Severity: Notice --> Undefined index: reportid C:\wamp64\www\gem\application\models\Gem_model.php 74
ERROR - 2018-09-24 13:24:28 --> Severity: Notice --> Undefined index: reportid C:\wamp64\www\gem\application\models\Gem_model.php 75
ERROR - 2018-09-24 13:24:28 --> Severity: Notice --> Undefined index: reportid C:\wamp64\www\gem\application\models\Gem_model.php 79
ERROR - 2018-09-24 13:24:50 --> Severity: Notice --> Undefined index: reportid C:\wamp64\www\gem\application\models\Gem_model.php 74
ERROR - 2018-09-24 13:24:50 --> Severity: Notice --> Undefined index: reportid C:\wamp64\www\gem\application\models\Gem_model.php 75
ERROR - 2018-09-24 13:24:50 --> Severity: Notice --> Undefined index: reportid C:\wamp64\www\gem\application\models\Gem_model.php 79
ERROR - 2018-09-24 13:25:15 --> Severity: Notice --> Undefined index: reportid C:\wamp64\www\gem\application\models\Gem_model.php 74
ERROR - 2018-09-24 13:25:15 --> Severity: Notice --> Undefined index: reportid C:\wamp64\www\gem\application\models\Gem_model.php 75
ERROR - 2018-09-24 13:25:15 --> Severity: Notice --> Undefined index: reportid C:\wamp64\www\gem\application\models\Gem_model.php 79
ERROR - 2018-09-24 13:25:17 --> Severity: Notice --> Undefined index: reportid C:\wamp64\www\gem\application\models\Gem_model.php 74
ERROR - 2018-09-24 13:25:17 --> Severity: Notice --> Undefined index: reportid C:\wamp64\www\gem\application\models\Gem_model.php 75
ERROR - 2018-09-24 13:25:17 --> Severity: Notice --> Undefined index: reportid C:\wamp64\www\gem\application\models\Gem_model.php 79
ERROR - 2018-09-24 13:28:22 --> Severity: Notice --> Undefined index: reportid C:\wamp64\www\gem\application\models\Gem_model.php 74
ERROR - 2018-09-24 13:28:22 --> Severity: Notice --> Undefined index: reportid C:\wamp64\www\gem\application\models\Gem_model.php 75
ERROR - 2018-09-24 13:28:22 --> Severity: Notice --> Undefined index: reportid C:\wamp64\www\gem\application\models\Gem_model.php 79
ERROR - 2018-09-24 13:29:23 --> Severity: Notice --> Undefined index: reportid C:\wamp64\www\gem\application\models\Gem_model.php 74
ERROR - 2018-09-24 13:29:23 --> Severity: Notice --> Undefined index: reportid C:\wamp64\www\gem\application\models\Gem_model.php 75
ERROR - 2018-09-24 13:29:23 --> Severity: Notice --> Undefined index: reportid C:\wamp64\www\gem\application\models\Gem_model.php 79
ERROR - 2018-09-24 13:31:05 --> Severity: Notice --> Undefined index: reportid C:\wamp64\www\gem\application\models\Gem_model.php 74
ERROR - 2018-09-24 13:31:05 --> Severity: Notice --> Undefined index: reportid C:\wamp64\www\gem\application\models\Gem_model.php 75
ERROR - 2018-09-24 13:31:05 --> Severity: Notice --> Undefined index: reportid C:\wamp64\www\gem\application\models\Gem_model.php 79
ERROR - 2018-09-24 17:46:24 --> 404 Page Not Found: Gemstone/search
ERROR - 2018-09-24 20:48:01 --> Query error: Unknown column 'tbl_lab_reportreportid' in 'where clause' - Invalid query: DELETE FROM `tbl_gemstone_report`
WHERE `tbl_lab_reportreportid` = `tbl_gemstone_reportreportid`
AND `gsrid` = 'GCL2018-091004'
ERROR - 2018-09-24 20:48:56 --> Query error: Unknown column 'tbl_lab_report.reportid' in 'where clause' - Invalid query: DELETE FROM `tbl_gemstone_report`
WHERE `tbl_lab_report`.`reportid` = `tbl_gemstone_report`.`reportid`
AND `gsrid` = 'GCL2018-091004'
ERROR - 2018-09-24 20:51:20 --> Query error: Unknown column 'tbl_lab_report.reportid' in 'where clause' - Invalid query: DELETE FROM `tbl_gemstone_report`
WHERE `tbl_lab_report`.`reportid` = `tbl_gemstone_report`.`reportid`
AND `gsrid` = 'GCL2018-091004'
ERROR - 2018-09-24 20:52:34 --> Query error: Unknown column 'tbl_gemstone_report.reportid' in 'where clause' - Invalid query: DELETE FROM `tbl_lab_report`
WHERE `tbl_lab_report`.`reportid` = `tbl_gemstone_report`.`reportid`
AND `gsrid` = 'GCL2018-091004'
AND `tbl_gemstone_report` IS NULL
ERROR - 2018-09-24 21:07:15 --> Query error: Unknown column 'tbl_gemstone_report.reportid' in 'where clause' - Invalid query: DELETE FROM `tbl_lab_report`
WHERE `tbl_lab_report`.`reportid` = `tbl_gemstone_report`.`reportid`
AND `gsrid` = 'GCL2018-091004'
ERROR - 2018-09-24 21:08:34 --> Query error: Unknown column 'tbl_gemstone_report.reportid' in 'where clause' - Invalid query: DELETE FROM `tbl_lab_report`
WHERE `tbl_lab_report`.`reportid` = `tbl_gemstone_report`.`reportid`
AND `gsrid` = 'GCL2018-091004'
ERROR - 2018-09-24 21:09:19 --> Query error: Unknown column 'tbl_gemstone_report.reportid' in 'where clause' - Invalid query: DELETE FROM `tbl_lab_report`
WHERE `tbl_lab_report`.`reportid` = `tbl_gemstone_report`.`reportid`
AND `gsrid` = 'GCL2018-091004'
ERROR - 2018-09-24 21:13:04 --> Query error: Unknown column 'tbl_gemstone_report.reportid' in 'where clause' - Invalid query: DELETE FROM `tbl_lab_report`
WHERE `tbl_lab_report`.`reportid` = `tbl_gemstone_report`.`reportid`
AND `gsrid` = 'GCL2018-091004'
ERROR - 2018-09-24 21:17:22 --> Query error: Unknown column 'tbl_gemstone_report.reportid' in 'where clause' - Invalid query: DELETE FROM `tbl_lab_report`
WHERE `tbl_lab_report`.`reportid` = `tbl_gemstone_report`.`reportid`
AND `gsrid` = 'GCL2018-091004'
ERROR - 2018-09-24 21:19:42 --> Query error: Unknown column 'gsrid' in 'where clause' - Invalid query: DELETE FROM `tbl_lab_report`
WHERE `tbl_lab_report`.`reportid` = '40'
AND `gsrid` = 'GCL2018-091004'
ERROR - 2018-09-24 21:24:09 --> Query error: Unknown column 'gsrid' in 'where clause' - Invalid query: DELETE FROM `tbl_lab_report`
WHERE `tbl_lab_report`.`reportid` = '40'
AND `gsrid` = 'GCL2018-091004'
ERROR - 2018-09-24 21:33:21 --> Query error: Unknown column 'gsrid' in 'where clause' - Invalid query: DELETE FROM `tbl_lab_report`
WHERE `tbl_lab_report`.`reportid` = '40'
AND `gsrid` = 'GCL2018-091004'
ERROR - 2018-09-24 21:34:42 --> Severity: Parsing Error --> syntax error, unexpected '$this' (T_VARIABLE), expecting ')' C:\wamp64\www\gem\application\models\Gem_model.php 184
ERROR - 2018-09-24 21:35:48 --> Query error: Unknown column 'gsrid' in 'where clause' - Invalid query: DELETE FROM `tbl_lab_report`
WHERE `gsrid` = 'GCL2018-091004'
ERROR - 2018-09-24 23:05:18 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'AS t1, tbl_gemstone_report AS t2 WHERE t1.reportid = t2.reportid AND WHERE t2.gs' at line 1 - Invalid query: DELETE FROM tbl_lab_report AS t1, tbl_gemstone_report AS t2 WHERE t1.reportid = t2.reportid AND WHERE t2.gsrid = GCL2018-091004
ERROR - 2018-09-24 23:07:02 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'AS t1, tbl_gemstone_report AS t2 WHERE t1.reportid = t2.reportid AND WHERE t2.gs' at line 1 - Invalid query: DELETE FROM tbl_lab_report AS t1, tbl_gemstone_report AS t2 WHERE t1.reportid = t2.reportid AND WHERE t2.gsrid = GCL2018-091004
ERROR - 2018-09-24 23:07:22 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'AS t1, tbl_gemstone_report AS t2 WHERE t1.reportid = t2.reportid AND t2.gsrid = ' at line 1 - Invalid query: DELETE FROM tbl_lab_report AS t1, tbl_gemstone_report AS t2 WHERE t1.reportid = t2.reportid AND t2.gsrid = GCL2018-091004
ERROR - 2018-09-24 23:08:25 --> Severity: Parsing Error --> syntax error, unexpected '$id' (T_VARIABLE) C:\wamp64\www\gem\application\models\Gem_model.php 182
ERROR - 2018-09-24 23:08:29 --> Severity: Parsing Error --> syntax error, unexpected '$id' (T_VARIABLE) C:\wamp64\www\gem\application\models\Gem_model.php 182
ERROR - 2018-09-24 23:09:15 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'AS t1, tbl_gemstone_report AS t2 WHERE t1.reportid = t2.reportid AND t2.gsrid = ' at line 1 - Invalid query: DELETE FROM tbl_lab_report AS t1, tbl_gemstone_report AS t2 WHERE t1.reportid = t2.reportid AND t2.gsrid = GCL2018-091004
ERROR - 2018-09-24 23:10:01 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'AS t1, tbl_gemstone_report AS t2 WHERE t1.reportid = t2.reportid AND WHER t2.gsr' at line 1 - Invalid query: DELETE FROM tbl_lab_report AS t1, tbl_gemstone_report AS t2 WHERE t1.reportid = t2.reportid AND WHER t2.gsrid = "GCL2018-091004" 
ERROR - 2018-09-24 23:11:18 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'AS t1, tbl_gemstone_report AS t2 WHERE t1.reportid = t2.reportid AND WHER t2.gsr' at line 1 - Invalid query: DELETE FROM tbl_lab_report AS t1, tbl_gemstone_report AS t2 WHERE t1.reportid = t2.reportid AND WHER t2.gsrid = GCL2018-091004 
ERROR - 2018-09-24 23:27:30 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'AS `t1`
WHERE `t2`.`gsrid` = 'GCL2018-091003'' at line 1 - Invalid query: DELETE FROM `tbl_lab_report` AS `t1`
WHERE `t2`.`gsrid` = 'GCL2018-091003'
ERROR - 2018-09-24 23:29:09 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'AS `t1`
WHERE `t2`.`gsrid` = 'GCL2018-091003'' at line 1 - Invalid query: DELETE FROM `tbl_lab_report` AS `t1`
WHERE `t2`.`gsrid` = 'GCL2018-091003'
ERROR - 2018-09-24 23:29:47 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'AS `t1`
WHERE `t2`.`gsrid` = 'GCL2018-091003'' at line 1 - Invalid query: DELETE FROM `tbl_lab_report` AS `t1`
WHERE `t2`.`gsrid` = 'GCL2018-091003'
ERROR - 2018-09-24 23:39:33 --> Query error: Unknown column 'GCL2018' in 'where clause' - Invalid query:  DELETE t1, t2 FROM tbl_gemstone_report AS t1 JOIN tbl_gemstone_report AS t2 ON t1.reportid = t2.reportid WHERE t2.gsrid = GCL2018-091003
ERROR - 2018-09-24 23:44:28 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1 - Invalid query:  DELETE t1, t2 FROM tbl_gemstone_report AS t1 JOIN tbl_gemstone_report AS t2 ON t1.reportid = t2.reportid WHERE t2.gsrid =  
ERROR - 2018-09-24 23:45:40 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1 - Invalid query:  DELETE t1, t2 FROM tbl_gemstone_report AS t1 JOIN tbl_gemstone_report AS t2 ON t1.reportid = t2.reportid WHERE t2.gsrid =  
ERROR - 2018-09-24 23:46:19 --> Query error: Unknown column 'GCL2018' in 'where clause' - Invalid query:  DELETE t1, t2 FROM tbl_gemstone_report AS t1 JOIN tbl_gemstone_report AS t2 ON t1.reportid = t2.reportid WHERE t2.gsrid = GCL2018-091002 
ERROR - 2018-09-24 23:50:47 --> Query error: Unknown column 'GCL2018' in 'where clause' - Invalid query:  DELETE t1, t2 FROM tbl_gemstone_report AS t1 JOIN tbl_gemstone_report AS t2 ON t1.reportid = t2.reportid WHERE t2.gsrid = GCL2018-091001 
ERROR - 2018-09-24 23:51:42 --> Query error: Unknown column 'GCL2018' in 'where clause' - Invalid query:  DELETE t1, t2 FROM tbl_gemstone_report AS t1 JOIN tbl_gemstone_report AS t2 ON t1.reportid = t2.reportid WHERE t2.gsrid = GCL2018-091001 
ERROR - 2018-09-24 23:53:05 --> Severity: Parsing Error --> syntax error, unexpected '"' C:\wamp64\www\gem\application\models\Gem_model.php 183
ERROR - 2018-09-24 23:53:33 --> Severity: Error --> Call to a member function affected_rows() on boolean C:\wamp64\www\gem\application\models\Gem_model.php 187
ERROR - 2018-09-24 23:55:29 --> Severity: Notice --> Array to string conversion C:\wamp64\www\gem\application\controllers\admin\Gemstone.php 136
