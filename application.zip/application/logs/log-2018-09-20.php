<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-09-20 00:00:43 --> 404 Page Not Found: Assets/admin
ERROR - 2018-09-20 00:40:27 --> 404 Page Not Found: Assets/admin
ERROR - 2018-09-20 01:42:17 --> 404 Page Not Found: Assets/admin
ERROR - 2018-09-20 01:42:53 --> 404 Page Not Found: Assets/admin
ERROR - 2018-09-20 01:51:25 --> 404 Page Not Found: Assets/admin
ERROR - 2018-09-20 01:51:28 --> 404 Page Not Found: Assets/admin
ERROR - 2018-09-20 07:06:50 --> 404 Page Not Found: Report/index
ERROR - 2018-09-20 07:07:04 --> 404 Page Not Found: Report_verification/index
ERROR - 2018-09-20 07:08:12 --> Severity: Notice --> Undefined variable: captcha C:\wamp64\www\gem\application\views\public\report\manuel_form.php 29
ERROR - 2018-09-20 07:10:53 --> Could not find the language line "form_validation_"
ERROR - 2018-09-20 07:18:14 --> 404 Page Not Found: Report/index
ERROR - 2018-09-20 07:29:58 --> 404 Page Not Found: Report/index
ERROR - 2018-09-20 07:37:50 --> 404 Page Not Found: Report_verification/index
ERROR - 2018-09-20 07:40:10 --> 404 Page Not Found: Authenticating_report/index
ERROR - 2018-09-20 07:48:05 --> 404 Page Not Found: Authenticating_report/index
ERROR - 2018-09-20 07:54:32 --> 404 Page Not Found: Authenticating_report/index
ERROR - 2018-09-20 07:56:57 --> 404 Page Not Found: Assets/admin
ERROR - 2018-09-20 08:05:13 --> 404 Page Not Found: Authenticating_report/index
ERROR - 2018-09-20 08:07:16 --> 404 Page Not Found: Assets/admin
ERROR - 2018-09-20 08:52:07 --> 404 Page Not Found: Report/index
ERROR - 2018-09-20 08:53:04 --> 404 Page Not Found: Assets/admin
ERROR - 2018-09-20 08:54:11 --> 404 Page Not Found: Assets/admin
ERROR - 2018-09-20 08:59:28 --> 404 Page Not Found: Assets/admin
ERROR - 2018-09-20 09:00:12 --> 404 Page Not Found: Assets/admin
