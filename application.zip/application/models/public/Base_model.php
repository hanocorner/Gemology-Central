<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Base_model extends CI_Model
{
  /**
   * Default Constructor
   *
   * @param none
   */
  public function __construct() {
      parent::__construct();
  }
}
?>
