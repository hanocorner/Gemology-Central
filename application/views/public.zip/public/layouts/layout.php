<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <title> <?php echo $title; ?></title>

    <!--  -->
    <?php echo $this->layout->print_includes() ?>
    <!--  -->

  </head>
  <body>
    <?php echo $content; ?>
  </body>
</html>
